# Instructor Demo Script: Kickoff I-Do (about 40 minutes)

The I-do walk that opens the capstone. You demonstrate the finished system's behavior end to end WITHOUT showing solution code, ending at the hand-off point: teams leave knowing what "done" looks like, does, and refuses to do. Timing assumes services were started before class.

## Pre-flight checklist (before the room fills)

- [ ] `docker compose up -d` from the project root; `docker compose ps` shows both services running. On Apple Silicon, if the Pinecone Local pull ever fails, the compose file has a commented `platform: linux/amd64` line; verify on YOUR machine beforehand, not live.
- [ ] Ports free: 5080 (Pinecone), 5001 (MLflow; note port 5000 is AirPlay on macOS, which is why we are on 5001), 8000 (API), 8501 (TruLens).
- [ ] Dedicated venv active (`which python` shows the capstone .venv). Do not present from the main cohort venv; mlflow's pandas pin makes them incompatible by design.
- [ ] Solution package pre-verified: `CAPSTONE_TARGET=solution pytest tests/ -q` shows 50 passed. Run it now, not live.
- [ ] Ingest ALREADY RUN against the solution (`./run.sh solution ingest`), so the sweep segment does not wait on embedding.
- [ ] Sweep ALREADY RUN once (`./run.sh solution experiment` then `select-champion`), so MLflow has the six runs and the champion tag before class. You will re-run the sweep live; the pre-run is your fallback.
- [ ] MLflow UI open in a tab at http://localhost:5001 with the experiment's compare view bookmarked. TruLens dashboard NOT yet running (you will launch it live; it launches fast).
- [ ] `.env` says LAB_BACKEND=offline and EMBEDDING_BACKEND=hash for the demo: deterministic, no model server, and your numbers will match the README table exactly.

## Segment 1: The corpus is the villain (5 min)

Open the corpus folder in a file listing. Say: 31 documents, everything a retailer's knowledge base actually contains: policies, product manuals, how-to guides, operations docs, a recall notice, a safety data sheet, a call-transcript digest.

Open `policy_returns_2026.md` briefly: front matter, then normal markdown. Then say the sentence that frames the whole lab: "This corpus will fight you the way real ones do, at least four distinct ways, and your ingestion code has to win. The tests know every trick; when something breaks strangely, the symptom-keyed section at the bottom of HINTS.md is your field guide."

Do NOT enumerate the curveballs. Naming them costs the discovery.

## Segment 2: Ingest, narrated by its numbers (5 min)

```bash
./run.sh solution check-services
./run.sh solution ingest
```

Read the printout line by line, out loud: 31 loaded; 30 active with 1 superseded dropped ("hold that thought: superseded by WHAT rule? That is one of your tasks"); about 190 chunks with 6 duplicates dropped ("also your task, and the 6 has a story your team will want to tell at demos"); the embedding backend line; the upserted count. Say: "Every number on this screen is a test your starter fails right now."

**Expected output:** counts matching the README; total runtime a few seconds. **Recovery:** if Pinecone is unreachable, check-services says so plainly; `docker compose up -d`, ten seconds, retry. If anything deeper misbehaves, the numbers above are on the slide and in the README; narrate from there and debug at break.

## Segment 3: Ask it things (8 min)

```bash
./run.sh solution serve
```

Open http://localhost:8000/docs. Frame it: "FastAPI generated this page from the code's type declarations; contract and documentation are the same artifact here."

Three requests through the docs UI, in this order:

1. **/search** with `q=return window`, top_k 3. Show the hits: text plus citation fields. "This endpoint is the shared knowledge base as a service; another team could build on it without ever touching an LLM."
2. **/answer** with "What is the standard return window for most items?" Read the answer (30 days, receipt, the Platinum extension) and then, deliberately, the sources array. "Grounded means the receipts come attached."
3. **/answer** with "Does Cordwell offer a military discount?" Read the refusal aloud: NOT ENOUGH CONTEXT. "The corpus does not cover it, so the system says so. By the end of this capstone you will have MEASURED how much that refusal is worth, not just asserted it."

Interaction hook: take one audience question and submit it live. Both outcomes teach: an answer shows retrieval breadth, a refusal shows the boundary. **Recovery:** if serve fails, `connect_existing_index` failing fast means ingest did not run against this target; the error says so; re-run ingest.

## Segment 4: The sweep and the champion (12 min)

```bash
./run.sh solution experiment
```

While the six runs print (under a minute), explain the grid: three prompt variants (helpful baseline that never refuses; grounded_strict that answers only from context and abstains; concise) crossed with top_k 3 and 5. As lines appear, point at abstain_recall: 0.000, 0.000, then 0.667s. "Watch that column; it is about to decide everything."

Switch to the MLflow tab. In the compare view, walk the parallel coordinates: baselines high on ROUGE and relevance, diving to zero at abstain_recall. Then:

```bash
./run.sh solution select-champion
```

Read the verdict: both baselines ineligible on the abstain gate, grounded_strict-k3 wins the composite at 0.5251. Open `artifacts/champion.json`. The line to deliver slowly: "The most fluent configuration lost, on a safety standard written down before the sweep ran, and nobody had to win a meeting for that to happen. That is what evaluation-driven selection means, and building this machinery is your Days 2 and 3."

**Recovery:** if the live sweep misbehaves, the pre-run results are already in MLflow; pivot to the UI and select-champion still works against them.

## Segment 5: One trace (5 min)

```bash
./run.sh solution dashboard
```

TruLens on http://localhost:8501. Leaderboard: same six versions, same triad numbers as MLflow ("one source of truth, two views"). Click into grounded_strict-k3, open one record, and walk a single trace top to bottom: question, retrieval span with the actual chunks, the answer, the three metric scores. "Aggregates tell you WHICH configuration; traces tell you WHY. You will use both in your demo."

**Recovery:** dashboard is the lowest-stakes segment; if Streamlit sulks, show the per-question results.csv artifact in MLflow instead, which carries the same per-question story.

## Segment 6: The hand-off (5 min)

Show the starter tree and open ONE contract docstring (Task 4 in chunking.py reads well aloud). Then the failing-test baseline:

```bash
CAPSTONE_TARGET=starter pytest tests/ -q
```

"Thirty-three failures, and that is the syllabus. Twelve tasks, each with a contract like the one you just read. Milestones and the team split are in the participant guide; two hint tiers exist and you pick ONE per task; the solution package is in the repo and opening it before your demo is only cheating yourself. Milestone 1 is your environment up by the first break. Go."

Do not demo any solution internals. The walkthroughs exist for AFTER their demos.
