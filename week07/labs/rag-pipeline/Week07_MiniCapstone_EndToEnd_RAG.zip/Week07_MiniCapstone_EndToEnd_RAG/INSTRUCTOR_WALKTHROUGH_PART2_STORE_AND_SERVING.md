# Instructor Walkthrough, Part 2: Embeddings, the Vector Store, and the API

Line-by-line through embeddings.py, vector_store.py, api.py, and the CLI plumbing that connects them.

## embeddings.py: two backends, one shape

### pick_device (student Task 1)

The whole routine exists to make one sentence true everywhere: "no code in this project ever hard-codes a device." The import of torch happens INSIDE the function, inside a try block, which reads oddly until you remember the hash embedder path must work on a machine where torch is not installed at all. CUDA is probed first (free speed when present), then MPS through `hasattr(torch.backends, "mps")` because older torch builds do not even have that attribute and touching it would crash the very function whose contract is "never raise." Everything else falls through to cpu. On the cohort's Macs the answer is mps for the sentence-transformers backend and irrelevant for the hash backend, and both of those facts are worth saying aloud.

### The Embedder protocol

A Protocol is Python's way of saying "anything with these methods counts." Both embedders expose `name`, `dim`, and `embed(list of texts) -> list of vectors`. Downstream code type-hints against the protocol and genuinely cannot tell which backend it holds. That indifference is what makes the sweep's embedding_backend parameter honest.

### HashEmbedder

Worth narrating slowly, because it demystifies embeddings for engineers who think they are magic. Every word is hashed to a slot number between 0 and 383 and a sign, plus or minus. A text's vector starts as 384 zeros; each word adds its sign into its slot; adjacent word pairs do the same at half weight (so "return window" as a phrase carries signal beyond its two words); the vector is scaled to length 1. Two texts sharing vocabulary collide in the same slots with the same signs, so their dot product rises. It is literally keyword matching dressed in geometry, deterministic to the byte, and that is why the tests use it.

Two refinements earn their lines. The plural fold (`returns` and `return` hash identically) is the cheapest normalization with the biggest payoff on retail text. The stopword set exists because conversational documents are dense in "the, you, does, how," and without filtering, a chatty call transcript scores spuriously well against EVERY question just by being chatty. The corpus contains a 41 KB transcript precisely dense in such words; before the stopword filter existed, it polluted the top ranks of half the eval questions. Show the class the STOPWORDS frozenset and let them notice entries like "thi" and "wa": the list is written in FOLDED form because filtering happens after folding. That tiny ordering detail is a nice example of two normalizations needing to agree about who runs first.

### SentenceTransformerEmbedder

Lazy import (torch and sentence-transformers load only when this backend is chosen), model name from config, device from pick_device, `normalize_embeddings=True` so downstream cosine math is identical for both backends. `get_embedder()` dispatches on config and raises ValueError with the valid options for anything else: same no-silent-fallback stance as the LLM backends.

## vector_store.py: the SDK boundary

### Connection and index lifecycle

The constructor builds a Pinecone client against `PINECONE_HOST` with any api key (Pinecone Local ignores keys but the client requires one; "pclocal" is tradition). `ensure_fresh_index` deletes any existing index and creates a dense one with our dimension and cosine metric: ingest is idempotent by demolition, which for a teaching corpus of 190 vectors is the right trade. `connect_existing_index` is the serving path: it refuses to create anything and fails fast with a clear message if ingest has not run, because an API that silently serves an empty index is a debugging nightmare wearing a 200 status code.

One Pinecone Local wrinkle worth pre-flighting: after index creation the client talks to the index on a data-plane port the emulator assigns (5081 and up), which is why compose publishes the 5080-5090 range and why the emulator's host alias appears in the compose file.

### build_metadata and metadata_size_bytes

Static methods, deliberately: pure functions of a chunk, testable without any connection. Metadata carries the text itself plus the citation fields (doc_id, title, category, effective_date, seq). `metadata_size_bytes` measures the JSON-serialized UTF-8 byte length, not character count, and the test suite includes an accented-text case to catch anyone measuring characters: "café" is four characters and five bytes, and Pinecone bills bytes.

### upsert_chunks (student Task 6)

Three movements. Alignment check first: chunks and vectors must be the same length, and a mismatch is a programming error deserving an immediate ValueError. Then ALL records are built and size-checked before ANY network call: the guard raising on record 137 after 100 records already shipped would leave a half-written index, so validation is fully front-loaded. The error message names the chunk id and the byte size, which turns a failed ingest into a one-line diagnosis. Finally batching: slices of 100 sent as `self.index.upsert(vectors=batch)`. The keyword is not style. pinecone 9.x removed the positional form, and the FakeIndex in the tests raises the same TypeError the real client does, so students who write `upsert(batch)` learn it from a fast local test instead of a slow live one.

### query_top_k (student Task 7)

One query call with `include_metadata=True`, then normalization: every match becomes a plain dict with id, float score, and the metadata fields defaulted safely. The dual attribute-or-dict access pattern looks paranoid until you enumerate who calls this function: the real SDK (attribute-style responses), the test fake (SimpleNamespace, attribute-style), and any future cached fixture (dicts). The rule being taught: response objects from a vendor SDK stop at the boundary module; the rest of the codebase speaks plain data.

### stats

Normalizes `describe_index_stats()` through three shapes: `to_dict()` if offered, mapping if it is one, attribute harvest otherwise. Written that way after the health endpoint returned "degraded" against the test fake for want of a `to_dict`; a two-line lesson in defensive normalization at boundaries.

## api.py: the service

### The models

Pydantic models are the API's contract, and FastAPI turns them into both validation and documentation. `AnswerRequest` constrains question length and top_k bounds declaratively; the /docs page students open at M6 is generated from exactly these declarations. One narration point: `SearchHit` is reused as the sources element of `AnswerResponse`, so the citation a caller gets from /answer is byte-identical in shape to a /search hit. Consistency like that is free when models are shared and expensive to retrofit when they are not.

### create_app and lifespan

The factory takes optional store and embedder. In production nothing is passed and the lifespan hook builds both at startup: the embedder loads once (a sentence-transformers model load is not something to repeat per request) and the store attaches to the existing index, failing fast if ingest never ran. In tests, fakes are injected and no Docker is needed. When a student asks why the app is built by a function instead of at module import, this is the answer in one sentence: dependency injection is what makes endpoint logic unit-testable, and module-level construction is what makes it not.

The tests use `with TestClient(app) as client`, and the context manager matters: entering it runs the lifespan startup. A TestClient used without the with-block skips lifespan, state stays empty, and every endpoint 500s mysteriously. Worth demoing the broken version for thirty seconds; it is a common FastAPI stumble.

### /health

Reports status, backend configuration, and index stats, degrading to "degraded" with the error string if the store cannot answer. The philosophical point for the room: health endpoints exist for the operator at 2 AM, so they should report configuration reality (which backend, which model, how many vectors), not just "ok".

### /search (student Task 12)

Four lines over things already built: embed the query, ask the store, map matches into SearchHits, wrap in a SearchResponse. The deliberate absence: no validation inside the handler. The Query() declarations already rejected short queries and out-of-range top_k with a 422 before the handler ran. Re-validating inside is how the real behavior and the documented contract drift apart.

### /answer

Builds a RagPipeline from the requested variant (unknown variant names 422 with the valid list), runs retrieve then generate, and builds sources from `pipeline.last_matches`, the same field the evaluation harness reads. One pipeline instance per request keeps the handler stateless; the heavy objects (embedder, store) live in app state and are shared.

## cli.py: the driver's seat

check-services pings all four dependencies with three-second timeouts and prints UP or DOWN with a tag marking each as required or optional; it is deliberately the first command in every troubleshooting path. ingest narrates every stage count so the curveballs surface as numbers. serve runs uvicorn against the app factory. experiment and select-champion are Part 4's story. dashboard launches TruLens Streamlit on a fixed port with `force=True` so re-running it reclaims the port instead of dying; that pairing is the difference between a demo that recovers and one that does not.
