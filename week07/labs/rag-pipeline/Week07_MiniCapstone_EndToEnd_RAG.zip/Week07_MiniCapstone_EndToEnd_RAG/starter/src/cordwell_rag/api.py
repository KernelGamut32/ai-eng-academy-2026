"""FastAPI service over the populated index.

Two jobs, deliberately separated:

  * GET /search : serve raw context chunks for a query. This is the
    retrieval service other teams would call to build their own features
    on top of the shared knowledge base. It never touches an LLM.
  * POST /answer : the full RAG answer, using whatever LAB_BACKEND is
    active. Offline mode makes this endpoint fully demoable with no model
    server running.

The app is built by a factory (create_app) that accepts injectable
dependencies, which is what makes the endpoint logic unit-testable with a
fake store and no Docker."""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

from . import config
from .embeddings import Embedder, get_embedder
from .rag import VARIANTS, RagPipeline
from .vector_store import PineconeLocalStore


class SearchHit(BaseModel):
    id: str
    score: float
    text: str
    doc_id: str
    title: str
    category: str
    effective_date: str


class SearchResponse(BaseModel):
    query: str
    top_k: int
    hits: List[SearchHit]


class AnswerRequest(BaseModel):
    question: str = Field(min_length=3)
    variant: str = "grounded_strict"
    top_k: int = Field(default=5, ge=1, le=20)


class AnswerResponse(BaseModel):
    question: str
    answer: str
    variant: str
    backend: str
    sources: List[SearchHit]


def create_app(
    store: Optional[PineconeLocalStore] = None,
    embedder: Optional[Embedder] = None,
) -> FastAPI:
    """Build the service. When store/embedder are not injected (normal
    operation), they are constructed at startup: the embedder loads once,
    and the store attaches to the existing index and fails fast if ingest
    has not run."""

    state: Dict[str, Any] = {"store": store, "embedder": embedder}

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if state["embedder"] is None:
            state["embedder"] = get_embedder()
        if state["store"] is None:
            s = PineconeLocalStore()
            s.connect_existing_index()
            state["store"] = s
        yield

    app = FastAPI(title="Cordwell Knowledge Base API", version="1.0", lifespan=lifespan)

    @app.get("/health")
    def health() -> Dict[str, Any]:
        payload: Dict[str, Any] = {"status": "ok", "backend": config.BACKEND_MODE}
        try:
            payload["index"] = state["store"].stats()
        except Exception as exc:  # index reachable-ness is health information
            payload["status"] = "degraded"
            payload["index_error"] = str(exc)
        return payload

    @app.get("/search", response_model=SearchResponse)
    def search(
        q: str = Query(min_length=3, description="The user's question or phrase"),
        top_k: int = Query(default=5, ge=1, le=20),
    ) -> SearchResponse:
        """Serve context chunks over HTTP.

        This endpoint is the 'usage' half of the capstone: the populated
        RAG store consumed as a service by other teams.

        Contract:
          * Embed q with state["embedder"], query state["store"] with
            query_top_k(vector, top_k=top_k).
          * Map each match dict to a SearchHit (fields: id, score, text,
            doc_id, title, category, effective_date).
          * Return SearchResponse(query=q, top_k=top_k, hits=hits).
        FastAPI already validates q length and top_k bounds from the
        Query() declarations; do not re-validate.
        """
        # TODO(Task 12): implement the search endpoint.
        raise NotImplementedError("TODO Task 12: /search")

    @app.post("/answer", response_model=AnswerResponse)
    def answer(req: AnswerRequest) -> AnswerResponse:
        if req.variant not in VARIANTS:
            raise HTTPException(
                status_code=422,
                detail=f"Unknown variant {req.variant!r}. Choose from {sorted(VARIANTS)}.",
            )
        pipeline = RagPipeline(
            state["embedder"], state["store"], VARIANTS[req.variant], top_k=req.top_k
        )
        answer_text = pipeline.answer(req.question)
        sources = [
            SearchHit(
                id=m["id"],
                score=m["score"],
                text=m["text"],
                doc_id=m["doc_id"],
                title=m["title"],
                category=m["category"],
                effective_date=m["effective_date"],
            )
            for m in pipeline.last_matches
        ]
        return AnswerResponse(
            question=req.question,
            answer=answer_text,
            variant=req.variant,
            backend=config.BACKEND_MODE,
            sources=sources,
        )

    return app


app = create_app()
