"""Embedding backends.

Two interchangeable embedders, both 384-dimensional:

  * SentenceTransformerEmbedder ("st"): the real model the cohort has been
    using since Week 5 (all-MiniLM-L6-v2). Needs the model cached locally.
  * HashEmbedder ("hash"): a deterministic hashed bag-of-words embedder.
    No downloads, no model files, identical output on every machine. It is
    what the unit tests use, and it is a perfectly honest lexical-matching
    baseline: two texts score as similar when they share words and word
    pairs, which is exactly what it looks like it does.

Keeping both behind one interface means the index dimension, the ingest
code, and the retrieval code never change when you switch backends.
"""

from __future__ import annotations

import hashlib
import math
import re
from typing import List, Protocol

from . import config


def pick_device() -> str:
    """Return the best available torch device name.

    Contract:
      * Return "cuda" when torch reports CUDA available.
      * Otherwise return "mps" when Apple MPS is available.
      * Otherwise return "cpu".
      * Never raise: if torch is missing or probing fails, return "cpu".
    """
    # TODO(Task 1): implement the CUDA -> MPS -> CPU runtime device pick.
    raise NotImplementedError("TODO Task 1: pick_device")



class Embedder(Protocol):
    name: str
    dim: int

    def embed(self, texts: List[str]) -> List[List[float]]: ...


_TOKEN_RE = re.compile(r"[a-z0-9]+")


class HashEmbedder:
    """Deterministic hashed bag-of-words embedding.

    How it works, in plain terms: every word (and every adjacent word
    pair) is hashed to a fixed slot in a 384-long vector and to a +1 or -1
    sign. We add the word's weight into its slot, then scale the vector to
    length 1. Texts that share vocabulary end up pointing in similar
    directions, so cosine similarity behaves like a keyword match score.
    There is no learning and no randomness: the same text always produces
    exactly the same vector, on any machine.
    """

    name = "hash"

    # A tiny stopword list. Without this, chatty conversational text scores
    # spuriously high against every question because both are dense in
    # words like "the", "you", and "does" that carry no topical meaning.
    STOPWORDS = frozenset(
        """a an and are at be but by can do doe for from ha have how i if in
        is it its me my no not of on or our so than that the their them then
        there these they thi to u wa we what when where which who why will
        with you your""".split()
    )

    def __init__(self, dim: int = config.EMBED_DIM):
        self.dim = dim

    def _slot_and_sign(self, token: str) -> tuple[int, float]:
        digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
        slot = int.from_bytes(digest[:4], "big") % self.dim
        sign = 1.0 if digest[4] % 2 == 0 else -1.0
        return slot, sign

    @staticmethod
    def _fold(token: str) -> str:
        """Fold trivial plurals so 'return' and 'returns' hash to the same
        slot. This is not stemming, just the single cheapest normalization
        with the biggest retrieval payoff for English retail text."""
        if len(token) > 3 and token.endswith("s") and not token.endswith("ss"):
            return token[:-1]
        return token

    def _embed_one(self, text: str) -> List[float]:
        vec = [0.0] * self.dim
        tokens = [
            folded
            for t in _TOKEN_RE.findall(text.lower())
            if (folded := self._fold(t)) not in self.STOPWORDS
        ]
        for tok in tokens:
            slot, sign = self._slot_and_sign(tok)
            vec[slot] += sign * 1.0
        for a, b in zip(tokens, tokens[1:]):
            slot, sign = self._slot_and_sign(f"{a}_{b}")
            vec[slot] += sign * 0.5
        norm = math.sqrt(sum(v * v for v in vec))
        if norm > 0:
            vec = [v / norm for v in vec]
        return vec

    def embed(self, texts: List[str]) -> List[List[float]]:
        return [self._embed_one(t) for t in texts]


class SentenceTransformerEmbedder:
    """all-MiniLM-L6-v2 via sentence-transformers, on the auto-selected
    device. Imported lazily so machines running the hash backend never
    need torch installed."""

    name = "st"

    def __init__(self, model_name: str = config.ST_MODEL_NAME):
        from sentence_transformers import SentenceTransformer  # lazy: heavy import

        self.device = pick_device()
        self.model = SentenceTransformer(model_name, device=self.device)
        self.dim = int(self.model.get_embedding_dimension())
        if self.dim != config.EMBED_DIM:
            raise ValueError(
                f"Model {model_name} produces {self.dim}-dim vectors but the "
                f"index is configured for {config.EMBED_DIM}. Pick a matching model."
            )

    def embed(self, texts: List[str]) -> List[List[float]]:
        vectors = self.model.encode(
            texts, normalize_embeddings=True, convert_to_numpy=True, show_progress_bar=False
        )
        return [v.tolist() for v in vectors]


def get_embedder(backend: str | None = None) -> Embedder:
    """Factory keyed by EMBEDDING_BACKEND: 'st' or 'hash'.

    Unknown values raise immediately. No silent fallback: if you asked for
    the sentence-transformers backend and it cannot load, you should know.
    """
    backend = backend or config.EMBEDDING_BACKEND
    if backend == "hash":
        return HashEmbedder()
    if backend == "st":
        return SentenceTransformerEmbedder()
    raise ValueError(
        f"Unknown EMBEDDING_BACKEND {backend!r}. Expected 'st' or 'hash'."
    )
