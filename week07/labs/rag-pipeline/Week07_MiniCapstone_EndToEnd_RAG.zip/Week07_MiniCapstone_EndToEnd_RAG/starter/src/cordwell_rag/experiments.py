"""The experiment sweep and champion selection.

The sweep runs the full evaluation once per configuration (prompt variant
x top_k), logging each run to MLflow with:

  * params : everything needed to reproduce the run
  * metrics: the deterministic metrics plus the TruLens triad
  * artifacts: the per-question results CSV and the exact system prompt

Champion selection then happens programmatically from the MLflow store:
hard gates first (a run that hallucinates or misses retrieval is not
eligible no matter how good its ROUGE looks), then a weighted composite
score picks among the survivors. The winning run is tagged in MLflow and
its full configuration is written to artifacts/champion.json, which is
what a deployment pipeline would consume."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import mlflow
import pandas as pd

from . import config
from .embeddings import Embedder
from .evaluation import EvalItem, run_evaluation
from .rag import VARIANTS, RagPipeline
from .vector_store import PineconeLocalStore

# ---------------------------------------------------------------------------
# Sweep configuration
# ---------------------------------------------------------------------------

DEFAULT_SWEEP: List[Dict[str, Any]] = [
    {"variant": "baseline", "top_k": 3},
    {"variant": "baseline", "top_k": 5},
    {"variant": "grounded_strict", "top_k": 3},
    {"variant": "grounded_strict", "top_k": 5},
    {"variant": "concise", "top_k": 3},
    {"variant": "concise", "top_k": 5},
]


@dataclass
class ChampionCriteria:
    """Gates are pass/fail eligibility rules; weights rank the survivors.

    Gate rationale:
      * groundedness: below this, the pipeline is decorating hallucinations.
      * retrieval_hit_rate: below this, answers cannot be right except by luck.
      * abstain_recall: below this, the pipeline answers questions it has
        no business answering.
    Composite rationale: groundedness is weighted highest because a wrong
    confident answer at the returns desk costs more than a slightly
    less fluent right one.
    """

    gates: Dict[str, float] = field(
        default_factory=lambda: {
            "groundedness": 0.60,
            "retrieval_hit_rate": 0.70,
            "abstain_recall": 0.66,
        }
    )
    weights: Dict[str, float] = field(
        default_factory=lambda: {
            "groundedness": 0.40,
            "rougeL_f": 0.30,
            "answer_relevance": 0.30,
        }
    )


# ---------------------------------------------------------------------------
# Sweep
# ---------------------------------------------------------------------------


def run_sweep(
    embedder: Embedder,
    store: PineconeLocalStore,
    eval_items: List[EvalItem],
    session,
    sweep: Optional[List[Dict[str, Any]]] = None,
    experiment_name: str = config.MLFLOW_EXPERIMENT_NAME,
    tracking_uri: str = config.MLFLOW_TRACKING_URI,
) -> List[str]:
    """Run every configuration and log each as one MLflow run.

    Returns the list of MLflow run ids, in sweep order."""
    sweep = sweep or DEFAULT_SWEEP
    mlflow.set_tracking_uri(tracking_uri)
    mlflow.set_experiment(experiment_name)
    config.ensure_dirs()

    run_ids: List[str] = []
    for spec in sweep:
        variant = VARIANTS[spec["variant"]]
        top_k = int(spec["top_k"])
        app_version = f"{variant.name}-k{top_k}"
        pipeline = RagPipeline(embedder, store, variant, top_k=top_k)

        with mlflow.start_run(run_name=app_version) as run:
            mlflow.log_params(
                {
                    "variant": variant.name,
                    "top_k": top_k,
                    "backend": config.BACKEND_MODE,
                    "model": config.LOCAL_MODEL if config.BACKEND_MODE != "offline" else "extractive",
                    "embedding_backend": embedder.name,
                    "chunk_max_chars": config.CHUNK_MAX_CHARS,
                    "chunk_overlap_chars": config.CHUNK_OVERLAP_CHARS,
                    "index_name": config.INDEX_NAME,
                    "temperature": variant.temperature,
                    "eval_set_size": len(eval_items),
                }
            )

            result = run_evaluation(
                pipeline,
                eval_items,
                session,
                app_name=config.TRULENS_APP_NAME,
                app_version=app_version,
            )
            mlflow.log_metrics(result["aggregate"])

            # Artifacts: the receipts for this run.
            run_dir = config.ARTIFACTS_DIR / "runs" / app_version
            run_dir.mkdir(parents=True, exist_ok=True)
            per_question = pd.DataFrame(result["rows"])
            csv_path = run_dir / "per_question_results.csv"
            per_question.to_csv(csv_path, index=False)
            prompt_path = run_dir / "system_prompt.txt"
            prompt_path.write_text(variant.system_prompt, encoding="utf-8")
            mlflow.log_artifact(str(csv_path))
            mlflow.log_artifact(str(prompt_path))

            run_ids.append(run.info.run_id)
            agg = result["aggregate"]
            print(
                f"[{app_version}] hit_rate={agg['retrieval_hit_rate']:.3f} "
                f"mrr={agg['retrieval_mrr']:.3f} rougeL={agg['rougeL_f']:.3f} "
                f"grounded={agg.get('groundedness', 0.0):.3f} "
                f"abstain_recall={agg['abstain_recall']:.3f}"
            )
    return run_ids


# ---------------------------------------------------------------------------
# Champion selection
# ---------------------------------------------------------------------------


def pick_champion(
    runs_df: pd.DataFrame, criteria: ChampionCriteria
) -> Dict[str, Any]:
    """Pure champion selection over an mlflow.search_runs dataframe.

    Contract:
      * Gates: for each (metric, threshold) in criteria.gates, drop runs
        where metrics.<metric> is missing, NaN, or < threshold. Count the
        failures per gate.
      * If no run survives, return {"status": "no_eligible_run",
        "gate_failures": {...}, "message": <any helpful string>}.
      * Composite: weighted sum over criteria.weights of metrics.<name>
        (missing values count 0.0).
      * Winner: highest composite; break ties by higher
        metrics.groundedness, then run_id ascending, so selection is
        deterministic.
      * Return {"status": "champion_selected", "run_id", "run_name",
        "composite", "params": {variant, top_k, backend,
        embedding_backend}, "metrics": {gate+weight metric values},
        "gate_failures"}.
    """
    # TODO(Task 11): implement gates-then-composite selection. This
    # function is pure so it is testable without an MLflow server.
    raise NotImplementedError("TODO Task 11: pick_champion")



def select_champion(
    experiment_name: str = config.MLFLOW_EXPERIMENT_NAME,
    tracking_uri: str = config.MLFLOW_TRACKING_URI,
    criteria: Optional[ChampionCriteria] = None,
) -> Dict[str, Any]:
    """Query MLflow, pick the champion, tag it, and write champion.json.

    In a production pipeline the champion.json (or an MLflow Model Registry
    alias, which is the pattern from the DVC and MLflow module) is what the
    deployment stage consumes. Here the pipeline is configuration rather
    than model weights, so a config artifact is the honest equivalent.
    """
    criteria = criteria or ChampionCriteria()
    mlflow.set_tracking_uri(tracking_uri)
    experiment = mlflow.get_experiment_by_name(experiment_name)
    if experiment is None:
        raise RuntimeError(f"MLflow experiment {experiment_name!r} not found. Run the sweep first.")

    runs_df = mlflow.search_runs(experiment_ids=[experiment.experiment_id])
    if runs_df.empty:
        raise RuntimeError(f"Experiment {experiment_name!r} has no runs. Run the sweep first.")

    verdict = pick_champion(runs_df, criteria)

    if verdict["status"] == "champion_selected":
        client = mlflow.tracking.MlflowClient()
        client.set_tag(verdict["run_id"], "champion", "true")
        config.ensure_dirs()
        champion_path = config.ARTIFACTS_DIR / "champion.json"
        champion_path.write_text(json.dumps(verdict, indent=2), encoding="utf-8")
        print(f"Champion: {verdict['run_name']} (run {verdict['run_id'][:8]})")
        print(f"Composite: {verdict['composite']:.4f}")
        print(f"Written: {champion_path}")
    else:
        print("No eligible run. Gate failure counts:", verdict["gate_failures"])
    return verdict
