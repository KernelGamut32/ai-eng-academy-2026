"""The RAG pipeline: retrieve, then generate, under TruLens instrumentation.

Three prompt variants define the experiment axis for the MLflow sweep:

  * baseline        : answer helpfully from context; never abstains.
  * grounded_strict : answer only from context, cite chunk numbers, and
                      abstain with the exact ABSTAIN marker when the
                      context does not contain the answer.
  * concise         : one to two sentences, context only, abstains.

For live backends the variant is expressed through the system prompt and
sampling settings. For the offline backend the same intent is expressed
through extractive-answer parameters (sentence budget and abstain
threshold), so every variant behaves differently and measurably in all
three backend modes.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from trulens.core.otel.instrument import instrument
from trulens.otel.semconv.trace import SpanAttributes

from . import config, llm
from .embeddings import Embedder
from .vector_store import PineconeLocalStore


@dataclass(frozen=True)
class PromptVariant:
    name: str
    system_prompt: str
    temperature: float
    max_tokens: int
    offline_max_sentences: int
    offline_abstain_threshold: float | None  # None means never abstain


_ABSTAIN_INSTRUCTION = (
    "If the context does not contain the information needed to answer, reply "
    f"with exactly: {config.ABSTAIN_TEXT}"
)

VARIANTS: Dict[str, PromptVariant] = {
    "baseline": PromptVariant(
        name="baseline",
        system_prompt=(
            "You are the Cordwell Home & Hardware knowledge assistant. Answer "
            "the customer's question using the provided context. Be helpful "
            "and complete."
        ),
        temperature=0.7,
        max_tokens=400,
        offline_max_sentences=3,
        offline_abstain_threshold=None,
    ),
    "grounded_strict": PromptVariant(
        name="grounded_strict",
        system_prompt=(
            "You are the Cordwell Home & Hardware knowledge assistant. Answer "
            "ONLY with facts stated in the numbered context blocks. After each "
            "fact, cite the block you used, like [2]. Do not use outside "
            "knowledge. " + _ABSTAIN_INSTRUCTION
        ),
        temperature=0.0,
        max_tokens=400,
        offline_max_sentences=3,
        offline_abstain_threshold=0.30,
    ),
    "concise": PromptVariant(
        name="concise",
        system_prompt=(
            "You are the Cordwell Home & Hardware knowledge assistant. Answer "
            "in one or two short sentences using only the provided context. "
            + _ABSTAIN_INSTRUCTION
        ),
        temperature=0.2,
        max_tokens=120,
        offline_max_sentences=1,
        offline_abstain_threshold=0.30,
    ),
}


def format_context_block(matches: List[Dict]) -> str:
    """Render retrieved chunks as numbered blocks the model can cite.

    Each block carries its source title and effective date, which lets the
    grounded_strict variant cite sources and lets a human reading the
    prompt spot a stale document instantly.
    """
    blocks = []
    for i, m in enumerate(matches, start=1):
        header = f"[{i}] {m['title']} (doc: {m['doc_id']}, effective: {m['effective_date']})"
        blocks.append(f"{header}\n{m['text']}")
    return "\n\n".join(blocks)


class RagPipeline:
    """Retrieval-augmented answering over the Cordwell index.

    The three instrumented methods (retrieve, generate, answer) are the
    spans TruLens records. `retrieve` is tagged as a RETRIEVAL span with
    its query text and returned contexts, which is what lets the
    context-relevance and groundedness metrics find their inputs.
    """

    def __init__(
        self,
        embedder: Embedder,
        store: PineconeLocalStore,
        variant: PromptVariant,
        top_k: int = 5,
    ):
        self.embedder = embedder
        self.store = store
        self.variant = variant
        self.top_k = top_k
        self.last_matches: List[Dict] = []

    @instrument(
        span_type=SpanAttributes.SpanType.RETRIEVAL,
        attributes={
            SpanAttributes.RETRIEVAL.QUERY_TEXT: "question",
            SpanAttributes.RETRIEVAL.RETRIEVED_CONTEXTS: "return",
        },
    )
    def retrieve(self, question: str) -> List[str]:
        """Retrieve top_k context chunks for a question.

        Contract:
          * Embed the question with self.embedder.
          * Query self.store.query_top_k(vector, top_k=self.top_k).
          * Save the full match dicts on self.last_matches (the eval
            harness and the API sources field read them).
          * Return the list of chunk texts, best match first.
        Keep the @instrument decorator exactly as-is: it is what records
        the retrieval span for TruLens.
        """
        # TODO(Task 9a): implement retrieval.
        raise NotImplementedError("TODO Task 9a: retrieve")


    @instrument()
    def generate(self, question: str, contexts: List[str]) -> str:
        """Produce an answer from the question and retrieved contexts.

        Contract:
          * offline backend: call offline_extractive_answer with this
            variant's offline_max_sentences and offline_abstain_threshold,
            and return the text.
          * lmstudio / ollama: build messages = [system, user] where the
            system prompt is self.variant.system_prompt and the user
            content combines the question with
            format_context_block(self.last_matches), then call
            chat_completion with this variant's temperature, max_tokens,
            and backend.
          * Unknown backends must have already raised in llm; do not add
            fallbacks here.
        """
        # TODO(Task 9b): implement generation across the three backends.
        raise NotImplementedError("TODO Task 9b: generate")


    @instrument()
    def answer(self, question: str) -> str:
        contexts = self.retrieve(question)
        return self.generate(question, contexts)
