"""Pinecone Local wrapper.

One class owns every interaction with the vector database: index lifecycle,
batched upserts with a client-side metadata size guard, and query
normalization into plain dictionaries the rest of the codebase can consume
without knowing anything about the Pinecone SDK.

SDK notes (pinecone 9.x, verified against the installed package):
  * Pinecone(api_key=..., host=...) targets Pinecone Local when host points
    at http://localhost:5080. Any api_key string works locally.
  * Index.upsert is keyword-only: index.upsert(vectors=batch). Passing the
    batch positionally is a TypeError, which surprises people migrating
    old snippets.
  * Each index gets its own data-plane host (localhost:5081 and up).
    describe_index(name).host tells you where; Pinecone Local speaks plain
    HTTP, so the host string must carry an http:// scheme.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from . import config
from .chunking import Chunk


class PineconeLocalStore:
    def __init__(
        self,
        host: str = config.PINECONE_HOST,
        index_name: str = config.INDEX_NAME,
        dim: int = config.EMBED_DIM,
        api_key: str = config.PINECONE_API_KEY,
    ):
        self.host = host
        self.index_name = index_name
        self.dim = dim
        self.api_key = api_key
        self.pc = None
        self.index = None

    # ------------------------------------------------------------------
    # Connection and index lifecycle
    # ------------------------------------------------------------------
    def connect(self):
        """Create the control-plane client. Cheap; no network call yet."""
        from pinecone import Pinecone  # lazy: keeps unit tests import-light

        self.pc = Pinecone(api_key=self.api_key, host=self.host)
        return self.pc

    def _data_plane_host(self) -> str:
        """Ask the control plane where this index lives, and make sure the
        answer carries an http:// scheme, because Pinecone Local has no TLS."""
        desc = self.pc.describe_index(self.index_name)
        host = desc.host if hasattr(desc, "host") else desc["host"]
        host = f"http://{host.split('://')[-1]}"  # Pinecone Local returns "localhost:5081" without scheme
        return str(host)

    def ensure_fresh_index(self):
        """Delete-and-recreate the index so every ingest starts clean.

        Fine for a lab and for many batch-rebuild production patterns.
        (An incremental refresh strategy is a stretch goal.)
        """
        from pinecone import ServerlessSpec

        if self.pc is None:
            self.connect()
        if self.pc.has_index(self.index_name):
            self.pc.delete_index(self.index_name)
        self.pc.create_index(
            name=self.index_name,
            dimension=self.dim,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1"),
            vector_type="dense",
        )
        self.index = self.pc.Index(host=self._data_plane_host())
        return self.index

    def connect_existing_index(self):
        """Attach to an already-populated index (what the serving API does).
        Raises if the index does not exist, because serving an empty or
        missing index should be loud, not quiet."""
        if self.pc is None:
            self.connect()
        if not self.pc.has_index(self.index_name):
            raise RuntimeError(
                f"Index {self.index_name!r} does not exist. Run ingest first."
            )
        self.index = self.pc.Index(host=self._data_plane_host())
        return self.index

    # ------------------------------------------------------------------
    # Writing
    # ------------------------------------------------------------------
    @staticmethod
    def build_metadata(chunk: Chunk) -> Dict[str, Any]:
        """Metadata stored alongside each vector. The chunk text itself
        rides along so retrieval can return usable context without a second
        lookup. Everything here counts against the 40 KB metadata limit."""
        return {
            "text": chunk.text,
            "doc_id": chunk.doc_id,
            "doc_family": chunk.doc_family,
            "title": chunk.title,
            "category": chunk.category,
            "effective_date": chunk.effective_date,
            "seq": chunk.seq,
        }

    @staticmethod
    def metadata_size_bytes(metadata: Dict[str, Any]) -> int:
        return len(json.dumps(metadata, ensure_ascii=False).encode("utf-8"))

    def upsert_chunks(
        self,
        chunks: List[Chunk],
        vectors: List[List[float]],
        batch_size: int = 100,
    ) -> int:
        """Embed-free upsert: chunks and their precomputed vectors go in
        together.

        Contract:
          * Raise ValueError if len(chunks) != len(vectors).
          * Build metadata with self.build_metadata (provided) and check
            self.metadata_size_bytes(metadata) against
            config.METADATA_LIMIT_BYTES BEFORE upserting; on violation,
            raise ValueError naming the offending chunk_id and the size,
            so the failure is diagnosable from the message alone.
          * Upsert in batches of batch_size records.
          * The pinecone client is keyword-only: index.upsert(vectors=batch).
          * Each record is {"id": chunk_id, "values": vector,
            "metadata": metadata}.
          * Return the total number of records upserted.
        """
        # TODO(Task 6): implement guarded, batched upsert. Passing the
        # batch positionally is the classic SDK mistake; the tests fake
        # index enforces the real client shape.
        raise NotImplementedError("TODO Task 6: upsert_chunks")


    # ------------------------------------------------------------------
    # Reading
    # ------------------------------------------------------------------
    def query_top_k(
        self,
        vector: List[float],
        top_k: int = 5,
        flt: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """Query the index and normalize matches to plain dicts.

        Contract:
          * Call self.index.query(vector=..., top_k=..., include_metadata=True).
          * Matches may arrive attribute-style (match.id, match.score,
            match.metadata) or dict-style; handle both.
          * Return a list of dicts with keys: id, score (float), text,
            doc_id, doc_family, title, category, effective_date, seq.
            Missing metadata fields become "" (or 0 for seq).
        """
        # TODO(Task 7): implement query + normalization so downstream
        # code never touches SDK response objects.
        raise NotImplementedError("TODO Task 7: query_top_k")


    def stats(self) -> Dict[str, Any]:
        """Normalize describe_index_stats() to a plain dict. The SDK
        returns a response object; we accept to_dict(), mapping, or
        attribute style so callers and tests never care which."""
        s = self.index.describe_index_stats()
        if hasattr(s, "to_dict"):
            return s.to_dict()
        if isinstance(s, dict):
            return dict(s)
        return {k: v for k, v in vars(s).items() if not k.startswith("_")}
