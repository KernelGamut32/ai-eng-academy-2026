"""Load the Cordwell document corpus from disk.

Responsibilities:
  1. Read every markdown file in the corpus directory, surviving files that
     are not clean UTF-8 (real corpora always contain a few).
  2. Parse the YAML-ish front matter block into document metadata.
  3. Filter superseded document versions so only the latest document per
     doc_family reaches the index.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Tuple

from . import config


@dataclass
class Document:
    doc_id: str
    doc_family: str
    title: str
    category: str
    effective_date: str  # ISO yyyy-mm-dd; lexical sort equals date sort
    version: str
    path: str
    body: str
    meta: Dict[str, str] = field(default_factory=dict)


def read_text_tolerant(path: Path) -> str:
    """Read a text file that may not be valid UTF-8.

    Contract:
      * Try UTF-8 first, tolerating a leading BOM.
      * On UnicodeDecodeError, fall back to Windows-1252 (cp1252).
      * As a last resort, decode UTF-8 with replacement characters so
        ingestion never dies on a single bad file.
      * Return the decoded string.
    """
    # TODO(Task 2): implement tolerant decoding. One corpus file will
    # refuse a plain UTF-8 read; that file is the acceptance test.
    raise NotImplementedError("TODO Task 2: read_text_tolerant")



def parse_front_matter(text: str) -> Tuple[Dict[str, str], str]:
    """Split a document into (metadata dict, body).

    Front matter is a leading block delimited by lines containing only
    '---', with simple 'key: value' pairs inside. This is a deliberately
    small hand parser: the corpus schema is flat, so pulling in a YAML
    library would be incidental complexity.
    """
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text

    meta: Dict[str, str] = {}
    body_start = len(lines)
    for i, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            body_start = i + 1
            break
        if ":" in line:
            key, _, value = line.partition(":")
            meta[key.strip()] = value.strip().strip('"')
    body = "\n".join(lines[body_start:]).strip()
    return meta, body


def load_corpus(corpus_dir: Path | None = None) -> List[Document]:
    """Load every .md document in the corpus directory (except MANIFEST.md)."""
    corpus_dir = corpus_dir or config.CORPUS_DIR
    docs: List[Document] = []
    for path in sorted(corpus_dir.glob("*.md")):
        if path.name.upper().startswith("MANIFEST"):
            continue
        text = read_text_tolerant(path)
        meta, body = parse_front_matter(text)
        docs.append(
            Document(
                doc_id=meta.get("doc_id", path.stem),
                doc_family=meta.get("doc_family", path.stem),
                title=meta.get("title", path.stem),
                category=meta.get("category", "uncategorized"),
                effective_date=meta.get("effective_date", "1970-01-01"),
                version=meta.get("version", "1.0"),
                path=str(path),
                body=body,
                meta=meta,
            )
        )
    return docs


def select_active_documents(docs: List[Document]) -> List[Document]:
    """Keep only the newest document per doc_family.

    Contract:
      * Group documents by doc_family.
      * Within a family, keep the one with the latest effective_date
        (ISO strings compare correctly); tie-break on version, then
        doc_id, so the choice is deterministic.
      * Preserve the original corpus order of the kept documents.
      * Documents that are alone in their family are always kept.
    """
    # TODO(Task 3): implement version selection. Two returns policies
    # share a family; only one may survive, and it must be the 2026 one.
    raise NotImplementedError("TODO Task 3: select_active_documents")

