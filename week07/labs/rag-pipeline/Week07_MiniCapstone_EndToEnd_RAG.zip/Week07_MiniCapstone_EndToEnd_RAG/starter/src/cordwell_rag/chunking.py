"""Turn documents into index-ready chunks.

Design goals:
  * Respect document structure first: split on '## ' section headings so a
    chunk is usually one coherent topic.
  * Enforce a hard size ceiling second: any section longer than
    CHUNK_MAX_CHARS is packed by paragraphs, and any single paragraph
    longer than the ceiling is sliced by characters with overlap. Real
    corpora always contain at least one wall-of-text document with no
    structure at all, and Pinecone enforces a 40 KB metadata limit per
    vector, so "split on headings" alone is not a chunker.
  * Deduplicate by normalized content hash, because real corpora also
    always contain at least one copy-pasted duplicate.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import List, Tuple

from . import config
from .corpus_loader import Document


@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    doc_family: str
    title: str
    category: str
    effective_date: str
    seq: int
    text: str


def split_into_sections(body: str) -> List[str]:
    """Split a markdown body on level-2 headings, keeping each heading with
    its section text. A document with no '## ' headings comes back as a
    single section."""
    sections: List[str] = []
    current: List[str] = []
    for line in body.splitlines():
        if line.startswith("## ") and current:
            sections.append("\n".join(current).strip())
            current = [line]
        else:
            current.append(line)
    if current:
        sections.append("\n".join(current).strip())
    return [s for s in sections if s]


def _pack_paragraphs(section: str, max_chars: int) -> List[str]:
    """Greedily pack paragraphs into pieces no longer than max_chars.
    Single paragraphs longer than max_chars pass through intact; the
    caller slices them."""
    paragraphs = [p.strip() for p in section.split("\n\n") if p.strip()]
    pieces: List[str] = []
    buffer = ""
    for para in paragraphs:
        candidate = f"{buffer}\n\n{para}" if buffer else para
        if len(candidate) <= max_chars:
            buffer = candidate
        else:
            if buffer:
                pieces.append(buffer)
            buffer = para
    if buffer:
        pieces.append(buffer)
    return pieces


def _slice_with_overlap(text: str, max_chars: int, overlap: int) -> List[str]:
    """Character-slice a paragraph that is too long to keep whole. Each
    slice starts `overlap` characters before the previous slice ended, so
    a fact that straddles a cut point survives in at least one slice."""
    if len(text) <= max_chars:
        return [text]
    step = max_chars - overlap
    if step <= 0:
        raise ValueError("CHUNK_OVERLAP_CHARS must be smaller than CHUNK_MAX_CHARS")
    slices = []
    start = 0
    while start < len(text):
        slices.append(text[start : start + max_chars])
        if start + max_chars >= len(text):
            break
        start += step
    return slices


def chunk_document(
    doc: Document,
    max_chars: int = config.CHUNK_MAX_CHARS,
    overlap: int = config.CHUNK_OVERLAP_CHARS,
) -> List[Chunk]:
    """Split one document into chunks no longer than max_chars.

    The three helpers above are provided and tested:
      * split_into_sections(body) -> heading-delimited sections
      * _pack_paragraphs(section, max_chars) -> greedy paragraph packing
      * _slice_with_overlap(text, max_chars, overlap) -> hard slicing

    Contract:
      * Compose the helpers so that EVERY returned chunk satisfies
        len(chunk.text) <= max_chars, no matter how the document is
        shaped: headings, no headings, giant single paragraphs.
      * Number chunks sequentially per document: chunk ids come from
        make_chunk (provided), which formats doc_id::cNNN.
      * Skip empty pieces.
    """
    # TODO(Task 4): compose the provided helpers into a chunker whose
    # size guarantee has no exceptions. One corpus document is shaped to
    # break any shortcut.
    raise NotImplementedError("TODO Task 4: chunk_document")



def normalize_for_hash(text: str) -> str:
    """Case-fold and collapse whitespace so cosmetic differences do not
    defeat duplicate detection."""
    return " ".join(text.lower().split())


def content_hash(text: str) -> str:
    return hashlib.blake2b(normalize_for_hash(text).encode("utf-8"), digest_size=16).hexdigest()


def dedupe_chunks(chunks: List[Chunk]) -> Tuple[List[Chunk], int]:
    """Drop chunks whose normalized text content is an exact duplicate.

    content_hash (provided) hashes normalized text.

    Contract:
      * First occurrence wins; later duplicates are dropped.
      * Return (kept_chunks, dropped_count).
      * Order of kept chunks is unchanged.
    """
    # TODO(Task 5): implement content dedupe. The corpus contains one
    # migrated copy of a manual; its chunks must collapse onto the first
    # copy seen.
    raise NotImplementedError("TODO Task 5: dedupe_chunks")



def chunk_corpus(docs: List[Document]) -> Tuple[List[Chunk], int]:
    """Chunk every document, then dedupe across the whole corpus."""
    all_chunks: List[Chunk] = []
    for doc in docs:
        all_chunks.extend(chunk_document(doc))
    return dedupe_chunks(all_chunks)
