# Instructor Walkthrough, Part 4: The Sweep, Champion Selection, and the Handoff

Line-by-line through experiments.py, plus the CLI commands that drive it and the deployment-shaped artifact it produces.

## The frame to set before any code

Week 7's theme is that ML systems are configuration plus process, not just code. This module is the theme made concrete: six configurations of the SAME code, evaluated identically, logged to MLflow, and then a machine (not a meeting) picks the winner against criteria a human wrote down in advance. The champion is chosen by a pure function anyone can read, test, and argue with. That last property is the point: the argument about what "best" means happens in a code review of the criteria, before results exist, instead of in a results meeting where everyone already has a favorite.

## DEFAULT_SWEEP

Six dicts: three prompt variants crossed with top_k of 3 and 5. Small on purpose. Two axes with a handful of levels already produce a leaderboard with a story, and every additional axis multiplies runtime by its level count. The sweep list is data, not code, so a team's fourth variant (a stretch goal) joins the sweep by appending a dict.

## ChampionCriteria

A dataclass holding two dicts, and the docstring is the part to read aloud in class because it is a values statement wearing a type annotation.

Gates are strict eligibility rules, pass or fail: groundedness at least 0.60 (below this the pipeline is decorating hallucinations), retrieval_hit_rate at least 0.70 (below this, right answers are luck), abstain_recall at least 0.66 (below this, the pipeline answers questions it has no business answering). The 0.66 is calibrated to the eval set's construction: three unanswerable questions, and the gate demands at least two refused. One of the three is deliberately nearly impossible for lexical abstention (the price question retrieves the right product's spec chunk, which contains no price), so a gate at 1.0 would fail every offline configuration for a designed reason rather than a quality reason. Gates should measure the system, not the trap.

Weights rank the survivors: groundedness 0.40, ROUGE 0.30, answer relevance 0.30. Groundedness weighted highest is a policy choice with a retail justification stated right in the docstring: a confidently wrong answer at the returns desk costs more than a slightly less fluent right one. Expect a team to challenge the weights during demos; that challenge is the exercise working.

## run_sweep

Setup: tracking URI and experiment name into mlflow, output dirs ensured. Then per configuration: build the variant's pipeline, open an MLflow run named `variant-kN` (the same string used as the TruLens app_version, which is the join key between the two systems' views), and log three families of things.

Params answer "could someone reproduce this run": variant, top_k, backend, model (the literal string "extractive" in offline mode, so nobody mistakes offline numbers for model numbers), embedding backend, chunking constants, index name, temperature, eval set size. The habit to name for the room: log the parameters you would need to be told if a colleague asked you to reproduce the run from scratch, and log them at run time, not from memory afterwards.

Then `run_evaluation` does the actual work (Part 3), and its aggregate dict is logged wholesale as metrics: the deterministic family and the TruLens triad side by side in one row of the comparison table.

Artifacts capture what params cannot: the per-question results as a CSV (every question, every answer, every score, for the run's autopsy) and the exact system prompt text. Logging the prompt as an artifact is a small act of professional honesty: prompts are code, they drift, and "which prompt produced these numbers" should never require archaeology.

The console line per run prints the headline metrics so the sweep narrates itself while it runs; six runs of 18 questions in offline mode complete in well under a minute.

## pick_champion (student Task 11)

Pure function: dataframe in, verdict dict out, no MLflow import, no network. mlflow.search_runs returns a dataframe whose metric columns are named `metrics.groundedness` and so on; this function only ever sees that frame, which is why its tests run on a hand-built dataframe on any machine.

Stage one, gates. For each gate, a boolean mask requires the column to exist, be non-null, and meet the threshold; a run that never logged a gated metric fails that gate, because unmeasured is not the same as passing. Failures are counted per gate as the masks are ANDed, and if nothing survives, the verdict is `no_eligible_run` carrying those counts, which turns "nothing won" from a shrug into a diagnosis: the gate_failures dict says WHICH standard the field failed.

Stage two, composite. The weighted sum over the criteria weights, missing values as zero. Survivors are ranked by composite, ties broken by groundedness, then run_id ascending, making selection fully deterministic: same store, same verdict, every time. Determinism here is not pedantry; a champion selector that could return different winners on re-run would be a coin flip with extra steps.

The verdict dict carries the run id and name, the composite, the params and metrics that justify the choice, and the gate failure counts. Everything a human reviewer or a deployment pipeline needs, in one JSON-serializable object.

## select_champion

The impure wrapper: pulls the runs dataframe from MLflow, calls pick_champion, and on success tags the winning run (`champion: true` plus a criteria note) and writes `artifacts/champion.json` with the verdict. The tag makes the winner findable in the MLflow UI; the JSON is the handoff artifact.

Worth pausing on what champion.json IS: this pipeline's configuration is the deployable unit; there are no trained weights, so the Week 7 model registry pattern (register a model version, alias it `@champion`, load `models:/name@champion`) has no model to register. Writing the winning configuration to a versioned artifact is the same promotion pattern expressed for a configuration-shaped system. When a student asks "is this what real deployment looks like," the honest answer is: the SHAPE is exactly right (evaluate, gate, select, tag, publish an artifact a deployment consumes), and in a weights-shaped system the registry alias would replace the JSON file.

## The sweep's actual story (offline, hash embeddings)

Run it before class and have the comparison view already open. The leaderboard reads, from the verified reference run: all six configurations hit retrieval perfectly (hit rate 1.0, MRR 0.967, on a corpus this size with calibrated questions, retrieval is not the discriminator). The baselines post competitive ROUGE (0.376 to 0.382) and the best answer relevance, and both FAIL the abstain_recall gate at exactly 0.000: they never refuse anything, including the three questions with no answer in the corpus. grounded_strict and concise both bank 0.667 abstain recall; grounded_strict-k3 takes the composite at 0.5251 on the strength of groundedness 0.749.

The narration that lands: the most fluent configuration lost on a safety gate, and no one in the room had to argue about it after the fact, because the standard was written down before the sweep ran. That sentence is the whole module.

## Retrofit and re-baseline notes

If chunking constants change, ingest counts and every downstream number shift slightly; the README's expected-results table is the re-baseline reference and the story shape (baselines gated out, grounded_strict wins) should survive parameter drift. If the cohort switches EMBEDDING_BACKEND to st for the sweep, re-baseline the offline abstention threshold first with the calibration method in the experiments guide; a threshold tuned for lexical scores applied to semantic scores will abstain on the wrong things, and the gates will correctly flag it.
