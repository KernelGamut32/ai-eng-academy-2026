# Instructor Notes: The Four Curveballs (INSTRUCTOR ONLY)

Do not distribute this file to teams. HINTS.md contains a symptom-keyed section that lets students self-rescue without spoilers; this file is your complete map of what was planted, where, why, and what to do with each in the room.

The corpus is a working miniature of a real enterprise document collection, which means it misbehaves in four specific, deliberate ways. Each curveball targets one student task, produces one recognizable symptom, and carries one production lesson. All four are covered by tests, so a team that skips the thinking still cannot ship the bug.

## CB1a: The byte-identical archived manual (targets Task 5, dedupe)

**Planted:** `archive_vexline_drill_manual.md` (doc_id `man-vexline-vx20dd1-archive`) has a byte-identical body to `manual_vexline_drill.md` (doc_id `man-vexline-vx20dd1`). Different front matter, different doc_family, same content: a content-migration leftover.

**Symptom before the fix:** chunk counts about 6 high; the same drill text appears twice in retrieval results for drill questions.

**Symptom after the fix, and the deeper lesson:** dedupe drops 6 chunks, and here is the part worth a whiteboard: because dedupe is first-wins and corpus load order is alphabetical by filename, `archive_...` loads BEFORE `manual_...`, so the ARCHIVE'S chunks survive and the primary manual's chunks are the duplicates that get dropped. Every drill citation the API returns carries the archive doc_id. Retrieval quality is unaffected (identical text); provenance is affected. The eval set accepts either doc_id for the two drill questions for exactly this reason.

**Discussion prompts:** Which copy SHOULD be canonical, and what rule would make it so (prefer non-archive families? prefer newest effective_date at dedupe time, not just at version-selection time?). What metadata is lost when a duplicate is dropped, and who downstream might have wanted it? In production, would you dedupe at ingest or at retrieval?

**Test referee:** `test_archived_duplicate_manual_is_deduped_in_real_corpus` asserts at least 5 dropped and exactly one surviving vexline doc_id.

## CB1b: The stale returns policy (targets Task 3, version selection)

**Planted:** `policy_returns_2024.md` and `policy_returns_2026.md` share doc_family `returns-policy`. The 2024 document states a 90 day standard window; 2026 states 30 days. The 2024 file reads as fully authoritative on its own; nothing in its body says "superseded."

**Symptom:** if both are ingested, returns questions retrieve whichever chunk scores higher, and the assistant sometimes answers "90 days" with a confident citation. The eval set's q01 expects 30 days.

**The lesson:** staleness is invisible at retrieval time; no error fires, the wrong answer is fluent and sourced. Version selection is a data-governance decision that must happen at ingest. Connect it forward: this is the same problem MLflow model aliases solve for models (Week 7 Module 02), expressed for documents.

**Live demo option (2 minutes):** comment out the `select_active_documents` call in cmd_ingest, re-ingest, ask the returns question through /answer, and watch the stale answer arrive with a straight face. Restore, re-ingest, ask again.

**Test referee:** `test_select_active_documents_keeps_latest_per_family` (30 active, 2024 absent).

## CB2: The heading-free 41KB transcript (targets Task 4, chunking size guarantee)

**Planted:** `transcript_hotline_digest_0417.md` (doc_id `ops-hotline-digest-0417`): a realistic support-hotline digest, 41,338 bytes of body, ZERO markdown headings, and its longest paragraph is 2,528 characters, over the 1,800 character chunk limit all by itself.

**Why it is shaped exactly this way:** heading-only chunkers produce one 41KB chunk (blows the 40,960 byte Pinecone metadata limit, which the upsert guard refuses by name). Heading-plus-paragraph chunkers survive most of the file but ship the 2,528 character paragraph oversized. Only the full composition (sections, then packing, then slicing with overlap) passes. The trap has two layers so partial solutions fail visibly too.

**Symptom:** ingest raises the metadata-guard ValueError naming a `ops-hotline-digest-0417::cNNN` chunk, or the chunking test fails on the length assertion.

**The lesson:** the metadata guard and the chunker are a contract pair; and real corpora contain machine-generated, structure-free documents that break structure-assuming code. Bonus discussion: the transcript is also the most conversational document in the corpus, which is why the hash embedder has a stopword list (without it, chatty text scores well against everything). If a sharp student asks about the stopword set, this document is the reason.

**Test referee:** `test_real_transcript_curveball_stays_within_limits` (asserts the body really is over 40KB, then asserts every chunk fits).

## CB3: The cp1252 buying guide (targets Task 2, tolerant reading)

**Planted:** `guide_cordless_platforms.md` (doc_id `guide-cordless-platforms`) is written in Windows-1252, not UTF-8: smart quotes at bytes 0x93 and 0x94, an apostrophe at 0x92, and an accented character at 0xE9. A plain `read_text()` raises UnicodeDecodeError on it.

**Symptom:** ingest (or the loader test) dies with `UnicodeDecodeError ... byte 0x93` before any other progress.

**The lesson:** encoding failures are the single most common way real document ingestion dies on day one, and the fix is a policy (try strict, fall back explicitly, replace as last resort), not a one-off patch. The file's content is genuinely useful corpus material (the 20V vs 40V platform guide), so excluding it is a worse fix than reading it, and one eval-adjacent question (the transcript's platform-consult call cross-references the same topic) rewards having it indexed.

**Verification note for your pre-flight:** `file corpus/guide_cordless_platforms.md` reports it as non-UTF-8 text; `python3 -c "open('corpus/guide_cordless_platforms.md', encoding='utf-8').read()"` raises; with `encoding='cp1252'` it reads clean. Verified at build time.

**Test referee:** `test_read_text_tolerant_handles_cp1252` (synthetic bytes) and `test_load_corpus_reads_all_documents_including_cp1252_file` (the real file, 31 documents).

## Sequencing advice

Teams typically hit CB3 first (it kills the first ingest attempt), CB2 second (first successful chunking run), and CB1a and CB1b only if they read their ingest counts or fail the eval questions. Resist rescuing early: the symptom-keyed section of HINTS.md exists so the rescue is self-service. The one place to intervene proactively is a team at M2 whose ingest printout shows 31 active documents or zero dropped duplicates and who has not noticed; ask them to read their own numbers aloud, then walk away.

If time compresses, CB1b (stale policy) is the one to force into every team's demo conversation: it is the curveball whose production analogue does the most damage in the wild.
