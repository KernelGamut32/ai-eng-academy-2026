"""Central configuration for the Cordwell RAG mini-capstone.

Every tunable lives here or in the .env file at the project root.
Nothing else in the codebase reads os.environ directly, which keeps
configuration discoverable and testable.
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

# ---------------------------------------------------------------------------
# Project layout
#
# This file lives at <PROJECT_ROOT>/solution/src/cordwell_rag/config.py
# (or <PROJECT_ROOT>/starter/src/cordwell_rag/config.py). Walking three
# parents up from the package directory lands on the project root in both
# cases, so corpus, data, and artifacts resolve identically for starter
# and solution code.
# ---------------------------------------------------------------------------
PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parents[2]

CORPUS_DIR = Path(os.getenv("CORPUS_DIR", PROJECT_ROOT / "corpus"))
DATA_DIR = Path(os.getenv("DATA_DIR", PROJECT_ROOT / "data"))
EVAL_SET_PATH = Path(os.getenv("EVAL_SET_PATH", DATA_DIR / "eval" / "eval_set.jsonl"))
ARTIFACTS_DIR = Path(os.getenv("ARTIFACTS_DIR", PROJECT_ROOT / "artifacts"))

# Load .env from the project root once, at import time. Values already set
# in the real environment win over .env values (override=False), so
# `LAB_BACKEND=lmstudio python -m cordwell_rag.cli ...` behaves as expected.
load_dotenv(PROJECT_ROOT / ".env", override=False)

# ---------------------------------------------------------------------------
# LLM backend selection (standing cohort pattern)
#
# offline  : deterministic extractive answering, no server required
# lmstudio : LM Studio local server, OpenAI-compatible, port 1234
# ollama   : Ollama local server, OpenAI-compatible, port 11434
#
# There is intentionally no silent fallback. If you select a live backend
# and its server is down, the code raises so you notice.
# ---------------------------------------------------------------------------
BACKEND_MODE = os.getenv("LAB_BACKEND", "ollama")
LOCAL_MODEL = os.getenv("LAB_MODEL", "gpt-oss:20b")  # confirm exact pulled tag per cohort machine

LMSTUDIO_BASE_URL = os.getenv("LMSTUDIO_BASE_URL", "http://localhost:1234/v1")
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1")
LLM_TIMEOUT_S = float(os.getenv("LLM_TIMEOUT_S", "60"))
LLM_MAX_RETRIES = int(os.getenv("LLM_MAX_RETRIES", "0"))

# ---------------------------------------------------------------------------
# Embeddings
#
# st   : sentence-transformers all-MiniLM-L6-v2 (384-dim), needs the model
#        cached locally (it is, from the Week 5 labs)
# hash : deterministic hashed bag-of-words (384-dim), zero downloads,
#        used by the unit tests and by fully offline machines
#
# Both produce 384-dim vectors so the Pinecone index dimension never changes
# when you switch.
# ---------------------------------------------------------------------------
EMBEDDING_BACKEND = os.getenv("EMBEDDING_BACKEND", "st")
ST_MODEL_NAME = str(Path(os.getenv("ST_MODEL_NAME", "~/models/all-MiniLM-L6-v2")).expanduser().resolve())
EMBED_DIM = 384

# ---------------------------------------------------------------------------
# Pinecone Local
# ---------------------------------------------------------------------------
PINECONE_HOST = os.getenv("PINECONE_HOST", "http://localhost:5080")
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY", "pclocal")  # any string works for Pinecone Local
INDEX_NAME = os.getenv("PINECONE_INDEX_NAME", "cordwell-kb")

# Pinecone enforces a 40 KB limit on the metadata attached to each vector.
# We enforce it client-side too, so a bad chunk fails loudly with a chunk id
# instead of a mid-batch server error.
METADATA_LIMIT_BYTES = 40960

# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------
CHUNK_MAX_CHARS = int(os.getenv("CHUNK_MAX_CHARS", "1800"))
CHUNK_OVERLAP_CHARS = int(os.getenv("CHUNK_OVERLAP_CHARS", "200"))

# ---------------------------------------------------------------------------
# MLflow (containerized; host port 5001 because macOS AirPlay squats on 5000)
# ---------------------------------------------------------------------------
MLFLOW_TRACKING_URI = os.getenv("MLFLOW_TRACKING_URI", "http://localhost:5001")
MLFLOW_EXPERIMENT_NAME = os.getenv("MLFLOW_EXPERIMENT_NAME", "wk7_mini_capstone_rag_sweep")

# ---------------------------------------------------------------------------
# TruLens
# ---------------------------------------------------------------------------
TRULENS_DB_URL = os.getenv(
    "TRULENS_DB_URL", f"sqlite:///{ARTIFACTS_DIR / 'trulens_capstone.sqlite'}"
)
TRULENS_APP_NAME = os.getenv("TRULENS_APP_NAME", "cordwell_rag")
TRULENS_DASHBOARD_PORT = int(os.getenv("TRULENS_DASHBOARD_PORT", "8501"))

# ---------------------------------------------------------------------------
# Serving API
# ---------------------------------------------------------------------------
API_HOST = os.getenv("API_HOST", "127.0.0.1")
API_PORT = int(os.getenv("API_PORT", "8000"))

# ---------------------------------------------------------------------------
# Abstention contract
#
# When the retrieved context does not support an answer, the pipeline must
# reply with text containing this exact marker. Prompts for live backends
# instruct the model to emit it verbatim; the offline extractive answerer
# emits it directly; evaluation code detects it with is_abstention().
# ---------------------------------------------------------------------------
ABSTAIN_MARKER = "NOT ENOUGH CONTEXT"
ABSTAIN_TEXT = (
    f"{ABSTAIN_MARKER}: I do not have enough information in the provided "
    "context to answer that question."
)


def ensure_dirs() -> None:
    """Create writable output directories if they do not exist."""
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    (DATA_DIR / "eval").mkdir(parents=True, exist_ok=True)
