# Instructor Walkthrough, Part 1: Configuration and Ingestion

Line-by-line, in plain language, through config.py, corpus_loader.py, and chunking.py of the solution package. Written so you can narrate any line cold if a student asks "why is that there." Parts 2 to 4 cover the store and API, generation and evaluation, and experiments.

## config.py: one place for every knob

The module docstring makes a promise the rest of the codebase keeps: nothing else reads os.environ. Why that matters: when a student asks "where do I change the chunk size," the answer is always the same file, and when a test wants to force offline mode, it sets two environment variables and knows nothing else is sneaking configuration in from somewhere.

```python
PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parents[2]
```

`__file__` is Python's name for "the path of this very file." `.resolve()` turns it into an absolute path with symlinks unwound, and `.parent` is the folder holding it: the cordwell_rag package directory. `parents[2]` walks three levels up: from cordwell_rag, past src, past starter (or solution), landing on the project root. This is the trick that lets starter and solution code share one corpus and one artifacts folder: both packages sit exactly three levels below the root, so both compute the same PROJECT_ROOT.

```python
load_dotenv(PROJECT_ROOT / ".env", override=False)
```

python-dotenv reads the .env file and copies its values into the process environment. `override=False` is the subtle half: values already present in the real environment win. That is why `LAB_BACKEND=lmstudio ./run.sh starter serve` works even when .env says offline: the shell's value was there first, and dotenv respectfully declines to stomp it.

The backend block defines the standing cohort pattern: `BACKEND_MODE` from `LAB_BACKEND`, defaulting to offline; `LOCAL_MODEL` from `LAB_MODEL`, defaulting to the cohort Gemma tag. The comment about "no silent fallback" is a design commitment the llm module enforces, and it is worth saying aloud in class: a pipeline that quietly swaps to a different model when its first choice is down will happily generate numbers that compare nothing to nothing.

`EMBED_DIM = 384` is not configurable, and that is deliberate: both embedding backends emit 384-wide vectors, so switching between them never requires rebuilding the index with a different dimension. The sentence-transformers model all-MiniLM-L6-v2 happens to be 384-wide; the hash embedder was simply built to match it.

`METADATA_LIMIT_BYTES = 40960` mirrors a real Pinecone rule: each vector can carry at most 40 KB of attached metadata. We enforce the limit on our side, before upserting, because a server-side rejection arrives mid-batch with an unhelpful message, while our client-side check names the exact chunk. One corpus document exists specifically to test whether this guard and the chunker cooperate.

The abstention contract at the bottom is the single most load-bearing constant in the project:

```python
ABSTAIN_MARKER = "NOT ENOUGH CONTEXT"
```

Every layer speaks it: the offline answerer emits it, live-backend prompts demand it verbatim, `is_abstention()` detects it, the evaluation harness scores it, and the abstain recall gate in champion selection counts it. When students ask why the marker is shouted in capitals, the honest answer is testability: an exact string that survives being embedded in a longer sentence is easy to detect reliably across three different backends.

## corpus_loader.py: reading the real world

The Document dataclass is a plain record: doc_id, doc_family, title, category, effective_date, version, path, body, and the raw meta dict. Two fields deserve narration. `doc_id` identifies one document; `doc_family` identifies a lineage of documents that supersede each other. The two returns policies share the family `returns-policy` but have different ids; that distinction is the entire basis of version selection.

### read_text_tolerant (student Task 2)

```python
raw = path.read_bytes()
for encoding in ("utf-8-sig", "cp1252"):
    try:
        return raw.decode(encoding)
    except UnicodeDecodeError:
        continue
return raw.decode("utf-8", errors="replace")
```

Read the bytes once; try to interpret them two ways; give up gracefully. "utf-8-sig" is ordinary UTF-8 with one extra courtesy: if the file starts with a byte order mark (an invisible marker some Windows editors prepend), it is silently absorbed instead of appearing as a ghost character at the start of the text. cp1252 is the old Windows character table; it is where "smart quotes" live, at byte values that are illegal in UTF-8, which is exactly why a file pasted out of an old Word document detonates a plain UTF-8 read. The guide_cordless_platforms.md file in the corpus is such a file, on purpose. The last line trades fidelity for survival: rather than let one hopeless file kill a 31-document ingest, decode it with replacement characters and move on. The explicitness matters: this is a decision, visible in code, not an accident.

### parse_front_matter

Each corpus file opens with a block between `---` lines containing `key: value` pairs. The parser is deliberately tiny: find the two delimiter lines, split each interior line on the first colon, strip whitespace and surrounding quotes. Students sometimes ask why we do not use a YAML library. The answer is a scoping lesson: the corpus schema is flat strings, a hand parser is fifteen honest lines, and a YAML dependency would import a hundred capabilities to use three. When the schema grows nesting, THAT is the day for the library.

### load_corpus

Walks `config.CORPUS_DIR` for `*.md`, sorted, skipping any file whose name starts with MANIFEST. Sorting matters more than it looks: it fixes corpus order across machines, which fixes chunk ids, which fixes what first-wins dedupe keeps. Determinism in ingestion is what makes "we got different results" a real signal instead of noise.

### select_active_documents (student Task 3)

```python
key = (doc.effective_date, doc.version, doc.doc_id)
```

Python compares tuples element by element, so this one line implements "newest date wins; same date, higher version wins; still tied, the doc_id string breaks it." The dates are ISO strings (2026-01-05), and ISO's whole reason for existing is that alphabetical order IS chronological order, so no date parsing is needed. The function then re-walks the original list keeping each document only if it is its family's winner, which preserves corpus order in the output.

The teaching moment: run ingest without this filter (comment out one line in cli.py) and ask the room what happens. Nothing crashes. Retrieval works. And any question about return windows now has two authoritative-looking answers in the index, one of them wrong by two years. The failure mode of skipping version selection is not an error message; it is confidently stale answers.

## chunking.py: the size guarantee

The Chunk dataclass carries everything the vector's metadata will need: chunk_id (formatted `doc_id::c000`, `::c001`, and so on by `make_chunk`), the document fields, seq, and text. Stable, predictable chunk ids make two-run diffs meaningful.

### The three provided helpers

`split_into_sections` splits the body on markdown headings (lines starting `## `), keeping each heading with its content. On a document with no headings at all, it returns the whole body as one giant section; that is not a bug, it is the honest answer, and handling it is the next helper's job.

`_pack_paragraphs` splits a section on blank lines and greedily packs consecutive paragraphs into pieces no longer than max_chars. Greedy means: keep adding paragraphs while they fit, emit, start fresh. Crucially, a SINGLE paragraph longer than max_chars cannot be packed smaller; it is emitted oversized, and the caller must deal with it.

`_slice_with_overlap` is the dealer: hard character slices of max_chars, each slice starting overlap characters before the previous one ended. The overlap is why a sentence straddling a slice boundary is still findable: its beginning lives in slice N and its entirety in slice N+1's head.

### chunk_document (student Task 4)

The composition: sections, packed within sections, sliced when packing could not help. The branch `if len(piece) <= max_chars` versus the slicing else IS the size guarantee, and the transcript document is its stress test: 41 KB of call-log prose, zero headings, with individual paragraphs over 2,500 characters. Heading-splitting yields one section; paragraph packing yields several pieces, some oversized; slicing finishes the job. Any chunker that handles only the happy shapes ships a chunk that the metadata guard in the store will refuse, and the refusal will name the chunk so the room can find this exact document.

### dedupe_chunks (student Task 5)

`content_hash` normalizes text (lowercase, collapsed whitespace) and hashes it; dedupe keeps the first chunk per hash and counts the rest. Six chunks vanish on the real corpus, all from the archived copy of the VexLine drill manual.

Here is the discussion gold, and it is worth five whole minutes at the board: WHICH copy survives? First wins, and corpus order is alphabetical by filename, and archive_vexline_drill_manual.md sorts before manual_vexline_drill.md. So the ARCHIVE'S chunks survive, carrying the archive's doc_id, and the primary manual's chunks are the ones dropped. Retrieval quality is untouched: the text is byte-identical. But every source citation the API returns for drill questions now says the archive id. The eval set accepts either id for exactly this reason. In production the same phenomenon means: dedupe is a policy about metadata, not just storage, and "which copy is canonical" deserves a deliberate answer rather than an alphabetical accident. Teams that hit this and trace it earn the deepest lesson in the lab.

### chunk_corpus

The orchestrator: chunk every document, concatenate, dedupe once globally (not per document; the duplicate pair spans two documents), return chunks plus the dropped count. The ingest CLI prints every stage's count, which turns each curveball into a visible number: 31 loaded, 30 active, about 190 chunks, 6 duplicates dropped. Teach students to read that printout like a cockpit: any number moving unexpectedly between runs is the first symptom of an ingestion regression.
