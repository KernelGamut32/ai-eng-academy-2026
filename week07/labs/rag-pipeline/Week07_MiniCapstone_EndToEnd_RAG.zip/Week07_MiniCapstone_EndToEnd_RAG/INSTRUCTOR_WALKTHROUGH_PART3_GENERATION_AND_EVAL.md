# Instructor Walkthrough, Part 3: Generation, the Pipeline, and TruLens Evaluation

Line-by-line through llm.py, rag.py, and evaluation.py.

## llm.py: three backends, one honest failure mode

### get_backend and _base_url_for

`get_backend()` reads config and validates against the known set, raising ValueError with the valid options listed for anything else. `_base_url_for` maps lmstudio to port 1234 and ollama to port 11434, both `/v1` OpenAI-compatible endpoints. Say the design sentence out loud in class: two different products, one client code path, because both chose to speak the OpenAI wire format. That interoperability is why swapping backends is a config change and not a rewrite.

### chat_completion

The offline guard comes first: calling a chat endpoint in offline mode is a programming error, not a runtime condition, so it raises immediately with a message pointing at the extractive answerer. The OpenAI import happens inside the function so fully offline machines never pay for it. The client is built with a placeholder api key (local servers ignore keys but the client insists on one), the config timeout, and the config retry count; the three override parameters (base_url_override, timeout, max_retries) exist for tests and connectivity debugging and default to None meaning "use config."

The docstring's last paragraph is the standing commitment: a dead server raises `openai.APIConnectionError`, and there is no code path that quietly tries the other backend. The test suite proves it by pointing the client at port 9 (a port nothing listens on) and asserting the exception type. When students ask why we would not want a helpful fallback, the answer is the sweep: a run labeled ollama that silently answered via LM Studio has poisoned its own results, and nobody would know.

### split_sentences and offline_extractive_answer (student Task 8)

split_sentences is a regex split on sentence-ending punctuation followed by whitespace; deliberately simple, and its edge cases (abbreviations, decimals) are acceptable losses for a teaching answerer.

The extractive answerer is the offline "model," and it is worth walking slowly because it is the thing that makes the entire capstone runnable with no model server. All context sentences are collected with their positions. One embed call covers the question and every sentence: batching is a performance habit worth building even when the embedder is cheap, because the same code runs against the sentence-transformers backend where per-call overhead is real. Unit vectors make cosine similarity a plain dot product. best_score, the single highest sentence similarity, is the confidence signal: if a threshold is set and best_score falls short, the function returns the ABSTAIN_TEXT with the score; otherwise the top sentences are re-sorted into reading order and joined. The re-sort is the craftsmanship detail: without it, answers read as a ransom note of high-scoring sentences in score order rather than prose in document order.

The threshold value itself (0.30 for grounded_strict and concise under hash embeddings) was not guessed. The calibration method appears in the experiments guide as a stretch goal: score every eval question with abstention disabled, then place the threshold in the gap between the answerable and unanswerable score distributions. On this corpus those distributions nearly separate: answerable questions bottom out around 0.27 and unanswerable ones top out around 0.40, with one deliberate hard case (a price question that retrieves the right product's spec chunk, which simply contains no price) sitting above any workable threshold. That case is why abstain recall is 2 of 3 rather than 3 of 3, and it is a better discussion than a clean sweep would be: lexical similarity cannot tell "about the right thing" from "contains the answer."

## rag.py: variants and instrumentation

### PromptVariant and VARIANTS

A frozen dataclass with the variant name, system prompt, sampling settings, and the two offline knobs. The design insight to narrate: each variant expresses ONE intent through TWO mechanisms. grounded_strict's intent is "answer only from context, refuse otherwise"; on live backends that intent is a system prompt containing the abstention instruction, and on the offline backend it is an abstention threshold. The sweep can therefore compare variants meaningfully in any backend mode. baseline's `offline_abstain_threshold=None` plus a prompt with no abstention instruction makes it the control group: fluent, never refusing, and about to be disqualified by a gate for exactly that.

The abstention instruction interpolates ABSTAIN_TEXT from config, so the marker the prompts demand and the marker the detector looks for cannot drift apart: they are the same constant.

### RagPipeline

Constructor stores embedder, store, variant, top_k, and initializes `last_matches`, the pipeline's one piece of mutable state. Three methods, all instrumented.

retrieve carries the loaded decorator:

```python
@instrument(
    span_type=SpanAttributes.SpanType.RETRIEVAL,
    attributes={
        SpanAttributes.RETRIEVAL.QUERY_TEXT: "question",
        SpanAttributes.RETRIEVAL.RETRIEVED_CONTEXTS: "return",
    },
)
```

Translation for the room: TruLens 2.x is built on OpenTelemetry, the same tracing standard Week 9 covers for production observability. The decorator marks this method as the RETRIEVAL span and declares, by argument name and by the word "return", which values are the query text and the retrieved contexts. The evaluation metrics will later select those recorded values by span type, not by knowing anything about our class. This is why the starter warns students to keep the decorator exactly as-is: delete it and evaluation does not error, it just finds no retrieval spans and the context metrics go quietly empty. Silent, structural, and exactly the kind of failure worth experiencing once in a lab instead of in production.

generate and answer wear plain `@instrument()`: recorded as spans, with answer as the app's main method, so the record input is the question and the record output is the final answer string. Those two facts are precisely what the other two metric selectors rely on.

## evaluation.py: two metric families

The module measures the same pipeline two ways. Reference-based metrics (ROUGE, retrieval hit, MRR) compare against the eval set's expected answers and documents; reference-free metrics (the TruLens triad) judge internal consistency between question, contexts, and answer with no gold labels at all. Production reality motivates keeping both: in production there are no reference answers, so the triad style is what monitoring looks like, while the reference metrics are what offline benchmarks look like.

### The eval set and EvalItem

18 questions: 15 answerable with expected_doc_ids and reference answers, 3 deliberately unanswerable whose reference is the abstention marker itself. Two questions accept either VexLine doc_id, and the reason is Part 1's dedupe discussion: which byte-identical copy survives dedupe is an artifact of corpus order, and an eval set that pretended otherwise would fail teams for a phenomenon the lab deliberately includes.

### rouge_l_f, is_abstention, retrieval_hit, reciprocal_rank

rouge_l_f wraps rouge-score's rougeL F-measure: longest-common-subsequence overlap between reference and produced answer, order-sensitive but not contiguous. is_abstention checks for the marker case-insensitively anywhere in the answer, so both the offline answerer's exact emission and a live model's slightly-wrapped emission count. retrieval_hit asks "did ANY expected document appear in the retrieved list"; reciprocal_rank asks "how high," scoring 1 over the rank of the first expected document. Both take (expected_doc_ids, retrieved_doc_ids) in that order; the tests pin the signature because the two argument lists are the same type and swapping them is a silent bug.

### make_triad_metrics (student Task 10)

The three implementations are embedding-similarity proxies for the RAG triad, and the choices among mean, max, and single similarity are the intellectual content. context_relevance takes the MEAN of question-to-chunk similarities: every retrieved chunk should have deserved its slot, so irrelevant passengers drag the score. groundedness takes the MAX of answer-to-chunk similarities: one fully supporting source suffices, and averaging would punish an answer for chunks it correctly ignored. answer_relevance is the single question-to-answer similarity.

The abstention rules create deliberate tension: groundedness scores an abstention 1.0 (a refusal cannot hallucinate) while answer_relevance scores it 0.0 (a refusal answers nothing). Hold that pair up in class, because the entire sweep story falls out of it: a variant that refuses freely banks groundedness and abstain recall while paying in relevance and ROUGE, and the champion criteria are how the team decides the exchange rate. Then the honesty note: real TruLens deployments typically implement the triad with an LLM judge reading the text; our embedding proxy keeps the lab deterministic and serverless, at the cost of literal-mindedness the dashboard traces let you audit.

Each metric is wrapped in a `Metric` with dict selectors:

```python
selectors={
    "question": Selector.select_record_input(),
    "contexts": Selector.select_context(collect_list=True),
}
```

The selector maps each function parameter to a recorded value: record input, record output, or the contexts captured by the RETRIEVAL span. `collect_list=True` gathers the retrieval span's context list. This is the 2.x replacement for the 1.x chained style (`Feedback(...).on_input().on(...)`); materials showing the chain are for the old API and raise here, which is called out as a currency flag in the README.

### run_evaluation

Builds a TruApp around the pipeline (app_name plus app_version distinguish sweep runs on the TruLens side), then loops the eval set INSIDE the `with tru_app:` recording context: every `pipeline.answer()` call in that block is recorded as a full trace. Per question it captures the answer, wall-clock latency, retrieved doc ids (read from last_matches), and the derived row fields. Rows use None for fields that do not apply (hit and MRR for unanswerable questions; ROUGE for abstentions is 0.0 for answerable questions so refusing everything cannot game the metric).

Then the sequencing block that owns its own comment: `force_flush()`, `compute_feedbacks()`, `force_flush()` all run before the function returns. TruLens 2.12 queues metric computations, and starting the next TruApp while a previous app's evaluations are pending silently drops them. In the sweep, six apps are created back to back, so this ordering is the difference between six scored runs and six half-scored ones. It was found the annoying way and is verified by execution.

### aggregate_rows and read_triad_from_leaderboard

aggregate_rows folds rows into run-level numbers with definitions worth reading verbatim in class, since each encodes a policy: hit rate and MRR over answerable questions only; ROUGE counting wrong abstentions as zero; abstain_recall as the safety number (fraction of unanswerable questions refused); false_abstain_rate as the cost-of-caution number (fraction of answerable questions refused anyway). read_triad_from_leaderboard pulls the triad aggregates from TruLens's own leaderboard for the app version, so MLflow logs the same numbers the TruLens dashboard displays; one source of truth, two views.
