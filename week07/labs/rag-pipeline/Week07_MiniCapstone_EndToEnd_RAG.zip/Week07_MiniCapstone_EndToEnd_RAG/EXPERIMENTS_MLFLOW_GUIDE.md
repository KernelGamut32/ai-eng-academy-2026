# Experiments Guide: The Sweep, the MLflow UI, and Champion Selection

For teams at Milestone 5 and for the instructor's Day 2 walkthrough. Assumes ingest has run and services are up.

## Running the sweep

```bash
./run.sh starter experiment
```

Six configurations, each running all 18 eval questions through the pipeline under TruLens recording, each logged as one MLflow run. Offline mode finishes in under a minute; a live backend takes as long as 108 model calls take, which is itself a number worth noticing.

Console output per run looks like:

```
[grounded_strict-k3] hit_rate=1.000 mrr=0.967 rougeL=0.351 grounded=0.749 abstain_recall=0.667
```

## Reading the results in the MLflow UI

Open http://localhost:5001 and click the `wk7_mini_capstone_rag_sweep` experiment.

**The runs table.** Six rows, named `variant-kN`. Use the column picker to show, in this order: variant and top_k from params, then retrieval_hit_rate, rougeL_f, groundedness, answer_relevance, abstain_recall from metrics. Sort by any metric header; sorting by rougeL_f and then by groundedness, one after the other, is a fast way to feel the tension the sweep is built around: the ROUGE ranking and the groundedness ranking disagree, and they disagree ABOUT the baselines.

**Compare view.** Select all six runs with the checkboxes and press Compare. The parallel coordinates chart is the money visual: put variant on the left, the five metrics rightward, and watch the baseline lines dive to zero at the abstain_recall axis while holding high elsewhere. That one picture is the argument for gates.

**Chart and table tabs.** The scatter of groundedness against rougeL_f, colored by variant, shows the trade cleanly: baseline sits high-ROUGE lower-groundedness, grounded_strict the reverse, concise between. The table tab gives the same numbers side by side for screenshots and the demo.

**Artifacts.** Open any single run and its artifacts: `results.csv` holds every question, the answer produced, and every per-question score, which is where you go when an aggregate looks odd; `system_prompt.txt` is the exact prompt that produced the run. Pull up baseline-k3's results.csv and find q16 (the military discount question): the baseline answered it, from context about something else entirely. That row is the gate's justification in one line of CSV.

## The TruLens view of the same runs

```bash
./run.sh starter dashboard
```

Streamlit on http://localhost:8501. The leaderboard lists the same six app versions with the triad aggregates MLflow logged (one source of truth, two views). Click into a version, pick a record, and read a full trace: the question, the RETRIEVAL span with the actual chunks, the generate span, the answer, and each metric's score for that record. For the demo, trace q17 (the drill price question) under grounded_strict: retrieval brings back exactly the right document, and the answer is wrong anyway, because "about the right thing" and "contains the answer" are different properties. The trace makes that distinction visible in a way no aggregate can.

## Selecting the champion

```bash
./run.sh starter select-champion
```

This reads the runs from MLflow, applies the gates, ranks survivors by the weighted composite, tags the winner in MLflow (`champion: true`; find it with the tag filter in the UI), and writes `artifacts/champion.json`:

- Gates: groundedness at least 0.60, retrieval_hit_rate at least 0.70, abstain_recall at least 0.66. Both baselines fail the third at 0.000.
- Composite over survivors: 0.40 groundedness, 0.30 rougeL_f, 0.30 answer_relevance.
- Expected verdict on the reference numbers: grounded_strict-k3, composite 0.5251.

Then open champion.json and read it as what it is: the deployment handoff. Everything a serving system needs (variant, top_k, backend, embedding backend) plus everything a reviewer needs (the metrics and the criteria that justified selection). In a weights-shaped system this role is played by a model registry alias; in a configuration-shaped system it is a versioned config artifact. Same promotion pattern, different payload.

## Why 0.30? Recalibrating the abstention threshold

The offline abstention threshold in grounded_strict and concise (0.30) was set empirically, and the method matters more than the number, because switching to semantic embeddings invalidates the number.

The method: run every eval question through `offline_extractive_answer` with `abstain_threshold=None`, recording best_score per question. Split the scores by answerable versus unanswerable and look at the two distributions. On this corpus with hash embeddings: answerable questions score 0.27 to 0.64 (mean 0.45); unanswerable ones score 0.18 to 0.40 (mean 0.26). The threshold goes in the gap. 0.30 catches two of the three unanswerable questions while false-abstaining on at most one borderline answerable question.

The third unanswerable question (q17, the drill price) scores 0.398, ABOVE any workable threshold, and that is a designed lesson rather than a flaw: the question retrieves the correct product's specification chunk with high lexical overlap, and the chunk simply contains no price. Confidence-by-similarity cannot detect "relevant but insufficient." Live LLM backends handle q17 correctly through the grounded prompt, because a model reading the context can notice the absence; a similarity score cannot. If your team runs the stretch goal comparing backends, watch that one question flip.

To recalibrate for `EMBEDDING_BACKEND=st`: the script is 20 lines against modules you already built (load corpus, chunk, embed, retrieve per question, call the answerer with the threshold disabled, print the two score distributions). Semantic similarity scores sit in a different range than lexical ones, so expect a different gap and a different threshold. Update the two variant definitions, rerun the sweep, and compare leaderboards; writing three sentences about what moved and why is the stretch goal's actual deliverable.

## Troubleshooting

- **Sweep dies immediately mentioning the tracking URI or a file store.** MLflow is down (run check-services) or someone pointed MLFLOW_TRACKING_URI at a local path; mlflow 3.15 refuses the classic file store. Point it back at http://localhost:5001.
- **Six runs but triad columns empty in MLflow.** The TruLens sequencing was disturbed: compute_feedbacks must complete per run before the next app starts. If you reordered run_evaluation's ending, restore it.
- **select-champion says no_eligible_run.** Read the gate_failures dict it prints; it names which gate eliminated how many runs. All six failing abstain_recall usually means abstention is not firing at all: check the threshold made it into the variant definitions and the marker constant is untouched.
- **The dashboard port is busy.** The dashboard command uses a fixed port with force=True precisely so re-running it reclaims a stuck Streamlit; if something else owns 8501, set TRULENS_DASHBOARD_PORT.
