# Airflow image for the Cordwell refresh lab.
#
# Built on the official 3.3.1 image with the RAG stack's client libraries
# baked in, so container startup is instant after the one-time build.
# (The _PIP_ADDITIONAL_REQUIREMENTS env-var alternative reinstalls on
# every container start; fine for a quick experiment, wrong for a lab
# that restarts the stack all day.)
#
# Build happens automatically via `docker compose up -d --build`.
FROM apache/airflow:3.3.1-python3.12

COPY requirements-airflow.txt /requirements-airflow.txt
RUN pip install --no-cache-dir -r /requirements-airflow.txt
