#!/usr/bin/env bash
# Convenience wrapper: ./run.sh <target> <command...>
#   ./run.sh starter check-services
#   ./run.sh starter ingest
#   ./run.sh solution experiment
# Equivalent to: PYTHONPATH=<target>/src python -m cordwell_rag.cli <command...>
set -euo pipefail
TARGET="${1:?usage: ./run.sh starter|solution <command...>}"
shift
if [[ "$TARGET" != "starter" && "$TARGET" != "solution" ]]; then
  echo "first argument must be starter or solution" >&2
  exit 2
fi
PYTHONPATH="$(dirname "$0")/$TARGET/src" exec python -m cordwell_rag.cli "$@"
