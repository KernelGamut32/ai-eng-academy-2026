"""Weekly evaluation-only DAG, inherited from the previous platform team.

Runs the evaluation sweep and champion selection WITHOUT re-ingesting,
as a drift check between nightly refreshes: if the champion changes when
the data did not, the eval set or the criteria moved.

NOTE FOR THE REFRESH PROJECT (ticket CORD-2214): this DAG was written
against Airflow 2.7 and has not been touched since. Migrate it to the
Airflow 3 cluster as part of the refresh rollout.
"""

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator

_SRC_CANDIDATES = [
    Path("/opt/airflow/cordwell_src"),
    Path(__file__).resolve().parents[2] / "src",
]
for _src in _SRC_CANDIDATES:
    if _src.is_dir() and str(_src) not in sys.path:
        sys.path.insert(0, str(_src))


def _run_weekly_eval(eval_date: str) -> None:
    from cordwell_rag.pipeline_tasks import run_refresh_sweep, select_refresh_champion

    result = run_refresh_sweep(refresh_tag=f"weekly-eval-{eval_date}")
    verdict = select_refresh_champion()
    print(f"weekly eval {eval_date}: {len(result['run_ids'])} runs, verdict {verdict['status']}")


with DAG(
    dag_id="cordwell_weekly_eval",
    description="Weekly drift check: evaluation sweep + champion selection, no ingest",
    schedule_interval="0 6 * * 1",
    start_date=datetime(2026, 8, 1),
    catchup=False,
    tags=["cordwell", "rag", "legacy"],
) as dag:
    run_eval = PythonOperator(
        task_id="run_weekly_eval",
        python_callable=_run_weekly_eval,
        op_kwargs={"eval_date": "{{ execution_date.strftime('%Y-%m-%d') }}"},
    )
