"""Orchestration task functions for the scheduled knowledge-base refresh.

This module is the seam between Airflow and the RAG system. Every function
here is a plain Python callable with JSON-serializable inputs and outputs,
which buys three things at once:

  * The Airflow DAG stays thin: each Airflow task wraps exactly one of
    these functions, so the DAG file is wiring, not logic.
  * Everything is unit-testable without Airflow installed: the functions
    know nothing about task instances, XCom, or context.
  * XCom compatibility is automatic: plain dicts of strings and numbers
    pass between tasks with no custom serialization.

The store factory (_build_store) exists as a named seam so tests can
substitute a fake index; production code never passes a store in.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List

from . import config

# ---------------------------------------------------------------------------
# Internal factories (seams for tests; production uses the defaults)
# ---------------------------------------------------------------------------


def _build_store():
    """Construct the vector store. Kept as a module-level factory so tests
    can monkeypatch one name instead of reaching into task internals."""
    from .vector_store import PineconeLocalStore

    return PineconeLocalStore()


def _build_embedder():
    from .embeddings import get_embedder

    return get_embedder()


# ---------------------------------------------------------------------------
# Task 1: preflight
# ---------------------------------------------------------------------------


def check_services_or_raise(timeout_s: float = 3.0) -> Dict[str, str]:
    """Ping the services the refresh needs and fail fast if any is down.

    Contract:
      * Required services: Pinecone (config.PINECONE_HOST) and MLflow
        (config.MLFLOW_TRACKING_URI). Ping each with httpx.get and the
        given timeout; any exception counts as down.
      * All up: return {service_name: "up"} for each.
      * Any down: raise RuntimeError whose message names EVERY
        unreachable service with its URL and the exception type, so the
        operator reading a 2 AM failure knows exactly what to start.
    """
    # TODO(Task E1): implement the preflight check. A scheduled run that
    # cannot succeed should die in its first task with a diagnosis, not
    # halfway through ingest with a connection traceback.
    raise NotImplementedError("TODO Task E1: check_services_or_raise")



# ---------------------------------------------------------------------------
# Task 2: ingest
# ---------------------------------------------------------------------------


def refresh_ingest() -> Dict[str, int]:
    """Run the full corpus refresh: load, version-select, chunk, dedupe,
    embed, rebuild the index, upsert.

    Contract:
      * Compose the existing pipeline: load_corpus,
        select_active_documents, chunk_corpus, _build_embedder().embed,
        then _build_store() with ensure_fresh_index() and upsert_chunks.
      * Return the stage counts as a plain dict (XCom-friendly) with
        keys: documents_loaded, documents_active, chunks,
        duplicates_dropped, vectors_upserted.
      * Raise RuntimeError when chunking produced zero chunks, and when
        upsert wrote fewer vectors than chunks. A scheduled refresh must
        never silently publish an empty or partial index.
      * Use the _build_store and _build_embedder factories above rather
        than constructing directly; they are the seams the tests patch.
    """
    # TODO(Task E2): implement the ingest task function.
    raise NotImplementedError("TODO Task E2: refresh_ingest")



# ---------------------------------------------------------------------------
# Task 3: evaluation sweep
# ---------------------------------------------------------------------------


def run_refresh_sweep(refresh_tag: str) -> Dict[str, Any]:
    """Run the 6-configuration evaluation sweep against the freshly
    ingested index, logging every run to MLflow.

    Contract:
      * Build the embedder and store from the factories; the store
        attaches with connect_existing_index() (ingest already ran; a
        sweep against a missing index should fail fast, not recreate it).
      * Load the eval set, create a TruSession on config.TRULENS_DB_URL,
        call run_sweep from experiments, and collect the run ids. Pass
        tracking_uri=config.MLFLOW_TRACKING_URI explicitly: run_sweep's
        default binds the config value at import time, and a task that
        ignores late configuration changes is a scheduling bug waiting
        to happen.
      * Tag every returned run with refresh_tag under the MLflow tag key
        "refresh_tag" (mlflow.tracking.MlflowClient().set_tag), so one
        scheduled refresh's runs are groupable in the UI.
      * Return {"run_ids": run_ids, "refresh_tag": refresh_tag}.
    """
    # TODO(Task E3): implement the sweep task function.
    raise NotImplementedError("TODO Task E3: run_refresh_sweep")



# ---------------------------------------------------------------------------
# Task 4: champion selection
# ---------------------------------------------------------------------------


def select_refresh_champion() -> Dict[str, Any]:
    """Run gates-then-composite champion selection over the MLflow store
    and return the verdict dict unchanged.

    The verdict's status field ('champion_selected' or 'no_eligible_run')
    is what the DAG's branch task switches on. This wrapper exists so the
    DAG imports one orchestration module rather than reaching into
    experiments directly, and so the selection call site is patchable in
    tests.
    """
    from .experiments import select_champion

    return select_champion()


# ---------------------------------------------------------------------------
# Task 5a: publish report (champion path)
# ---------------------------------------------------------------------------


def write_refresh_report(
    verdict: Dict[str, Any],
    counts: Dict[str, int],
    run_date: str,
) -> str:
    """Write the dated refresh report and return its path as a string.

    Contract:
      * Path: config.ARTIFACTS_DIR / "reports" / f"refresh_{run_date}.md"
        (create the directory if needed).
      * Content is markdown containing at minimum: the run_date in the
        title, the ingest counts (documents, chunks, duplicates dropped,
        vectors), the champion run name and composite, and every metric
        from verdict["metrics"] with its value.
      * run_date arrives from the DAG's data interval; never derive the
        report date from wall-clock time inside this function, so
        re-running a past interval reproduces the same filename.
      * Return str(path).
    """
    # TODO(Task E4): implement the report writer.
    raise NotImplementedError("TODO Task E4: write_refresh_report")



# ---------------------------------------------------------------------------
# Task 5b: no-champion alert (failure path)
# ---------------------------------------------------------------------------


def raise_no_champion(verdict: Dict[str, Any]) -> None:
    """Terminal task for the no-eligible-run branch.

    Contract:
      * Build a message that includes each gate name with its failure
        count from verdict["gate_failures"], and states clearly that the
        index WAS refreshed but champion.json was NOT updated.
      * Raise RuntimeError with that message. This task exists to fail:
        a refresh whose sweep produced no shippable configuration must
        surface as a FAILED run in the Airflow UI, not a green one with
        a sad log line.
    """
    # TODO(Task E5): implement the loud failure.
    raise NotImplementedError("TODO Task E5: raise_no_champion")

