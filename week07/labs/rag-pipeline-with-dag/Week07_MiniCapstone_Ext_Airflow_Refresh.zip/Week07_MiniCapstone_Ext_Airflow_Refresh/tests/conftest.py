"""Test target selection.

CAPSTONE_TARGET=starter (default) runs the tests against the starter
package, where unimplemented TODOs fail their tests cleanly.
CAPSTONE_TARGET=solution runs the identical tests against the solution
package, where every test must pass. Teams work until the starter run
matches the solution run.
"""

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = os.getenv("CAPSTONE_TARGET", "starter").strip().lower()
if TARGET not in {"starter", "solution"}:
    raise SystemExit(f"CAPSTONE_TARGET must be 'starter' or 'solution', got {TARGET!r}")

sys.path.insert(0, str(ROOT / TARGET / "src"))

# Force deterministic test behavior regardless of the developer's .env.
os.environ["LAB_BACKEND"] = "offline"
os.environ["EMBEDDING_BACKEND"] = "hash"


def pytest_report_header(config):
    return f"cordwell_rag target: {TARGET}  (set CAPSTONE_TARGET=solution to test the solution)"
