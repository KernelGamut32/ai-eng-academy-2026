import pytest

from cordwell_rag.config import ABSTAIN_MARKER
from cordwell_rag.evaluation import (
    aggregate_rows,
    is_abstention,
    load_eval_set,
    make_triad_metrics,
    reciprocal_rank,
    retrieval_hit,
    rouge_l_f,
)
from cordwell_rag.embeddings import HashEmbedder


def test_eval_set_loads_with_expected_shape():
    items = load_eval_set()
    assert len(items) == 18
    assert sum(1 for i in items if not i.answerable) == 3
    assert all(i.reference_answer for i in items)


def test_rouge_l_f_identical_is_one_and_disjoint_is_zero():
    assert rouge_l_f("the window is 30 days", "the window is 30 days") == pytest.approx(1.0)
    assert rouge_l_f("alpha beta gamma", "delta epsilon zeta") == pytest.approx(0.0)


def test_is_abstention_detects_marker_case_insensitively():
    assert is_abstention(ABSTAIN_MARKER)
    assert is_abstention("I'm sorry, not enough context to answer that.")
    assert not is_abstention("The window is 30 days.")


def test_retrieval_hit_and_mrr():
    retrieved = ["a", "b", "c"]
    assert retrieval_hit(["b"], retrieved) is True
    assert retrieval_hit(["z"], retrieved) is False
    assert reciprocal_rank(["b"], retrieved) == pytest.approx(0.5)
    assert reciprocal_rank(["z"], retrieved) == pytest.approx(0.0)


def test_triad_metric_implementations_are_bounded():
    emb = HashEmbedder()
    metrics = make_triad_metrics(emb)
    fns = {m.name: m.imp for m in metrics}
    ctxs = ["The return window is 30 days.", "Shear bolts break on impact."]
    for name, fn in fns.items():
        if name == "context_relevance":
            score = fn("what is the return window", ctxs)
        elif name == "groundedness":
            score = fn(ctxs, "The window is 30 days.")
        else:
            score = fn("what is the return window", "The window is 30 days.")
        assert 0.0 <= score <= 1.0, name


def test_groundedness_scores_abstention_as_safe():
    emb = HashEmbedder()
    metrics = {m.name: m.imp for m in make_triad_metrics(emb)}
    assert metrics["groundedness"](["anything"], ABSTAIN_MARKER) == pytest.approx(1.0)
    assert metrics["answer_relevance"]("q", ABSTAIN_MARKER) == pytest.approx(0.0)


def test_aggregate_rows_computes_abstention_metrics():
    rows = [
        dict(answerable=True, abstained=False, hit=True, mrr=1.0, rougeL_f=0.8, latency_s=0.1),
        dict(answerable=True, abstained=True, hit=True, mrr=0.5, rougeL_f=0.0, latency_s=0.1),
        dict(answerable=False, abstained=True, hit=None, mrr=None, rougeL_f=None, latency_s=0.1),
        dict(answerable=False, abstained=False, hit=None, mrr=None, rougeL_f=None, latency_s=0.1),
    ]
    agg = aggregate_rows(rows)
    assert agg["retrieval_hit_rate"] == pytest.approx(1.0)  # over answerable only
    assert agg["abstain_recall"] == pytest.approx(0.5)      # 1 of 2 unanswerable
    assert agg["false_abstain_rate"] == pytest.approx(0.5)  # 1 of 2 answerable
