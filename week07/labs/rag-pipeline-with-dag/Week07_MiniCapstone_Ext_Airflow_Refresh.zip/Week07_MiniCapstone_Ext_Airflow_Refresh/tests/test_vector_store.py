import pytest

from cordwell_rag import config
from cordwell_rag.chunking import Chunk
from cordwell_rag.vector_store import PineconeLocalStore
from fakes import FakeIndex


def _chunk(text: str, cid: str = "d::c000") -> Chunk:
    return Chunk(
        chunk_id=cid, doc_id="d", doc_family="d", title="T", category="test",
        effective_date="2026-01-01", seq=0, text=text,
    )


def _store_with_fake() -> tuple[PineconeLocalStore, FakeIndex]:
    store = PineconeLocalStore.__new__(PineconeLocalStore)
    store.index = FakeIndex()
    return store, store.index


def test_upsert_uses_keyword_only_sdk_shape():
    store, fake = _store_with_fake()
    chunks = [_chunk("hello world")]
    written = store.upsert_chunks(chunks, [[0.1] * config.EMBED_DIM])
    assert written == 1
    assert fake.vectors["d::c000"]["metadata"]["text"] == "hello world"


def test_upsert_batches_at_100():
    store, fake = _store_with_fake()
    chunks = [_chunk("t", cid=f"d::c{i:03d}") for i in range(250)]
    store.upsert_chunks(chunks, [[0.0] * config.EMBED_DIM] * 250)
    assert fake.upsert_batches == [100, 100, 50]


def test_upsert_guard_refuses_oversized_metadata():
    store, _ = _store_with_fake()
    big = _chunk("y" * (config.METADATA_LIMIT_BYTES + 100), cid="d::c007")
    with pytest.raises(ValueError) as err:
        store.upsert_chunks([big], [[0.0] * config.EMBED_DIM])
    assert "d::c007" in str(err.value)  # error names the offending chunk


def test_upsert_refuses_misaligned_inputs():
    store, _ = _store_with_fake()
    with pytest.raises(ValueError):
        store.upsert_chunks([_chunk("a")], [])


def test_metadata_size_measures_utf8_bytes():
    small = PineconeLocalStore.build_metadata(_chunk("abc"))
    accented = PineconeLocalStore.build_metadata(_chunk("caf\u00e9" * 100))
    assert PineconeLocalStore.metadata_size_bytes(accented) > PineconeLocalStore.metadata_size_bytes(small)
    assert PineconeLocalStore.metadata_size_bytes(accented) > len("caf\u00e9" * 100)  # bytes > chars


def test_query_normalizes_matches_to_plain_dicts():
    store, fake = _store_with_fake()
    store.upsert_chunks([_chunk("alpha beta")], [[1.0] + [0.0] * (config.EMBED_DIM - 1)])
    out = store.query_top_k([1.0] + [0.0] * (config.EMBED_DIM - 1), top_k=1)
    assert out[0]["id"] == "d::c000"
    assert out[0]["text"] == "alpha beta"
    assert isinstance(out[0]["score"], float)
    assert out[0]["doc_id"] == "d"
