import math

from cordwell_rag import config
from cordwell_rag.embeddings import HashEmbedder, get_embedder, pick_device


def test_pick_device_returns_valid_choice():
    assert pick_device() in {"cuda", "mps", "cpu"}


def test_hash_embedder_is_deterministic_and_normalized():
    emb = HashEmbedder()
    v1 = emb.embed(["the return window is 30 days"])[0]
    v2 = emb.embed(["the return window is 30 days"])[0]
    assert v1 == v2
    assert len(v1) == config.EMBED_DIM
    assert math.isclose(sum(x * x for x in v1), 1.0, rel_tol=1e-9)


def test_hash_embedder_similar_texts_score_higher():
    emb = HashEmbedder()
    q, near, far = emb.embed([
        "how long is the standard return window",
        "the standard return window is 30 days from purchase",
        "install the auger shear bolt with the spanner",
    ])
    dot = lambda a, b: sum(x * y for x, y in zip(a, b))
    assert dot(q, near) > dot(q, far)


def test_plural_folding_matches_singular_and_plural():
    emb = HashEmbedder()
    a, b = emb.embed(["returns", "return"])
    assert a == b


def test_get_embedder_rejects_unknown_backend(monkeypatch):
    monkeypatch.setenv("EMBEDDING_BACKEND", "quantum")
    import importlib

    from cordwell_rag import config as cfg
    importlib.reload(cfg)
    from cordwell_rag import embeddings
    importlib.reload(embeddings)
    try:
        import pytest
        with pytest.raises(ValueError):
            embeddings.get_embedder()
    finally:
        monkeypatch.setenv("EMBEDDING_BACKEND", "hash")
        importlib.reload(cfg)
        importlib.reload(embeddings)
