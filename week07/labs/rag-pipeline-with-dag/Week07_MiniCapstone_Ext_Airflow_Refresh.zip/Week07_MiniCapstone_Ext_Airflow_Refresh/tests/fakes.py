"""In-memory stand-ins for services the unit tests must not require.

FakeIndex imitates the pinecone 9.1.0 Index surface strictly enough to
catch the two integration mistakes that bite in the real SDK: positional
upsert arguments (the real client is keyword-only) and object-style match
attributes in query responses.
"""

from types import SimpleNamespace
from typing import Any, Dict, List


class FakeIndex:
    def __init__(self):
        self.vectors: Dict[str, Dict[str, Any]] = {}
        self.upsert_batches: List[int] = []

    def upsert(self, *args, vectors=None, **kwargs):
        if args:
            raise TypeError(
                "Index.upsert() takes 1 positional argument: pass vectors=..."
            )
        if vectors is None:
            raise TypeError("upsert() missing required keyword argument: 'vectors'")
        self.upsert_batches.append(len(vectors))
        for item in vectors:
            self.vectors[item["id"]] = item
        return SimpleNamespace(upserted_count=len(vectors))

    def query(self, *, vector, top_k, include_metadata=True, **kwargs):
        def dot(a, b):
            return sum(x * y for x, y in zip(a, b))

        scored = sorted(
            self.vectors.values(),
            key=lambda item: dot(item["values"], vector),
            reverse=True,
        )[:top_k]
        matches = [
            SimpleNamespace(
                id=item["id"],
                score=dot(item["values"], vector),
                metadata=dict(item["metadata"]) if include_metadata else None,
            )
            for item in scored
        ]
        return SimpleNamespace(matches=matches)

    def describe_index_stats(self):
        return SimpleNamespace(total_vector_count=len(self.vectors), dimension=384)
