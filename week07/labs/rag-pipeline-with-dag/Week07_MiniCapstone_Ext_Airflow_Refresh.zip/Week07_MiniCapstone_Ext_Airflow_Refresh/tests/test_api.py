from fastapi.testclient import TestClient

from cordwell_rag import config
from cordwell_rag.api import create_app
from cordwell_rag.chunking import Chunk
from cordwell_rag.embeddings import HashEmbedder
from cordwell_rag.vector_store import PineconeLocalStore
from fakes import FakeIndex


def _client():
    emb = HashEmbedder()
    store = PineconeLocalStore.__new__(PineconeLocalStore)
    store.index = FakeIndex()
    texts = [
        "The standard return window is 30 days from purchase with a receipt.",
        "CordPerks Platinum members receive an extended 90 day return window.",
        "The FrostBreaker recall covers shear bolt lots 24C through 24F.",
    ]
    chunks = [
        Chunk(chunk_id=f"d{i}::c000", doc_id=f"d{i}", doc_family=f"d{i}", title=f"T{i}",
              category="test", effective_date="2026-01-01", seq=0, text=t)
        for i, t in enumerate(texts)
    ]
    store.upsert_chunks(chunks, emb.embed(texts))
    app = create_app(store=store, embedder=emb)
    return TestClient(app)


def test_health_reports_ok_and_index_stats():
    with _client() as client:
        data = client.get("/health").json()
    assert data["status"] == "ok"
    assert data["index"]["total_vector_count"] == 3


def test_search_serves_context_chunks():
    with _client() as client:
        resp = client.get("/search", params={"q": "standard return window", "top_k": 2})
    assert resp.status_code == 200
    body = resp.json()
    assert body["top_k"] == 2
    assert len(body["hits"]) == 2
    assert "30 days" in body["hits"][0]["text"]
    assert set(body["hits"][0]) >= {"id", "score", "text", "doc_id", "title"}


def test_search_validates_query_params():
    with _client() as client:
        assert client.get("/search", params={"q": "ab"}).status_code == 422
        assert client.get("/search", params={"q": "abc", "top_k": 99}).status_code == 422


def test_answer_returns_grounded_answer_with_sources():
    with _client() as client:
        resp = client.post("/answer", json={"question": "What is the standard return window?"})
    assert resp.status_code == 200
    body = resp.json()
    assert "30 days" in body["answer"]
    assert body["backend"] == "offline"
    assert len(body["sources"]) >= 1


def test_answer_abstains_on_out_of_corpus_question():
    with _client() as client:
        resp = client.post("/answer", json={"question": "Who won the World Series last year?"})
    assert resp.json()["answer"].startswith(config.ABSTAIN_MARKER)


def test_answer_rejects_unknown_variant():
    with _client() as client:
        resp = client.post("/answer", json={"question": "Anything at all?", "variant": "yolo"})
    assert resp.status_code == 422
