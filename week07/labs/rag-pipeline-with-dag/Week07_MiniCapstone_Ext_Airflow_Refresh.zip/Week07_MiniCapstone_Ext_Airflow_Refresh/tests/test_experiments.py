import pandas as pd
import pytest

from cordwell_rag.experiments import ChampionCriteria, pick_champion


def _df(rows):
    return pd.DataFrame(rows)


BASE = dict(
    **{"metrics.rougeL_f": 0.5, "params.variant": "x", "params.top_k": "5",
       "params.backend": "offline", "params.embedding_backend": "hash",
       "tags.mlflow.runName": "x-k5"}
)


def test_pick_champion_applies_gates():
    df = _df([
        dict(run_id="a", **{"metrics.groundedness": 0.9, "metrics.retrieval_hit_rate": 0.9,
             "metrics.abstain_recall": 0.9, "metrics.answer_relevance": 0.5}, **BASE),
        dict(run_id="b", **{"metrics.groundedness": 0.2, "metrics.retrieval_hit_rate": 0.9,
             "metrics.abstain_recall": 0.9, "metrics.answer_relevance": 0.9}, **BASE),
    ])
    verdict = pick_champion(df, ChampionCriteria())
    assert verdict["status"] == "champion_selected"
    assert verdict["run_id"] == "a"  # b fails the groundedness gate despite relevance


def test_pick_champion_reports_when_nothing_passes():
    df = _df([
        dict(run_id="a", **{"metrics.groundedness": 0.1, "metrics.retrieval_hit_rate": 0.1,
             "metrics.abstain_recall": 0.1, "metrics.answer_relevance": 0.1}, **BASE),
    ])
    verdict = pick_champion(df, ChampionCriteria())
    assert verdict["status"] == "no_eligible_run"
    assert verdict["gate_failures"]["groundedness"] == 1


def test_pick_champion_composite_ranks_survivors():
    common = {"metrics.retrieval_hit_rate": 0.9, "metrics.abstain_recall": 0.9}
    df = _df([
        dict(run_id="low", **{"metrics.groundedness": 0.7, "metrics.answer_relevance": 0.2, **common}, **BASE),
        dict(run_id="high", **{"metrics.groundedness": 0.7, "metrics.answer_relevance": 0.9, **common}, **BASE),
    ])
    verdict = pick_champion(df, ChampionCriteria())
    assert verdict["run_id"] == "high"
    assert verdict["composite"] > 0.0


def test_pick_champion_handles_missing_metric_columns():
    df = _df([dict(run_id="a", **BASE)])  # no metrics at all
    verdict = pick_champion(df, ChampionCriteria())
    assert verdict["status"] == "no_eligible_run"
