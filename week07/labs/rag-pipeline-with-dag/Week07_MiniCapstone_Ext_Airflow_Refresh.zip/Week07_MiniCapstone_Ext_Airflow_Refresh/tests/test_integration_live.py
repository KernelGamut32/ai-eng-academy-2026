"""Live integration tests. These require docker compose services and are
skipped automatically when the services are unreachable, so `pytest` stays
green on a machine without Docker running."""

import httpx
import pytest

from cordwell_rag import config


def _reachable(url: str) -> bool:
    try:
        httpx.get(url, timeout=2.0)
        return True
    except Exception:
        return False


pinecone_up = _reachable(config.PINECONE_HOST)
mlflow_up = _reachable(config.MLFLOW_TRACKING_URI)


@pytest.mark.skipif(not pinecone_up, reason="Pinecone Local not running (docker compose up -d)")
def test_live_ingest_and_query_roundtrip():
    from cordwell_rag.chunking import chunk_corpus
    from cordwell_rag.corpus_loader import load_corpus, select_active_documents
    from cordwell_rag.embeddings import get_embedder
    from cordwell_rag.vector_store import PineconeLocalStore

    docs = select_active_documents(load_corpus())
    chunks, _ = chunk_corpus(docs)
    emb = get_embedder()
    store = PineconeLocalStore()
    store.ensure_fresh_index()
    written = store.upsert_chunks(chunks, emb.embed([c.text for c in chunks]))
    assert written == len(chunks)

    out = store.query_top_k(emb.embed(["standard return window"])[0], top_k=3)
    assert any("30 days" in m["text"] for m in out)


@pytest.mark.skipif(not mlflow_up, reason="MLflow not running (docker compose up -d)")
def test_live_mlflow_accepts_a_run():
    import mlflow

    mlflow.set_tracking_uri(config.MLFLOW_TRACKING_URI)
    mlflow.set_experiment("wk7_capstone_smoke")
    with mlflow.start_run(run_name="smoke") as run:
        mlflow.log_metric("ok", 1.0)
    assert run.info.run_id
