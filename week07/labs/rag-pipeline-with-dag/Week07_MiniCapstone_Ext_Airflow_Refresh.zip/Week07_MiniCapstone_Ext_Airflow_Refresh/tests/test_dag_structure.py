"""DAG-level tests: parsing, schedule semantics, and graph shape.

These require Airflow and are skipped automatically where it is not
installed (the main lab venv). Run them in any venv with
apache-airflow==3.3.1 after a one-time `airflow db migrate` (DagBag
dependency resolution touches the metadata DB), or inside the Airflow
container where standalone already migrated it:

  docker compose cp tests airflow:/opt/airflow/lab_tests
  docker compose exec airflow bash -c \
    "pip install pytest -q && CAPSTONE_TARGET=starter \
     python -m pytest /opt/airflow/lab_tests/test_dag_structure.py -q"

The instructor verification ledger records a full run.
"""

import os
from pathlib import Path

import pytest

airflow = pytest.importorskip("airflow", reason="apache-airflow not installed in this venv")

from airflow.dag_processing.dagbag import DagBag  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TARGET = os.getenv("CAPSTONE_TARGET", "starter").strip().lower()
DAGS_FOLDER = ROOT / TARGET / "airflow" / "dags"
if not DAGS_FOLDER.is_dir():
    # Inside the Airflow container the project tree is not rooted at the
    # copied test file, so the host-relative path above does not exist.
    # Fall back to the folder Airflow actually loads DAGs from there.
    from airflow.configuration import conf

    DAGS_FOLDER = Path(conf.get("core", "dags_folder"))


@pytest.fixture(scope="module")
def dagbag():
    # Tests read dagbag.dags (what was parsed from THIS folder) rather
    # than get_dag(), which can fall back to previously serialized DAGs
    # in the metadata database and mask a broken file.
    return DagBag(dag_folder=str(DAGS_FOLDER))


def test_dags_folder_has_no_import_errors(dagbag):
    # In the starter this fails until the legacy DAG is migrated (Task
    # E9): schedule_interval= raises TypeError at DAG construction on
    # Airflow 3.
    assert dagbag.import_errors == {}, f"import errors: {dagbag.import_errors}"


def test_refresh_dag_exists_with_expected_tasks(dagbag):
    dag = dagbag.dags.get("cordwell_kb_refresh")
    assert dag is not None
    expected = {"preflight", "ingest", "evaluate", "select",
                "route_on_verdict", "publish_report", "no_champion_alert"}
    assert set(dag.task_ids) == expected


def test_refresh_dag_schedule_is_daily_cron(dagbag):
    # Task E6: schedule="30 2 * * *" on Airflow 3.3 builds a
    # CronTriggerTimetable. schedule=None (the starter placeholder) or a
    # schedule_interval attempt both fail here.
    dag = dagbag.dags.get("cordwell_kb_refresh")
    assert dag is not None
    assert dag.timetable.expression == "30 2 * * *"
    assert type(dag.timetable).__name__ == "CronTriggerTimetable"
    assert dag.catchup is False
    assert dag.max_active_runs == 1


def test_preflight_gates_ingest(dagbag):
    # Task E8, edge one: ingest must not start before preflight passes.
    dag = dagbag.dags.get("cordwell_kb_refresh")
    assert dag is not None
    ingest = dag.get_task("ingest")
    assert "preflight" in ingest.upstream_task_ids


def test_branch_owns_both_outcomes(dagbag):
    # Task E8, edge two: both outcome tasks must be DIRECT downstreams of
    # the branch, or branching cannot skip the loser and both always run.
    dag = dagbag.dags.get("cordwell_kb_refresh")
    assert dag is not None
    branch = dag.get_task("route_on_verdict")
    assert branch.downstream_task_ids == {"publish_report", "no_champion_alert"}


def test_weekly_eval_dag_is_migrated(dagbag):
    # Task E9: the legacy DAG must parse (schedule= not
    # schedule_interval=) and its template must use data_interval_end;
    # execution_date was removed in Airflow 3 and raises UndefinedError
    # at RUN time even though the DAG parses.
    dag = dagbag.dags.get("cordwell_weekly_eval")
    assert dag is not None, "cordwell_weekly_eval missing (import error?)"
    assert dag.timetable.expression == "0 6 * * 1"
    task = dag.get_task("run_weekly_eval")
    template = task.op_kwargs["eval_date"]
    assert "data_interval_end" in template
    assert "execution_date" not in template
