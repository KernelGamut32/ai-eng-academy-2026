from pathlib import Path

from cordwell_rag import config
from cordwell_rag.corpus_loader import (
    load_corpus,
    parse_front_matter,
    read_text_tolerant,
    select_active_documents,
)

CORPUS = config.CORPUS_DIR


def test_read_text_tolerant_handles_cp1252(tmp_path: Path):
    p = tmp_path / "smart.md"
    p.write_bytes(b"He said \x93hello\x94 at the caf\xe9.")
    text = read_text_tolerant(p)
    assert "\u201chello\u201d" in text
    assert "caf\u00e9" in text


def test_read_text_tolerant_handles_utf8_bom(tmp_path: Path):
    p = tmp_path / "bom.md"
    p.write_bytes("plain".encode("utf-8-sig"))
    assert read_text_tolerant(p) == "plain"


def test_parse_front_matter_extracts_fields():
    text = '---\ndoc_id: x-1\ntitle: "A Title"\neffective_date: 2026-01-01\n---\n\nBody here.'
    meta, body = parse_front_matter(text)
    assert meta["doc_id"] == "x-1"
    assert meta["title"] == "A Title"
    assert body.strip() == "Body here."


def test_load_corpus_reads_all_documents_including_cp1252_file():
    docs = load_corpus()
    ids = {d.doc_id for d in docs}
    assert len(docs) == 31
    assert "guide-cordless-platforms" in ids  # the cp1252 file loads
    assert "pol-returns-2024" in ids and "pol-returns-2026" in ids


def test_select_active_documents_keeps_latest_per_family():
    docs = load_corpus()
    active = select_active_documents(docs)
    ids = {d.doc_id for d in active}
    assert "pol-returns-2026" in ids
    assert "pol-returns-2024" not in ids  # stale policy superseded
    assert len(active) == 30
