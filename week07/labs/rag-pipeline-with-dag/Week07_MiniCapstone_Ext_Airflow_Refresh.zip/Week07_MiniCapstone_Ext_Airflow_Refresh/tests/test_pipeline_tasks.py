"""Unit tests for the orchestration task functions. Airflow is NOT
required here: the functions are plain callables, which is the design
point. DAG-level behavior lives in test_dag_structure.py."""

import json

import pytest

from cordwell_rag import config
from cordwell_rag import pipeline_tasks as pt
from fakes import FakeIndex


VERDICT_CHAMPION = {
    "status": "champion_selected",
    "run_id": "abc123",
    "run_name": "grounded_strict-k3",
    "composite": 0.5251,
    "params": {"variant": "grounded_strict", "top_k": "3", "backend": "offline",
               "embedding_backend": "hash"},
    "metrics": {"groundedness": 0.749, "retrieval_hit_rate": 1.0,
                "abstain_recall": 0.667, "rougeL_f": 0.351, "answer_relevance": 0.401},
    "gate_failures": {"groundedness": 0, "retrieval_hit_rate": 0, "abstain_recall": 2},
}

COUNTS = {"documents_loaded": 31, "documents_active": 30, "chunks": 190,
          "duplicates_dropped": 6, "vectors_upserted": 190}


# ---------------------------------------------------------------------------
# check_services_or_raise (Task E1)
# ---------------------------------------------------------------------------


def test_preflight_reports_up_when_all_reachable(monkeypatch):
    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, timeout: None)
    status = pt.check_services_or_raise()
    assert status == {"pinecone": "up", "mlflow": "up"}


def test_preflight_raises_naming_every_down_service(monkeypatch):
    import httpx

    def _boom(url, timeout):
        raise httpx.ConnectError("refused")

    monkeypatch.setattr(httpx, "get", _boom)
    with pytest.raises(RuntimeError) as err:
        pt.check_services_or_raise()
    message = str(err.value)
    assert "pinecone" in message and "mlflow" in message
    assert "ConnectError" in message


# ---------------------------------------------------------------------------
# refresh_ingest (Task E2)
# ---------------------------------------------------------------------------


def _fake_store():
    from cordwell_rag.vector_store import PineconeLocalStore

    store = PineconeLocalStore.__new__(PineconeLocalStore)
    store.index = FakeIndex()
    store.ensure_fresh_index = lambda: None
    store.connect_existing_index = lambda: None
    return store


def test_refresh_ingest_returns_stage_counts(monkeypatch):
    store = _fake_store()
    monkeypatch.setattr(pt, "_build_store", lambda: store)
    counts = pt.refresh_ingest()
    assert counts["documents_loaded"] == 31
    assert counts["documents_active"] == 30
    assert counts["duplicates_dropped"] >= 5
    assert counts["vectors_upserted"] == counts["chunks"]
    assert len(store.index.vectors) == counts["chunks"]
    json.dumps(counts)  # XCom contract: plain JSON-serializable dict


def test_refresh_ingest_refuses_empty_chunking(monkeypatch):
    monkeypatch.setattr(pt, "_build_store", lambda: _fake_store())
    import cordwell_rag.pipeline_tasks as module
    import cordwell_rag.chunking as chunking

    monkeypatch.setattr(chunking, "chunk_corpus", lambda docs: ([], 0))
    with pytest.raises(RuntimeError):
        module.refresh_ingest()


def test_refresh_ingest_refuses_partial_upsert(monkeypatch):
    store = _fake_store()
    real_upsert = store.upsert_chunks
    store.upsert_chunks = lambda chunks, vectors: real_upsert(chunks, vectors) - 1
    monkeypatch.setattr(pt, "_build_store", lambda: store)
    with pytest.raises(RuntimeError) as err:
        pt.refresh_ingest()
    assert "partial" in str(err.value).lower() or "trustworthy" in str(err.value)


# ---------------------------------------------------------------------------
# run_refresh_sweep (Task E3): full sweep against fake store + sqlite MLflow
# ---------------------------------------------------------------------------


def test_run_refresh_sweep_logs_and_tags_runs(monkeypatch, tmp_path):
    import mlflow

    store = _fake_store()
    # Populate the fake index the same way ingest would.
    from cordwell_rag.chunking import chunk_corpus
    from cordwell_rag.corpus_loader import load_corpus, select_active_documents
    from cordwell_rag.embeddings import get_embedder

    chunks, _ = chunk_corpus(select_active_documents(load_corpus()))
    emb = get_embedder()
    store.upsert_chunks(chunks, emb.embed([c.text for c in chunks]))

    monkeypatch.setattr(pt, "_build_store", lambda: store)
    monkeypatch.setattr(config, "MLFLOW_TRACKING_URI", f"sqlite:///{tmp_path}/mlflow.db")
    monkeypatch.setattr(config, "TRULENS_DB_URL", f"sqlite:///{tmp_path}/trulens.sqlite")

    result = pt.run_refresh_sweep(refresh_tag="2026-08-14")
    assert len(result["run_ids"]) == 6
    assert result["refresh_tag"] == "2026-08-14"

    mlflow.set_tracking_uri(config.MLFLOW_TRACKING_URI)
    run = mlflow.tracking.MlflowClient().get_run(result["run_ids"][0])
    assert run.data.tags.get("refresh_tag") == "2026-08-14"


# ---------------------------------------------------------------------------
# write_refresh_report (Task E4)
# ---------------------------------------------------------------------------


def test_write_refresh_report_contents_and_path(monkeypatch, tmp_path):
    monkeypatch.setattr(config, "ARTIFACTS_DIR", tmp_path)
    path = pt.write_refresh_report(VERDICT_CHAMPION, COUNTS, run_date="2026-08-14")
    assert isinstance(path, str)
    assert path.endswith("refresh_2026-08-14.md")
    text = (tmp_path / "reports" / "refresh_2026-08-14.md").read_text()
    assert "2026-08-14" in text
    assert "grounded_strict-k3" in text
    assert "190" in text          # chunk count from ingest
    assert "groundedness" in text and "0.749" in text


# ---------------------------------------------------------------------------
# raise_no_champion (Task E5)
# ---------------------------------------------------------------------------


def test_raise_no_champion_names_gates_and_fails(monkeypatch):
    verdict = {"status": "no_eligible_run",
               "gate_failures": {"abstain_recall": 6, "groundedness": 1}}
    with pytest.raises(RuntimeError) as err:
        pt.raise_no_champion(verdict)
    message = str(err.value)
    assert "abstain_recall" in message and "6" in message
    assert "champion.json" in message
