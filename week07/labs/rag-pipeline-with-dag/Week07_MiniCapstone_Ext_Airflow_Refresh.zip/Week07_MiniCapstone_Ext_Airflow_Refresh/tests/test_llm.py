import pytest

from cordwell_rag.embeddings import HashEmbedder
from cordwell_rag.llm import _base_url_for, chat_completion, offline_extractive_answer, split_sentences
from cordwell_rag.config import ABSTAIN_MARKER


def test_split_sentences_basic():
    parts = split_sentences("First point. Second point! Third?")
    assert parts == ["First point.", "Second point!", "Third?"]


def test_offline_answer_extracts_relevant_sentence():
    emb = HashEmbedder()
    contexts = [
        "The standard return window is 30 days from purchase. Refunds post in 3 to 5 business days.",
        "Shear bolts protect the auger gearbox from impact loads.",
    ]
    text, score = offline_extractive_answer(
        "how long is the standard return window", contexts, emb,
        max_sentences=1, abstain_threshold=None,
    )
    assert "30 days" in text
    assert score > 0.3


def test_offline_answer_abstains_below_threshold():
    emb = HashEmbedder()
    contexts = ["Shear bolts protect the auger gearbox from impact loads."]
    text, score = offline_extractive_answer(
        "does cordwell offer a military discount", contexts, emb,
        max_sentences=2, abstain_threshold=0.30,
    )
    assert text.startswith(ABSTAIN_MARKER)
    assert score < 0.30


def test_unknown_backend_raises_value_error():
    with pytest.raises(ValueError):
        _base_url_for("bedrock")


def test_offline_backend_refuses_chat_completion():
    with pytest.raises(ValueError):
        chat_completion([{"role": "user", "content": "hi"}], backend="offline")


def test_dead_server_raises_connection_error_no_silent_fallback():
    import openai

    with pytest.raises(openai.APIConnectionError):
        chat_completion(
            [{"role": "user", "content": "hi"}],
            backend="ollama",
            base_url_override="http://127.0.0.1:9/v1",  # nothing listens on port 9
            timeout=0.5,
            max_retries=0,
        )
