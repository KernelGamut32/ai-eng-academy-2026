from cordwell_rag import config
from cordwell_rag.chunking import Chunk
from cordwell_rag.embeddings import HashEmbedder
from cordwell_rag.rag import VARIANTS, RagPipeline, format_context_block
from cordwell_rag.vector_store import PineconeLocalStore
from fakes import FakeIndex


def _pipeline(variant="grounded_strict", top_k=3):
    emb = HashEmbedder()
    store = PineconeLocalStore.__new__(PineconeLocalStore)
    store.index = FakeIndex()
    texts = [
        "The standard return window is 30 days from purchase with a receipt.",
        "CordPerks Platinum members receive an extended 90 day return window.",
        "Shear bolts protect the auger gearbox and break on impact.",
    ]
    chunks = [
        Chunk(chunk_id=f"d{i}::c000", doc_id=f"d{i}", doc_family=f"d{i}", title=f"T{i}",
              category="test", effective_date="2026-01-01", seq=0, text=t)
        for i, t in enumerate(texts)
    ]
    store.upsert_chunks(chunks, emb.embed(texts))
    return RagPipeline(emb, store, VARIANTS[variant], top_k=top_k)


def test_variants_exist_with_expected_contracts():
    assert set(VARIANTS) == {"baseline", "grounded_strict", "concise"}
    assert VARIANTS["baseline"].offline_abstain_threshold is None
    assert VARIANTS["grounded_strict"].offline_abstain_threshold is not None
    assert config.ABSTAIN_MARKER in VARIANTS["grounded_strict"].system_prompt


def test_format_context_block_numbers_and_attributes():
    block = format_context_block([
        {"text": "alpha", "title": "Doc A", "doc_id": "a", "effective_date": "2026-01-01"},
        {"text": "beta", "title": "Doc B", "doc_id": "b", "effective_date": "2026-02-01"},
    ])
    assert "[1]" in block and "[2]" in block
    assert "Doc A" in block and "beta" in block


def test_retrieve_returns_top_k_and_saves_matches():
    p = _pipeline(top_k=2)
    contexts = p.retrieve("what is the standard return window")
    assert len(contexts) == 2
    assert len(p.last_matches) == 2
    assert "30 days" in contexts[0]


def test_answer_offline_is_grounded_in_context():
    p = _pipeline()
    answer = p.answer("what is the standard return window")
    assert "30 days" in answer


def test_answer_offline_abstains_when_context_is_irrelevant():
    p = _pipeline()
    answer = p.answer("what is the airspeed velocity of an unladen swallow")
    assert answer.startswith(config.ABSTAIN_MARKER)
