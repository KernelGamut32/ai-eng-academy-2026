from cordwell_rag import config
from cordwell_rag.chunking import chunk_corpus, chunk_document, dedupe_chunks
from cordwell_rag.corpus_loader import Document, load_corpus, select_active_documents


def _doc(body: str, doc_id: str = "t-doc") -> Document:
    return Document(
        doc_id=doc_id, doc_family=doc_id, title="T", category="test",
        effective_date="2026-01-01", version="1", path=None, body=body, meta={},
    )


def test_chunk_ids_are_stable_and_sequential():
    chunks = chunk_document(_doc("## A\n\nalpha\n\n## B\n\nbeta"))
    assert [c.chunk_id for c in chunks] == ["t-doc::c000", "t-doc::c001"]


def test_no_chunk_exceeds_max_chars_even_without_headings():
    monster = " ".join(f"word{i}" for i in range(20000))  # no headings at all
    chunks = chunk_document(_doc(monster))
    assert len(chunks) > 1
    assert all(len(c.text) <= config.CHUNK_MAX_CHARS for c in chunks)


def test_single_giant_paragraph_is_sliced_with_overlap():
    para = "x" * 5000  # one paragraph, no spaces, no headings
    chunks = chunk_document(_doc(para))
    assert all(len(c.text) <= config.CHUNK_MAX_CHARS for c in chunks)
    # Overlap: the tail of chunk N reappears at the head of chunk N+1.
    assert chunks[1].text[: config.CHUNK_OVERLAP_CHARS] == chunks[0].text[-config.CHUNK_OVERLAP_CHARS :]


def test_real_transcript_curveball_stays_within_limits():
    docs = select_active_documents(load_corpus())
    transcript = next(d for d in docs if d.doc_id == "ops-hotline-digest-0417")
    assert len(transcript.body) > 40000  # the trap is real
    chunks = chunk_document(transcript)
    assert all(len(c.text) <= config.CHUNK_MAX_CHARS for c in chunks)


def test_dedupe_drops_exact_duplicates_first_wins():
    a = chunk_document(_doc("## S\n\nsame text", doc_id="first"))
    b = chunk_document(_doc("## S\n\nsame text", doc_id="second"))
    kept, dropped = dedupe_chunks(a + b)
    assert dropped == 1
    assert [c.doc_id for c in kept] == ["first"]


def test_archived_duplicate_manual_is_deduped_in_real_corpus():
    docs = select_active_documents(load_corpus())
    chunks, dropped = chunk_corpus(docs)
    assert dropped >= 5  # the archive VexLine copy collapses onto the original
    survivors = {c.doc_id for c in chunks if "vexline" in c.doc_id}
    assert len(survivors) == 1  # only one copy's chunks remain
