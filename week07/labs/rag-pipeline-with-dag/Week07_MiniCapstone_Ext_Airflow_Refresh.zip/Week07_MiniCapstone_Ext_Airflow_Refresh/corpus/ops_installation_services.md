---
doc_id: ops-install-services
doc_family: ops-install-services
title: Cordwell Installation Services Scope and Scheduling Guide
category: ops
effective_date: 2025-12-01
version: "2.4"
owner: Services Organization
---

## What Installation Services covers

Cordwell Installation Services arranges licensed, insured, background-checked installation professionals for flooring, water heaters, ceiling fans and lighting, smart thermostats, garage door openers, storm doors and entry doors, gas appliance connections, and dishwasher replacement. Every installation includes a 1 year labor warranty on the workmanship, separate from the product warranty. Services vary by market; the services desk terminal shows live availability by ZIP code.

## Measures and quotes

Flooring and door projects begin with an in-home measure, 35 dollars, credited in full against the project when the customer proceeds within 90 days. Measures produce a fixed installed-price quote covering materials, labor, and listed prep items. Water heater, thermostat, ceiling fan, and opener installations quote flat rates at the desk or online, with the installer confirming site conditions on arrival; site surprises such as code-required expansion tanks, fan-rated box replacement, or non-standard venting add from a printed price sheet the installer carries, agreed before work starts.

## Scheduling flow

After purchase, the installation partner contacts the customer within 2 business days to schedule. Standard scheduling windows run 5 to 10 business days out for most trades, longer in storm season for roofing-adjacent work. Customers can reach the services line for reschedules; same-day cancellations by the customer may incur a trip fee stated on the order.

## Permits and code

Installations that commonly require permits, including water heaters and gas connections, are permitted by the installing contractor where the jurisdiction requires it, with permit costs itemized on the quote. Installers will not bypass code requirements on request, including expansion tanks on closed systems, pan and drain requirements, or seismic strapping where applicable, and will document any customer-declined corrective work.

## When something goes wrong

Workmanship concerns within the 1 year labor warranty are filed at the services desk or the services line with photos where possible; the installing contractor is dispatched to remediate. Product failures route to the product warranty or ShieldCare where purchased. Damage claims are acknowledged within 1 business day and carry through the installation partner's insurance.
