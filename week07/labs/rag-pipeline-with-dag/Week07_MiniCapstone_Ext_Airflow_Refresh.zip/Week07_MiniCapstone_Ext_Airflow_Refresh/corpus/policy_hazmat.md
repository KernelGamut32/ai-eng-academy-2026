---
doc_id: pol-hazmat
doc_family: hazmat-policy
title: Hazardous Goods Handling, Exchange, and Recycling
category: policy
effective_date: 2025-04-20
version: "2.3"
owner: Environmental Health and Safety
---

## Propane tank exchange

Cordwell offers 20 pound propane tank exchange at all stores during regular hours. Bring the empty tank to the designated exchange cage at the front of the store and see any associate; never bring propane tanks inside the building. Exchanged tanks must be standard 20 pound grill cylinders with an intact OPD valve. Expired or damaged customer tanks are accepted into the exchange but a full-price exchange applies. Purchased exchange tanks are stored in the locked cage and released by an associate.

## Battery recycling

Cordwell accepts rechargeable batteries, including power tool packs up to 300 watt hours, cordless phone batteries, and laptop batteries, for free recycling at the service desk drop bin. Terminals must be taped before drop-off. Single-use alkaline batteries, damaged or swollen lithium packs, and electric vehicle batteries are not accepted; swollen packs should go to a municipal household hazardous waste facility.

## Paint and stain disposal

Cordwell stores do not accept leftover liquid paint for disposal. Latex paint can be dried at home with paint hardener or cat litter and then placed in household trash with the lid off where local rules allow. Oil-based paints, stains, and solvents are household hazardous waste and must go to a municipal collection event or facility. Empty, dry metal paint cans are accepted in the store's steel recycling bin at the outdoor lumber entrance.

## Fuel, propane, and pool chemical storage rules

Gasoline, kerosene, and premixed fuel are sold only in approved containers and may not be transported in open truck beds alongside pool chemicals. Pool chemicals must remain sealed, upright, and separated from fuels and fertilizers in the cart, at the register, and in the vehicle. Associates are trained to bag oxidizers separately and will decline to load incompatible chemicals together.

## Spill response in store

Any liquid spill in a chemical aisle is treated as hazardous until identified. Associates block the aisle, notify the manager on duty, and use the spill kit staged at each chemical aisle endcap. Customers should report spills to any associate and avoid walking through them.
