---
doc_id: how-stain-deck
doc_family: howto-stain-deck
title: How to Clean and Stain a Wood Deck
category: howto
effective_date: 2025-04-28
version: "1.1"
owner: Project Content Team
---

## When to stain

New pressure-treated lumber arrives saturated with treatment solution and must dry before it can absorb stain; depending on climate, allow 4 to 8 weeks after installation, then confirm readiness with the water drop test: sprinkle water on several boards, and if it soaks in within 10 minutes the wood is ready, while beading water means wait longer. For restains, the same test tells you whether the old finish has weathered enough to accept new stain. Plan around weather: most stains want surface temperatures between 50 and 90 degrees Fahrenheit and 24 to 48 hours without rain after application.

## Cleaning comes first

Stain locks in whatever is under it. Sweep, then apply a deck cleaner appropriate to the situation: an oxygenated cleaner for gray weathered wood and general grime, or a stain stripper where an old film-forming finish is peeling. Scrub with a stiff synthetic brush, keep surfaces wet with cleaner for the labeled dwell time, and rinse thoroughly. A pressure washer helps at low pressure with a fan tip kept moving 12 inches from the wood; concentrated pressure cuts fuzzy grooves in softwood that show through stain. Let the deck dry 48 hours after washing, then re-run the water drop test.

## Choosing a stain type

Transparent penetrating stains show the most grain and are easiest to refresh but weather fastest on horizontal surfaces. Semi-transparent stains balance grain visibility with pigment protection and are the most common deck choice. Solid stains behave like paint, hide old discoloration and mismatched boards completely, and last longest on rails, but they form a film that eventually peels on walking surfaces and commits future coats to solid. Whatever the type, buy all cans at once and box them together, mixing them in one large container so color stays consistent across the whole deck.

## Application

Cut in edges and rail details with a brush, then coat deck boards two or three at a time for their full length with a stain pad or brush, maintaining a wet edge so lap marks cannot form mid-board. Penetrating stains want thin coats: apply what the wood absorbs and back-brush any puddles within 10 minutes, since penetrating stain left sitting on the surface dries to a shiny, sticky film. Most penetrating products want a single coat on horizontal surfaces; a second coat, where the label allows, applies wet-on-wet within the labeled window rather than after full drying.

## Maintenance

Horizontal surfaces weather two to three times faster than verticals. Expect to refresh walking surfaces every 1 to 3 years for penetrating stains, washing first and recoating only when the water drop test shows absorption. Keep gaps between boards clear of debris with a putty knife each spring so boards can drain and dry.
