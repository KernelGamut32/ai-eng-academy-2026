---
doc_id: sds-proseal-cs40
doc_family: proseal-sealer-sds
title: ProSeal CS-40 Solvent-Based Concrete Sealer Safety Summary
category: sds
effective_date: 2025-05-30
version: "2.0"
owner: Environmental Health and Safety
---

## Product identification

ProSeal CS-40 is a solvent-based acrylic concrete sealer for exterior driveways, patios, and walkways, producing a gloss wet look finish. The carrier solvent is a xylene blend, which makes the wet product flammable and its vapors heavier than air. This summary supports store handling and customer guidance; the full Safety Data Sheet is available at the ProDesk and on the supplier portal.

## Hazards overview

CS-40 is a Category 3 flammable liquid. Vapors can travel along the ground to ignition sources including water heater pilots and garage appliances, and can accumulate in low or enclosed spaces. Vapor exposure above workplace limits causes headache, dizziness, and respiratory irritation. Liquid contact defats skin and irritates eyes. The cured film, typically dry to touch in 2 hours and cured in 24 to 48 hours, is not hazardous.

## Safe application guidance for customers

Apply outdoors only, never in enclosed garages or basements, in temperatures between 50 and 90 degrees Fahrenheit with no rain expected for 24 hours. Extinguish pilot lights and remove ignition sources within 50 feet, including grills and smoking materials. Wear chemical-resistant gloves, safety glasses, and, for anyone sensitive to solvent vapors or working near the application, an organic vapor respirator. Apply thin coats with a solvent-resistant roller or pump sprayer with viton seals; heavy coats trap solvent and stay tacky or turn white. Two thin coats beat one thick coat.

## Storage and transport

Store upright, tightly closed, between 40 and 95 degrees Fahrenheit, away from ignition sources and out of sun-heated vehicle interiors. Transport upright and secured, never in a closed passenger cabin for long trips; use the trunk or truck bed with the cap checked. In-store, CS-40 lives in the flammable cabinet aisle with signage, and spill response follows the chemical aisle spill kit procedure.

## First aid summary

For inhalation symptoms, move to fresh air. For skin contact, wash with soap and water and remove contaminated clothing. For eye contact, rinse 15 minutes with water and seek medical attention if irritation persists. If swallowed, do not induce vomiting and contact poison control immediately. For fire, use foam, carbon dioxide, or dry chemical; water spray can spread burning product.

## Disposal

Liquid CS-40 is household hazardous waste and goes to a municipal collection facility, never in the trash or a drain. Fully dried empty containers may go in household trash where local rules allow. Rags wet with CS-40 can self-heat as solvents oxidize; dry rags flat outdoors or store submerged in water in a sealed metal container before disposal.
