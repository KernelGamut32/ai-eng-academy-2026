---
doc_id: man-frostbreaker-fb24
doc_family: frostbreaker-snowblower-manual
title: FrostBreaker 24 Inch Two-Stage Snow Blower FB-24 Owner's Manual
category: manual
effective_date: 2025-09-08
version: "B"
owner: Merchandising Content
---

## Specifications

The FrostBreaker FB-24 is a two-stage gas snow blower with a 212cc four-cycle OHV engine, a 24 inch clearing width, a 21 inch intake height, a serrated steel auger, a 12 inch steel impeller, six forward and two reverse drive speeds, and a 200 degree remote chute rotation crank. Tire size is 15 x 5 inches. Fuel capacity is 0.6 gallons of fresh unleaded gasoline, 87 octane or higher, with no more than 10 percent ethanol. Engine oil capacity is 20 ounces of 5W-30.

## Shear bolt system

The auger is fastened to the auger shaft with shear bolts designed to break and protect the gearbox when the auger strikes a solid object such as ice, a curb, or a newspaper. Use only genuine FrostBreaker shear bolts, part FB-SB25, which are sized to break at the correct load. Substituting ordinary hardware bolts defeats this protection and leads to gearbox failure that is not covered by warranty. Two spare shear bolts and a spanner are clipped inside the belt cover. To replace a broken bolt, stop the engine, remove the key, wait for all motion to stop, align the auger hole with the shaft hole, and install the new bolt and locknut.

## Safe clearing practice

Never place hands or feet inside the auger housing or discharge chute while the engine is running, and never clear a clog by hand. Use the clean-out tool clipped to the handle panel after stopping the engine and confirming the impeller has stopped; an impeller under spring load can rotate when a clog releases even with the engine off. Wear eye protection and footwear with good traction. Discharge snow downwind and never toward people, vehicles, or glass.

## Starting procedure

Check oil before every use. Move the fuel valve to open, set the choke to full on a cold engine, set the throttle to fast, press the primer bulb three times in cold weather, and pull the starter grip or use the 120 volt electric start button with the extension cord connected. Move the choke to run as the engine warms. Let the machine run 2 to 3 minutes before engaging the auger in temperatures below 10 degrees Fahrenheit.

## End of season storage

Run the fuel system dry or treat fuel with stabilizer and run 5 minutes to circulate. Change the oil while the engine is warm. Wipe the auger housing dry, touch up paint chips on the auger and impeller, coat bare metal lightly with silicone spray, and store under cover. Replace any shear bolts showing partial shear before storage so the machine is ready for the first storm.

## Troubleshooting

If the engine starts then dies, the fuel is likely stale or the fuel valve is closed. If the machine moves but throws snow weakly, check for a worn or stretched auger drive belt and for broken shear bolts allowing the auger to freewheel. If the chute clogs repeatedly in wet snow, take smaller bites at a faster ground speed and coat the chute interior with silicone spray. If one auger side spins freely by hand with the engine off and key removed, a shear bolt has broken on that side.

## Warranty

The FB-24 carries a 3 year residential limited warranty and a 1 year commercial warranty. Belts, skid shoes, scraper bars, and shear bolts are wear items. See the current FrostBreaker service bulletin board at any Cordwell service desk for open recalls and service campaigns before the first use of each season.
