---
doc_id: pol-giftcards-cordperks
doc_family: giftcard-loyalty-policy
title: Gift Cards and the CordPerks Loyalty Program
category: policy
effective_date: 2025-08-12
version: "1.6"
owner: Customer Operations
---

## Gift card terms

Cordwell gift cards never expire and carry no dormancy or maintenance fees. Cards are redeemable for merchandise and services at any Cordwell store and online, but are not redeemable for cash except where state law requires redemption of small remaining balances. Lost or stolen gift cards can be replaced only if the original card number and proof of purchase are provided. Gift cards cannot be used to purchase other gift cards.

## CordPerks free tier

CordPerks membership is free and earns 1 point per dollar spent on eligible purchases. Every 500 points converts automatically to a 5 dollar CordPerks reward, delivered to the member's account and usable in store or online. Members also receive digital receipts, purchase history for easy returns, and member-only coupon events.

## CordPerks Platinum

CordPerks Platinum is a paid tier at 79 dollars per year. Platinum benefits include an extended 90 day return window on most merchandise, free standard shipping on orders of 29 dollars or more, 1.5 points per dollar on eligible purchases, four times per year 5x point events, and a dedicated Platinum phone line. Platinum benefits apply only to purchases made while the membership is active.

## Points and rewards rules

Points are not earned on gift card purchases, taxes, delivery fees, installation labor, or prior purchases. Points post within 24 hours of purchase and rewards expire 90 days after issuance. Returns deduct the points earned on the returned item. CordPerks rewards cannot be converted to cash and have no value until issued as a reward.

## Account management

Members can merge duplicate accounts, update contact information, and view point balances in the Cordwell app or at any register. Fraudulent point activity, including reselling rewards, may result in forfeiture of the account balance and termination of membership.
