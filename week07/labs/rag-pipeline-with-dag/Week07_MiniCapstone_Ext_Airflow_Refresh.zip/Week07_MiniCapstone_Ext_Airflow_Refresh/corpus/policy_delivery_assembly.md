---
doc_id: pol-delivery
doc_family: delivery-policy
title: Delivery, Haul-Away, and Assembly Services
category: policy
effective_date: 2025-11-03
version: "2.1"
owner: Supply Chain Services
---

## Standard shipping

Orders of 45 dollars or more qualify for free standard shipping to a home address for eligible items. Orders under 45 dollars ship at a flat rate of 6.99. Standard shipping arrives in 3 to 6 business days. Oversized items that ship by freight carrier display a calculated freight charge at checkout.

## Major appliance delivery

Major appliance delivery is free on appliance purchases of 499 dollars or more, and 79 dollars otherwise. Appliance delivery includes placement in the room of your choice, unboxing, basic hookup of a new electric range, refrigerator, washer, or dryer where compatible connections already exist, and a function test. Gas appliance connections require a licensed installation and are scheduled separately through Cordwell Installation Services.

Delivery teams call or text a four hour arrival window the evening before delivery. An adult 18 years or older must be present to receive the delivery and inspect the appliance. Any visible damage should be noted with the driver before signing; concealed damage must be reported within 48 hours under the return policy.

## Haul-away and recycling

Old appliance haul-away is available for 30 dollars per unit when a replacement appliance is delivered, and includes environmentally responsible recycling of the removed unit. The old unit must be disconnected, defrosted, and emptied before the delivery team arrives. Haul-away without a replacement delivery is not offered.

## Assembly services

Free in-store assembly is included with grills, wheelbarrows, and patio furniture purchased at full price; allow 24 hours notice for pickup scheduling. In-home assembly is available for select items through Cordwell Installation Services at rates quoted during checkout.

## Missed deliveries

If no eligible adult is present during the arrival window, the delivery is returned to the local hub and rescheduling may take 2 to 4 business days. A second missed appointment may incur a 49 dollar redelivery fee.
