---
doc_id: how-replace-toilet
doc_family: howto-replace-toilet
title: How to Remove and Replace a Toilet
category: howto
effective_date: 2025-03-09
version: "1.0"
owner: Project Content Team
---

## Measure the rough-in first

Before buying, measure from the finished wall, not the baseboard, to the center of the closet bolts holding the existing bowl. The standard rough-in is 12 inches; 10 and 14 inch rough-ins exist in older homes and require matching toilets. Also confirm bowl shape clearance: elongated bowls extend about 2 inches farther than round bowls, which matters in small bathrooms with doors that swing near the bowl.

## Remove the old toilet

Shut the supply stop at the wall and flush, holding the lever down to drain the tank fully, then sponge or wet-vacuum the remaining water from the tank and bowl. Disconnect the supply line at the tank. Pry the closet bolt caps, remove the nuts, break the caulk seal at the base with a utility knife, and rock the bowl gently to free it from the wax. Lift with your legs and set the old toilet on cardboard. Immediately stuff a rag in the open drain; sewer gas is unpleasant and dropped tools are worse.

## Prepare the flange

Scrape the old wax off the closet flange with a putty knife. Inspect the flange: it should sit on top of the finished floor, be solidly fastened, and be intact where the closet bolts slot in. A cracked or corroded flange ring gets a repair ring or flange replacement before any new toilet is set; setting a toilet on a broken flange guarantees rocking and leaks. Set new closet bolts upright in the flange slots, held vertical with washers or a dab of wax.

## Set the new toilet

Choose a seal: a traditional wax ring is reliable and forgiving on a correct-height flange, while a waxless rubber seal suits flanges slightly below floor level and allows repositioning, something wax never forgives, since lifting a toilet after compression ruins the wax seal and requires a fresh ring. Place the seal, lower the bowl straight down over the bolts using the bolts as guides, and press with body weight straight down without rocking until the bowl sits on the floor. Snug the nuts alternately and gently; porcelain cracks from overtightening. Cut bolt excess, cap, connect the supply, and open the stop slowly.

## Final checks

Check for leaks at the supply and around the base through several flushes, then caulk the base perimeter, leaving the back few inches open so a future seal failure shows itself at the back instead of hiding under caulk. Adjust the fill valve so water stops about 1 inch below the overflow tube top.
