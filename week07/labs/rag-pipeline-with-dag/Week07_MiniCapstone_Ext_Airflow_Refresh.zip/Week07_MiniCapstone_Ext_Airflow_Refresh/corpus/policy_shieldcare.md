---
doc_id: pol-shieldcare
doc_family: shieldcare-policy
title: Cordwell ShieldCare Protection Plans
category: policy
effective_date: 2025-06-01
version: "1.8"
owner: Protection Services
---

## Plan overview

Cordwell ShieldCare protection plans extend coverage beyond the manufacturer warranty on eligible appliances, power tools, outdoor power equipment, and smart home products. Plans are available in 2 year and 4 year terms, measured from the date of purchase, and coverage begins the day the manufacturer warranty expires for failure coverage while several benefits begin on day one.

## What ShieldCare covers

ShieldCare covers mechanical and electrical failures that occur during normal household use, including failures caused by power surges, dust, internal heat, and normal wear. There is no deductible and no fee for covered service calls. If a covered product cannot be repaired, Cordwell replaces it with a product of comparable specifications or issues a store credit for the original purchase price, at Cordwell's option. A plan that ends in a replacement or payout is considered fulfilled.

## Day one benefits

The following benefits apply from the date of purchase rather than waiting for the manufacturer warranty to end. Refrigerator and freezer plans include food loss reimbursement of up to 300 dollars per covered spoilage event. Washer plans include one laundry reimbursement of up to 25 dollars if a covered failure damages a load of laundry. Power tool and outdoor power equipment plans include a 20 percent reimbursement on scheduled maintenance parts such as blades, belts, spark plugs, and filters purchased at Cordwell.

## Transfer and cancellation

ShieldCare plans are fully transferable to a new owner at no charge, which is useful when selling a home with covered appliances. Plans may be cancelled for a full refund within 30 days of purchase if no claim has been filed, and for a prorated refund afterward.

## Filing a claim

Claims are filed online at the ShieldCare service portal or by phone through the Cordwell service line. Have the receipt or CordPerks account used at purchase available. Most repairs are scheduled with an authorized technician within 2 business days, and ShieldCare covers in-home service for major appliances and bench service for tools dropped at any Cordwell service desk.
