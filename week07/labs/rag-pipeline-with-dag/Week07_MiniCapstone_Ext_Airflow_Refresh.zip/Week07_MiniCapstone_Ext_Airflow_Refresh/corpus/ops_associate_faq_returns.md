---
doc_id: ops-returns-desk-faq
doc_family: ops-returns-desk
title: Returns Desk Associate FAQ and Procedures
category: ops
effective_date: 2026-02-15
version: "4.0"
owner: Store Operations
---

## Receipt lookup order

When a customer has no paper receipt, search in this order before treating the transaction as no-receipt: the CordPerks account phone number, the payment card used (swipe or insert the same card at the returns terminal to search), and the online order number from the confirmation email. A transaction found by any of these methods is a receipted return and refunds to the original payment method under the standard 30 day window, or 90 days for CordPerks Platinum purchases.

## No-receipt flow

No-receipt returns require a valid government-issued photo ID scanned into the return verification system, refund as store credit at the item's lowest advertised price in the previous 90 days, and may be declined when the verification system flags the ID. Do not override verification declines; refer the customer to the printed slip with the verification provider's contact information. Managers cannot override system declines either, and telling customers otherwise creates escalations the desk cannot resolve.

## Appliance and delivery-damage returns

Damage reported within 48 hours of appliance delivery is handled by the desk as a delivery claim, not a standard return: file the claim in the delivery portal, offer exchange or repair first, and route refunds through the claim so the delivery partner chargeback processes. After 48 hours, route the customer to the manufacturer warranty line or, if they purchased ShieldCare, to the ShieldCare portal.

## Serialized merchandise checks

Generators, gas-powered outdoor equipment, and tool combo kits require serial verification: the serial on the unit, the carton, and the receipt line must match before any refund. Mismatches go to the manager on duty. Gas-powered equipment showing any fuel residue is never restocked; process approved returns of fueled equipment as defective-out and stage them in the hazmat cage, never on the returns cart.

## Live goods

Perennials, trees, and shrubs returned dead within 365 days with receipt or tag are replaced or refunded once per original item under the live goods guarantee. Log the plant SKU and reason code so nursery merchandising sees mortality patterns. Annuals and holiday plants follow the standard window.

## Escalation guardrails

Associates may approve exceptions up to 50 dollars once per customer per rolling 90 days with a documented reason code. Anything beyond that goes to the manager on duty. Never promise policy exceptions in advance or in writing, and never quote the old 90 day standard window from the pre-2026 policy; the current standard window is 30 days and the printed signage at the desk reflects it.
