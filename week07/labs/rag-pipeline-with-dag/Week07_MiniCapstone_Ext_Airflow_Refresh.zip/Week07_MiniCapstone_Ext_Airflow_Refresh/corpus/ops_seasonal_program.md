---
doc_id: ops-seasonal-storage
doc_family: ops-seasonal-storage
title: Seasonal Merchandising and Holiday Program Calendar
category: ops
effective_date: 2025-08-25
version: "3.1"
owner: Merchandising Operations
---

## Season transitions

Cordwell stores run four hard seasonal transitions: spring set in late January, summer set in late April, harvest and Halloween set in early August, and holiday set the week after Halloween sell-through, with trim-a-tree opening no later than the first week of November. Transition weeks double receiving volume; overnight crews flip the seasonal pad and drive aisle within 5 nights per the plan-o-gram packet for that season.

## Live goods cadence

Nursery receiving begins with cold-tolerant pansies and early perennials at spring set, ramps weekly through the regional last-frost date, and peaks Mothers Day week, the single largest live goods week of the year. Trees and shrubs receive twice weekly in season with a mandatory same-day watering scan; mortality logged at the returns desk under the live goods guarantee feeds the regional buyer's vendor scorecards.

## Holiday program

The holiday program centers on trim-a-tree, gift center, and the holiday lighting wall. Light strings display by technology and bulb count with a powered demo rail; returns of opened light strings spike the first week of December and are processed under the seasonal policy, which keeps holiday merchandise returnable through the applicable holiday date. After-holiday clearance begins the morning of December 26 with markdown cadence 50, 75, then 90 percent across 3 weeks, and remaining goods after week 3 route to the salvage consolidator, not to donation, because tested-defective light strings cannot be donated.

## Snow program

Snow response stores in designated regions stage snow blowers, shovels, ice melt, and roof rakes on the power pad by mid October. When the regional desk issues a storm alert, participating stores extend receiving hours and cross-dock ice melt pallets directly to the front drive aisle. FrostBreaker units assemble at a maximum rate of 8 per associate shift with torque-checked shear bolts, and any unit on the recall service bulletin list is pulled from the pad the same day the bulletin posts.
