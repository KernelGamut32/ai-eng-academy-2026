---
doc_id: man-vexline-vx20dd1-archive
doc_family: vexline-drill-manual-archive
title: VexLine 20V MAX Cordless Drill/Driver VX20-DD1 Owner's Manual
category: manual
effective_date: 2025-05-10
version: "B"
owner: Content Migration Batch 12
---

## Specifications

The VexLine VX20-DD1 is a 20 volt MAX cordless drill/driver with a 1/2 inch single-sleeve ratcheting keyless chuck. It delivers 380 inch-pounds of maximum torque through a two-speed gearbox: speed 1 runs 0 to 450 RPM for driving fasteners and speed 2 runs 0 to 1800 RPM for drilling. The clutch collar provides 24 clutch positions plus a dedicated drill mode. The kit ships with one 2.0 amp-hour lithium-ion battery pack (model VXB-20), a rapid charger (model VXC-1A) that charges the 2.0Ah pack in approximately 60 minutes, a double-ended driver bit, and a belt hook. Bare tool weight is 2.6 pounds.

## Safety warnings

Read all safety warnings before operating. Wear eye protection at all times. Remove the battery pack before changing bits, making adjustments, or storing the tool. Do not expose the battery pack to fire, temperatures above 130 degrees Fahrenheit, or water. Charge only with the supplied VexLine charger. Secure loose clothing and long hair away from the rotating chuck. When drilling into walls, verify the location of electrical wiring and plumbing before drilling.

## Operating instructions

To install a bit, rotate the chuck sleeve counterclockwise to open the jaws, insert the bit fully, and tighten clockwise by hand until the ratchet clicks. Select speed 1 for screws and large-diameter drilling in wood, and speed 2 for small-diameter drilling in wood and metal. Set the clutch collar to a low number for small screws and soft material, increasing the number until the screw seats flush without cam-out; use the drill symbol for drilling so the clutch never slips. The forward/reverse selector above the trigger also locks the trigger in its center position; always center-lock the trigger when changing bits.

## Battery and charger care

The VXB-20 pack has a three-LED fuel gauge; press the gauge button to check charge. The pack stops delivering power when protection circuitry detects deep discharge, overload, or overheating; release the trigger and allow the pack to rest or cool, which is normal behavior rather than a defect. Store packs between 40 and 80 degrees Fahrenheit at 40 to 60 percent charge for long storage. The charger's red light indicates charging, green indicates fully charged, and a flashing red/green pattern indicates a pack fault.

## Troubleshooting

If the drill does not run, confirm the pack is charged and fully seated and the trigger is not center-locked. If the chuck slips on round-shank bits, open the jaws fully, reseat the bit centered between all three jaws, and retighten firmly. If runtime drops noticeably in cold weather, warm the pack to room temperature before use; lithium packs deliver reduced capacity below freezing. If the tool stops under heavy load and the fuel gauge flashes, the overload protection has tripped; release the trigger and resume with a lower speed or smaller bit.

## Warranty

The VX20-DD1 tool is covered by a 3 year limited warranty against defects in materials and workmanship. VexLine batteries and chargers carry a 2 year limited warranty. Warranty service is available through any Cordwell service desk with proof of purchase. The warranty does not cover normal wear items, damage from misuse, water exposure, or use of non-VexLine chargers or packs.