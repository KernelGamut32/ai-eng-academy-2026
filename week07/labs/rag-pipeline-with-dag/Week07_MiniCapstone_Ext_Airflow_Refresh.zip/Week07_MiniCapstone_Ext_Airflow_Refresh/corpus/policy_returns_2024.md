---
doc_id: pol-returns-2024
doc_family: returns-policy
title: Cordwell Home & Hardware Return and Refund Policy
category: policy
effective_date: 2024-03-01
version: "2.7"
owner: Customer Operations
---

## Standard return window

Most new, unopened merchandise sold by Cordwell Home & Hardware may be returned within 90 days of purchase for a full refund to the original form of payment. A valid receipt or order confirmation is required. Items returned opened but in resalable condition within the same 90 day window may be refunded at the discretion of the store manager on duty.

## Category exceptions

Major appliances, including refrigerators, ranges, dishwashers, washers, and dryers, may be returned or exchanged within 30 days of delivery if unused and in original packaging. Delivery damage must be noted on the delivery paperwork at the time of receipt.

Gas-powered outdoor equipment may be returned within 90 days if unused and containing no fuel or oil. Once fueled, equipment is serviced under the manufacturer warranty through an authorized service center.

Custom and special-order products, including cut-to-length blinds, mixed paint, and special-order cabinetry, are not returnable except where defective.

## Live goods guarantee

Perennials, trees, and shrubs are covered by the Cordwell one year live goods guarantee with receipt. Annuals follow the standard return window.

## Returns without a receipt

Returns without proof of purchase require a valid government-issued photo ID and are refunded as store credit at the current selling price of the item. Cordwell reserves the right to decline no-receipt returns flagged by the return verification system.

## Refund timing and methods

Refunds to the original payment card post within 5 to 7 business days of the return being accepted. Cash purchases over 250 dollars are refunded by corporate check mailed within 14 business days. Store credit is issued immediately.

## Serialized and restricted items

Generators and power tool combo kits with serial numbers must be returned with matching serial numbers on the product, packaging, and receipt. Gift cards, cut lumber, cut pipe, cut wire, and clearance items marked final sale are not returnable.
