---
doc_id: man-aquamark-am50e
doc_family: aquamark-heater-manual
title: AquaMark 50 Gallon Electric Water Heater AM-50E Owner's Manual
category: manual
effective_date: 2025-01-22
version: "B"
owner: Merchandising Content
---

## Specifications

The AquaMark AM-50E is a 50 gallon tall electric water heater with dual 4500 watt heating elements wired for non-simultaneous operation on a dedicated 240 volt, 30 amp circuit with 10 gauge copper wire. First hour delivery is 62 gallons. The tank is glass-lined with a factory-installed anode rod and includes a temperature and pressure relief valve rated 150 PSI and 210 degrees Fahrenheit. Factory thermostat setting is 120 degrees Fahrenheit.

## Installation requirements

Installation must comply with local codes and may require a permit. The heater must be installed upright on a level surface with a drain pan piped to an approved drain in any location where leakage can cause damage. A new temperature and pressure relief discharge pipe must run downward to within 6 inches of the floor, must not be reduced, threaded at the outlet, or trapped, and must terminate where discharge is visible. Install a shutoff valve on the cold inlet only. In closed plumbing systems with a check valve or pressure reducing valve at the meter, install a thermal expansion tank sized to the heater on the cold line; expansion tank failure is a leading cause of relief valve dripping.

## Startup

Fill the tank completely before energizing the circuit. Open the cold supply, open a nearby hot faucet, and wait for a full steady stream with no air before switching on the breaker. Energizing the elements in an air pocket destroys the upper element in seconds, a failure called dry firing that is not covered by warranty. Allow approximately 90 minutes for a full cold tank to reach the set temperature.

## Temperature setting

Both thermostats sit behind the two access panels and insulation. Switch off the breaker before removing panels. The recommended setting is 120 degrees Fahrenheit, which balances scald risk, energy use, and bacterial growth control. Settings above 120 increase scald risk sharply; where higher storage temperatures are required, install mixing valves at fixtures.

## Maintenance

Drain sediment through the drain valve every 6 months in hard water areas and yearly otherwise: switch off the breaker, close the cold inlet, attach a hose, open the drain valve and a hot faucet, and flush until the water runs clear. Test the relief valve yearly by lifting the lever briefly; if it fails to snap closed or drips continuously afterward, replace it. Inspect the anode rod every 2 years and replace it when more than 6 inches of core wire is exposed; a consumed anode rod ends the tank's corrosion protection.

## Troubleshooting

No hot water usually means a tripped breaker or a tripped high-limit reset; press the red reset button above the upper thermostat once, and if it trips again call for service because repeat trips indicate a failing thermostat or element. Not enough hot water with normal recovery time suggests a failed lower element. Rumbling or popping indicates sediment buildup; flush the tank. Moisture at the relief valve discharge pipe indicates thermal expansion or excess pressure rather than a bad tank in most cases.

## Warranty

The AM-50E carries a 12 year limited tank warranty and a 6 year limited parts warranty with proof of purchase. Labor, dry firing, sediment damage where maintenance was neglected, and installations that violate this manual are excluded.
