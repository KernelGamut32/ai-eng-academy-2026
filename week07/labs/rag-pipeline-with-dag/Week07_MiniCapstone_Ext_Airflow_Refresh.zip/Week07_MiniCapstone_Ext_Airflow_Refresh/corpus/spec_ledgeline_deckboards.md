---
doc_id: spec-ledgeline-decking
doc_family: ledgeline-decking-spec
title: LedgeLine Composite Decking Product Specification and Installation Guide
category: manual
effective_date: 2025-04-05
version: "A"
owner: Merchandising Content
---

## Product description

LedgeLine composite deck boards are capped wood-plastic composite boards with a protective polymer shell on three sides. Boards are available in 12, 16, and 20 foot lengths in a standard 5.5 inch width and 0.94 inch thickness, in grooved-edge profiles for hidden fasteners and square-edge profiles for face screwing at stair treads and picture-frame borders. Colors are Driftgray, Saddle, and Slate, produced with variegated streaking so adjacent boards differ naturally.

## Span and framing requirements

LedgeLine boards require joist spacing of 16 inches on center or less for residential decks when boards run perpendicular to joists, and 12 inches on center for boards installed at a 45 degree angle. Stair treads require stringers at 9 inches on center. The substructure must be code-compliant pressure-treated lumber or steel framing with positive drainage; LedgeLine boards are decking, not structural members, and must never be used as joists, beams, or posts.

## Gapping and fastening

Side gaps of 1/4 inch are created automatically by LedgeLine hidden fastener clips in grooved boards. End-to-end gaps must be 3/16 inch when installed at 40 degrees Fahrenheit or higher and 5/16 inch below 40 degrees, because composite boards move primarily along their length with temperature. Leave 1/2 inch between board ends and any wall or post. Hidden fastener clips, sold in 90 and 450 count buckets with color-matched screws, install with a standard drill and T20 bit at each joist. Face screws in square-edge boards must be composite deck screws with reverse-thread heads; standard wood screws cause mushrooming around the head.

## Heat and clearance considerations

Like all composite decking, LedgeLine boards become hotter than wood in direct summer sun, and darker colors run hotter than lighter colors. Do not install boards over enclosed cavities without ventilation; a minimum 1.5 inch clearance beneath boards with open airflow on at least two sides is required for warranty coverage. Reflected light from energy-efficient window coatings can concentrate heat and damage any composite decking; where such reflections strike the deck, install screening or films on the window per the window manufacturer.

## Care and cleaning

Wash twice yearly with soap, water, and a soft bristle brush. Remove snow with a plastic shovel run parallel to the boards. Do not use rubber-backed mats, which can discolor the cap, and do not sand, paint, or stain LedgeLine boards; the cap is the finish.

## Warranty

LedgeLine boards carry a 25 year limited residential warranty against material defects and a 25 year fade and stain warranty limited to color change beyond 5 Delta E units and stains from food and beverage not cleaned within one week. The warranty requires compliant framing, gapping, and ventilation as described in this guide.
