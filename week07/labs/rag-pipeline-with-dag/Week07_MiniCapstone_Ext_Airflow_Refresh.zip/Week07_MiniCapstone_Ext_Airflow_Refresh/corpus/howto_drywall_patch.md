---
doc_id: how-drywall-patch
doc_family: howto-drywall-patch
title: How to Patch Drywall Holes of Any Size
category: howto
effective_date: 2025-02-27
version: "1.1"
owner: Project Content Team
---

## Small holes and dents

Nail pops and holes under 1/2 inch need only lightweight spackling. Press the spackle in with a putty knife, strike it flush, let it dry per the label, and sand lightly with a fine sanding sponge. Prime the repair before painting; unprimed spackle flashes dull through paint.

## Medium holes with the California patch

Holes from 1/2 inch to about 6 inches suit a California patch, which needs no backing framing. Cut a square of drywall 2 inches larger in both directions than the hole. On the back of that square, score a line 1 inch in from each edge, snap and peel away the gypsum border while leaving the face paper attached, producing a plug with a 1 inch paper flange all around. Trace the plug's gypsum core over the hole, cut the traced outline with a drywall saw, dry-fit the plug, then butter the hole edges and flange area with all-purpose joint compound, press the plug in, and squeegee the flange flat. Two additional thin coats, each wider, complete the patch.

## Large holes need backing

Holes over 6 inches get a drywall patch of matching thickness screwed to backing. Square up the hole, insert two furring strips or plywood strips behind the opening extending past the edges, and drive drywall screws through the surrounding wall into the strips. Screw the patch to the strips, tape all four seams with paper or mesh tape, and coat as below. Damage that crosses a stud can screw directly to the stud on that side.

## Compound choice and coats

Setting-type compound sold as powder in 20, 45, and 90 minute grades hardens chemically and resists shrinking, which makes 20 minute compound the right first coat for deep fills, even for beginners, because a second coat can follow within the hour. Premixed all-purpose compound is easiest for the final two coats and sands more easily than setting compound. Apply each coat wider than the last, aiming for feathered edges rather than thickness, and sand only after the final coat with 220 grit.

## Matching texture and paint

Match orange peel and knockdown textures with aerosol texture cans, practicing on cardboard first, and knock down with a wide knife at the labeled time. Prime every repair with drywall primer, then paint to the nearest natural break such as a corner, since even the original paint color rarely touches up invisibly mid-wall after years on the wall.
