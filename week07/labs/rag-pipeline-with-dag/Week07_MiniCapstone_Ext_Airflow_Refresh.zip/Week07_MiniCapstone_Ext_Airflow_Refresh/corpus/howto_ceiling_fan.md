---
doc_id: how-ceiling-fan
doc_family: howto-ceiling-fan
title: How to Install a Ceiling Fan
category: howto
effective_date: 2025-06-18
version: "1.2"
owner: Project Content Team
---

## Before you start

A ceiling fan cannot hang from a standard plastic light fixture box. The electrical box must be metal and listed for ceiling fan support, marked "Acceptable for Fan Support" and rated for the fan weight, up to 70 pounds for common listed boxes. If the existing box is not fan-rated, replace it with a fan-rated retrofit brace box that expands between joists through the existing ceiling hole. Confirm the switch controls the fixture, then switch off the circuit at the breaker panel and verify power is off at the fixture wires with a non-contact voltage tester before touching any conductor.

## Tools and materials

You will need a fan-rated box or brace kit if the existing box is not rated, a voltage tester, a screwdriver set, wire strippers, a ladder tall enough to work without standing on the top two rungs, and the fan's included hardware. For sloped ceilings over 34 degrees or downrods over 12 inches, check the fan's maximum slope rating and order the matching angle mount kit before starting.

## Mounting the fan

Assemble per the fan manual: most fans hang the motor assembly on the mounting bracket's hook so both hands stay free for wiring. Connect ground to ground, white fixture neutral to white supply neutral, and the fan's black motor wire to the supply hot. If the fan has a separate blue light-kit wire and the room has a single switch, join blue with black to the switched hot; with two switches and a three-conductor cable, connect blue to the red conductor so the light switches separately. Fold conductors into the box, seat the canopy, then attach blades and the light kit.

## Balancing and testing

Restore power and test all speeds and the light kit. A wobble at higher speeds is normal to correct on new installs: confirm all blade screws are tight, measure blade tip heights to find a drooping blade, then use the included balancing kit, moving the clip along one blade at a time to find the offending blade and pressing the stick-on weight at the clip position that minimizes wobble. Seasonal direction matters: counterclockwise in summer pushes air down for cooling, clockwise on low in winter pulls air up to circulate warm air without a draft.

## When to call a pro

Call a licensed electrician for aluminum branch wiring, boxes with no ground, ceilings over 12 feet, or any panel work. Cordwell Installation Services offers licensed ceiling fan installation including fan-rated box replacement; see the ops guide for scope.
