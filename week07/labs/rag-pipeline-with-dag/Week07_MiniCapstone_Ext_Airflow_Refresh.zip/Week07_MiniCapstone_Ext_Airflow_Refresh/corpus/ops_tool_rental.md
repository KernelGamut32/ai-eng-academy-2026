---
doc_id: ops-tool-rental
doc_family: ops-tool-rental
title: Cordwell Tool and Equipment Rental Program Guide
category: ops
effective_date: 2025-07-01
version: "1.9"
owner: Store Operations
---

## Rental periods and rates

The rental counter offers 4 hour, 24 hour, weekly, and 4 week rates on categories including floor care, concrete and masonry, plumbing augers, pressure washers, lawn and garden equipment, ladders and scaffolding, and trailers at select stores. The 4 hour rate covers a same-day round trip; equipment returned after the 4 hour window but within 24 hours converts automatically to the 24 hour rate rather than accruing hourly overage. Weekly rates equal 4 times the daily rate and 4 week rates equal 12 times the daily rate.

## Requirements at the counter

Renters must be 18 or older with a valid government-issued photo ID and a major credit or debit card in the renter's name. The counter places a refundable deposit hold sized to the equipment category on the card; cash and gift cards cannot carry the deposit. Trailer rentals additionally require proof of insurance and a vehicle with a rated hitch, inspected at pickup.

## Fuel, cleaning, and damage

Gas equipment leaves with a full tank and returns full, with a refueling charge otherwise. Equipment returning excessively dirty, concrete tools returning with hardened material, or paint sprayers returning with coating dried in the pump incur a cleaning charge from the posted schedule. The optional damage waiver, 12 percent of the rental charge, covers accidental damage during normal use but not loss, theft, abuse, or running fluids incorrectly, such as operating a mixer without oil.

## Late and lost equipment

A rental becomes late 30 minutes after its due-back time and bills the next rate tier automatically. Equipment 7 days overdue with no contact is treated as unreturned and the replacement value is charged to the card on file after two documented contact attempts. Extensions requested before the due-back time by phone avoid all of this and simply re-rate the contract.

## Popular use notes

Aerators and dethatchers book out fully on spring and fall weekends; reservations are held with a card and released 30 minutes after the pickup time. Pressure washers rent with the nozzle set installed and a quart of pump-safe detergent available for purchase. Floor sanders include an edger bundle option and sandpaper is sold, not rented, with unopened sleeves returnable under the standard policy.
