---
doc_id: rec-frostbreaker-2026-01
doc_family: frostbreaker-recall
title: Safety Recall Notice FB-24 Snow Blower Auger Shear Bolt Kits, Lots 24C through 24F
category: recall
effective_date: 2026-01-19
version: "1.0"
owner: Product Safety Office
---

## Summary of the recall

FrostBreaker, in cooperation with Cordwell Home & Hardware, is recalling replacement auger shear bolt kits, part number FB-SB25, from manufacturing lots 24C, 24D, 24E, and 24F. Bolts in the affected lots were hardened out of specification and can fail to shear when the auger strikes a solid object, transferring impact loads into the auger gearbox. A gearbox that fails under load can seize the auger abruptly. No injuries have been reported. Snow blowers themselves are not being recalled; only the replacement shear bolt kits from the four affected lots are involved. Kits packed with new FB-24 units at the factory are not affected.

## How to identify affected kits

The lot code is printed on the back of the blister card above the barcode, in the format 24 followed by a letter. Kits with lot codes 24C, 24D, 24E, or 24F are affected. Loose bolts already installed can be identified by the head stamp: affected bolts carry the stamp FS7, while correct bolts carry FS5. If the head stamp cannot be read, treat the bolt as affected.

## What customers should do

Stop using shear bolts from affected kits. Bring affected kits, or the machine if affected bolts are installed, to any Cordwell service desk for a free replacement kit and, where bolts are installed, free replacement of the installed bolts while you wait. Customers may also request a prepaid mailer and replacement kit through the FrostBreaker recall portal. Refunds are available for customers who prefer them, with or without a receipt, as required for recalled merchandise.

## Store handling instructions

Pull all FB-SB25 kits from the shelf and returns cart, scan each against the recall lot list at the service desk terminal, quarantine affected lots in the recall tote, and restock only cleared lots. The seasonal program's assembly torque-check step now includes a head stamp check; any FB-24 on the pad assembled with FS7-stamped bolts is pulled and re-bolted before sale. Process recall refunds under the recall tender path, which bypasses the standard return window and receipt requirements.
