# Cordwell Knowledge Base Corpus Manifest

Synthetic corpus for the Week 7 mini-capstone. All companies, brands, products, part numbers, and policies are fictional and exist only for this exercise. Every document carries YAML front matter with doc_id, doc_family, title, category, effective_date, version, and owner.

| File | doc_id | Category |
|---|---|---|
| policy_returns_2026.md | pol-returns-2026 | policy |
| policy_returns_2024.md | pol-returns-2024 | policy |
| policy_price_match.md | pol-price-match | policy |
| policy_delivery_assembly.md | pol-delivery | policy |
| policy_shieldcare.md | pol-shieldcare | policy |
| policy_hazmat.md | pol-hazmat | policy |
| policy_giftcards_cordperks.md | pol-giftcards-cordperks | policy |
| manual_vexline_drill.md | man-vexline-vx20dd1 | manual |
| archive_vexline_drill_manual.md | man-vexline-vx20dd1-archive | manual |
| manual_torqline_vac.md | man-torqline-tv12 | manual |
| manual_hearthsense_thermostat.md | man-hearthsense-hst200 | manual |
| manual_aquamark_heater.md | man-aquamark-am50e | manual |
| manual_gatecrest_opener.md | man-gatecrest-gc1200 | manual |
| manual_sprayline_sprayer.md | man-sprayline-sl3000 | manual |
| manual_frostbreaker_snowblower.md | man-frostbreaker-fb24 | manual |
| spec_ledgeline_deckboards.md | spec-ledgeline-decking | manual |
| howto_ceiling_fan.md | how-ceiling-fan | howto |
| howto_drywall_patch.md | how-drywall-patch | howto |
| howto_winterize_irrigation.md | how-winterize-irrigation | howto |
| howto_tile_backsplash.md | how-tile-backsplash | howto |
| howto_stain_deck.md | how-stain-deck | howto |
| howto_install_smart_thermostat.md | how-smart-thermostat | howto |
| howto_replace_toilet.md | how-replace-toilet | howto |
| ops_associate_faq_returns.md | ops-returns-desk-faq | ops |
| ops_installation_services.md | ops-install-services | ops |
| ops_tool_rental.md | ops-tool-rental | ops |
| ops_seasonal_program.md | ops-seasonal-storage | ops |
| recall_frostbreaker_auger.md | rec-frostbreaker-2026-01 | recall |
| sds_proseal_sealer.md | sds-proseal-cs40 | sds |
| guide_cordless_platforms.md | guide-cordless-platforms | guide |
| transcript_hotline_digest_0417.md | ops-hotline-digest-0417 | transcript |

This manifest is inventory only and is skipped by the ingest pipeline.
