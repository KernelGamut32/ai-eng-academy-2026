---
doc_id: man-torqline-tv12
doc_family: torqline-vac-manual
title: TorqLine 12 Gallon Wet/Dry Vacuum TV-12P Owner's Manual
category: manual
effective_date: 2025-03-18
version: "A"
owner: Merchandising Content
---

## Specifications

The TorqLine TV-12P is a 12 gallon wet/dry vacuum with a 5.5 peak horsepower motor, a 2-1/2 inch by 7 foot hose, and a rear blower port. The drum is molded polypropylene with a bottom drain for liquids. The kit includes a utility nozzle, wet nozzle, crevice tool, two extension wands, a standard cartridge filter for dry pickup, and a foam sleeve for wet pickup. The power cord is 10 feet; the unit draws 11 amps on a standard 120 volt circuit.

## Filter selection

Filter choice depends on what you are picking up. Use the pleated cartridge filter for everyday dry debris. For fine dust such as drywall sanding dust, concrete dust, or cold ash, install the optional fine dust cartridge filter, model TF-2F, and empty the drum frequently; running fine dust through a standard cartridge clogs it quickly and sharply reduces suction. For wet pickup, remove any cartridge filter completely and install the foam sleeve over the cage. Running wet pickup with a paper cartridge installed destroys the cartridge.

## Wet pickup operation

Before wet pickup, remove the cartridge filter, install the foam sleeve, and attach the wet nozzle. The float ball inside the cage rises as the drum fills and shuts off airflow when full; when the motor tone rises and suction stops, the drum is full. Switch off, unplug, and empty using the bottom drain or by tipping the drum. Never pick up flammable liquids, hot ash, or smoldering material. After wet use, run the vacuum with clean airflow for one minute and leave the lid off the drum to dry.

## Blower use

Insert the hose into the rear blower port to convert the vacuum to a blower for clearing grass clippings from walkways or drying wet floors. Wear eye protection during blower use and never point the blower stream at people or pets.

## Maintenance and troubleshooting

Clean the cartridge filter after each heavy use by tapping it against the inside of a trash can; replace it when tapping no longer restores suction or the pleats are torn. If suction is weak, check in order: a full drum, a clogged filter, a blockage in the hose, and an air leak at the lid latches. A high-pitched motor tone with no pickup almost always means the float has sealed because the drum is full or the unit was tipped. If the motor does not start, verify the outlet with another device and check for a tripped breaker; the TV-12P has no serviceable parts inside the motor housing.

## Warranty

The TV-12P carries a 4 year limited warranty through Cordwell service desks with proof of purchase. Filters, hoses, and accessories are wear items covered for 90 days.
