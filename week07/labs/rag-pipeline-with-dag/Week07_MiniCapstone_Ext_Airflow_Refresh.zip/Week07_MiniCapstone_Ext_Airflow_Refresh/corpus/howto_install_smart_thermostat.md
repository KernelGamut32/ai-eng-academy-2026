---
doc_id: how-smart-thermostat
doc_family: howto-smart-thermostat
title: How to Replace a Thermostat with a Smart Thermostat
category: howto
effective_date: 2025-10-20
version: "1.2"
owner: Project Content Team
---

## Check compatibility before buying

Remove the old thermostat's faceplate and photograph the wiring. Count the wires and note the terminal letters they land on. Most smart thermostats, including the HearthSense HS-T200 sold at Cordwell, need a C wire for continuous power; a bundle of unused wire stuffed in the wall behind the plate can sometimes serve as the C conductor if it is connected at the furnace end. Line-voltage systems, identifiable by thick wires under wire nuts and 120 or 240 volt markings, are not compatible with low-voltage smart thermostats regardless of adapters.

## Kill power and label

Switch off the furnace or air handler at its breaker or service switch, then confirm the old thermostat display is dark. Label each wire with the terminal letter it leaves before disconnecting, using the sticker set included with most smart thermostats, and clip a clothespin or tape the bundle to keep wires from sliding back into the wall.

## Handling a missing C wire

Options, in order of preference: use an unused conductor already in the cable and land it on C at both the thermostat and the furnace control board; install the power adapter module included with many smart thermostats, such as the HearthSense Power Bridge, at the furnace board following its diagram; or have new 18/5 thermostat cable pulled. Battery-only operation and so-called power stealing without a C wire cause the exact symptoms people later report as defects: Wi-Fi dropouts, clicking relays at the furnace, and dead displays on cold mornings.

## Mount and connect

Mount the new base plate level over the old footprint, using the trim plate from the box where the old thermostat was larger. Seat each labeled wire in its matching terminal until the terminal clamps, gently tugging each to confirm. Attach the display, restore power, and follow the guided setup, confirming system type and, for heat pumps, the O/B reversing valve orientation.

## Verify operation

Run a full test: call for heat and confirm warm supply air within a few minutes, call for cooling and confirm the outdoor unit starts, and for heat pumps confirm the reversing valve setting by checking that cooling blows cold, not warm. Join Wi-Fi on a 2.4 GHz network, apply firmware updates, and set the schedule. Keep the wiring photo with the manual; the next replacement starts with that photo.
