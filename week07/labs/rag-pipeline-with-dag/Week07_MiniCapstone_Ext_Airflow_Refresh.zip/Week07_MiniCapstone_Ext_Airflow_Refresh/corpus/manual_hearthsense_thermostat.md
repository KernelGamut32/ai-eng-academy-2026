---
doc_id: man-hearthsense-hst200
doc_family: hearthsense-thermostat-manual
title: HearthSense Smart Thermostat HS-T200 Installation and User Manual
category: manual
effective_date: 2025-10-02
version: "C"
owner: Merchandising Content
---

## Compatibility

The HearthSense HS-T200 works with most 24 volt AC heating and cooling systems, including gas and oil furnaces, heat pumps with O/B changeover wiring, and two-stage conventional systems up to 2 heat / 2 cool. It requires a C wire (common wire) for continuous power. If no C wire is present at the wall plate, install the included HearthSense Power Bridge at the furnace control board, which frees the existing wires to deliver common power without pulling new cable. The HS-T200 does not support 120/240 volt line-voltage baseboard heat, millivolt fireplace systems, or proprietary communicating systems.

## Wi-Fi requirements

The HS-T200 connects to 2.4 GHz Wi-Fi networks only and does not join 5 GHz networks. During setup, phones that automatically prefer 5 GHz may fail to find the thermostat; temporarily disabling 5 GHz on the phone or standing farther from the router usually resolves discovery problems. The thermostat operates all schedules locally, so heating and cooling continue normally during internet outages; only remote control and energy reports pause.

## Installation summary

Switch off power to the HVAC system at the breaker before removing the old thermostat. Photograph the existing wiring before disconnecting anything, then label each wire with the included stickers as it is removed. Mount the HS-T200 base plate level, seat each labeled wire in its matching terminal until the terminal button clicks, and attach the display. Restore power and follow the on-screen setup, which detects connected wires and flags a missing C wire. For heat pumps, the setup asks whether the reversing valve energizes in cooling (O) or heating (B); most brands energize in cooling.

## Daily use and scheduling

The HS-T200 supports 7 day scheduling with up to 8 setpoints per day, a hold mode that pins the current temperature until cancelled, and adaptive recovery that starts equipment early so the home reaches the scheduled temperature at the scheduled time. Filter reminders count actual system runtime rather than calendar days.

## Troubleshooting

A blank display usually means no power at the C terminal or a tripped float switch on the condensate line cutting the R circuit. If the display shows "No C wire detected," recheck the Power Bridge connections at the furnace board. Short cycling on heat pumps most often traces to an incorrect O/B setting. If Wi-Fi setup fails repeatedly, confirm the network is 2.4 GHz, the password has no unsupported characters, and the router is not isolating new devices.

## Warranty

The HS-T200 carries a 5 year limited warranty when registered within 60 days of purchase, and 2 years otherwise. Professional installation through Cordwell Installation Services extends the labor warranty on the installation itself to 1 year.
