---
doc_id: how-winterize-irrigation
doc_family: howto-winterize-irrigation
title: How to Winterize a Sprinkler and Irrigation System
category: howto
effective_date: 2025-10-12
version: "1.3"
owner: Project Content Team
---

## Why blowouts matter

Water left in irrigation lines expands when it freezes and splits pipe, cracks manifolds, and destroys backflow preventers. In climates with sustained freezes, draining alone rarely empties every low spot, so the reliable method is a compressed air blowout performed before the first hard freeze.

## Shut down the water and controller

Close the irrigation shutoff valve, usually in a basement, crawl space, or valve box between the meter and the backflow preventer. Set the controller to off or rain mode; do not unplug controllers that hold schedules in volatile memory. Open the drain or test cocks on the backflow preventer and any low-point drains to relieve pressure.

## Air pressure limits

Air pressure limits protect the pipe: do not exceed 50 PSI when blowing out polyethylene pipe systems and do not exceed 80 PSI for rigid PVC systems, and always regulate the compressor rather than trusting its tank gauge. Air volume matters more than pressure; a small pancake compressor can winterize a small residential system one zone at a time with patience, while large systems clear faster with higher volume compressors. Never blow air through the backflow preventer itself; connect downstream of it at the blowout fitting.

## Blow out each zone

Connect the compressor to the blowout port with a quick-connect fitting. Activate one zone from the controller before introducing air so pressurized air always has an open path, then bring air up gradually until heads on that zone rise and spray water, then mist, then mostly air. Stop when a zone runs mostly dry rather than chasing perfectly dry heads: running rotors dry on air for long periods melts their internal gears from friction heat. Work through every zone in order, then repeat a short second pass on the first zones you cleared, which often spit water that drained back during later zones.

## Finish and protect above-ground parts

With zones cleared, leave manual drains and test cocks half-open through winter per the backflow manufacturer, wrap above-ground backflow preventers with insulating covers, and disconnect, drain, and store garden hoses. Note the shutoff and blowout locations in your phone for spring startup, when the shutoff valve reopens slowly against a closed system to avoid water hammer.
