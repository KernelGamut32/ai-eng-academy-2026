---
doc_id: pol-price-match
doc_family: price-match-policy
title: Cordwell Price Match Promise
category: policy
effective_date: 2025-09-15
version: "1.4"
owner: Pricing and Promotions
---

## What we match

Cordwell Home & Hardware matches the current advertised price of any identical, in-stock item from a local retail competitor or from an approved list of national online retailers. Identical means the same brand, model number, size, quantity, and color. The competitor item must be in stock and available for immediate purchase or shipment at the advertised price.

## How to request a match

Bring the competitor's current advertisement, product listing, or a photo of the shelf tag to any register or to the ProDesk. For online prices, the listing must be viewable at the time of the request, must be sold and fulfilled by the retailer itself rather than a third-party marketplace seller, and must include any shipping charges in the comparison price.

## Post-purchase price adjustments

If Cordwell lowers its own price on an item you purchased within the previous 14 days, bring your receipt and we will refund the difference to your original form of payment. Competitor price matches are honored at the time of sale only and are not applied retroactively.

## Exclusions

The Price Match Promise does not apply to clearance, closeout, open-box, refurbished, or damaged items, volume and contractor bid pricing, bundle offers, financing or gift card promotions, labor and installation services, marketplace listings, auction sites, or pricing errors. Cordwell limits price matches to one identical item per customer per day for quantities consistent with normal household use.

## Verification

Associates verify competitor prices by viewing the listing directly or by calling the competitor location. If a price cannot be verified at the time of the request, the match cannot be completed that day.
