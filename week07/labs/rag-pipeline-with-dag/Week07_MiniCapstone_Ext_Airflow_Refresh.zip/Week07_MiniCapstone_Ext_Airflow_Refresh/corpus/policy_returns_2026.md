---
doc_id: pol-returns-2026
doc_family: returns-policy
title: Cordwell Home & Hardware Return and Refund Policy
category: policy
effective_date: 2026-02-01
version: "3.2"
owner: Customer Operations
---

## Standard return window

Most new, unopened merchandise sold by Cordwell Home & Hardware may be returned within 30 days of purchase for a full refund to the original form of payment. A valid receipt, digital receipt, or order confirmation is required. Items returned in opened but resalable condition within the same 30 day window are eligible for refund at the discretion of the store manager on duty.

CordPerks Platinum members receive an extended return window of 90 days on most merchandise. The extended window applies automatically when the purchase is attached to an active Platinum membership at checkout.

## Category exceptions

The following categories carry shorter or modified windows regardless of membership tier.

Major appliances, including refrigerators, ranges, dishwashers, washers, and dryers, must be inspected at delivery. Damage or defects must be reported within 48 hours of delivery to qualify for return, exchange, or repair under this policy. After 48 hours, appliance concerns are handled through the manufacturer warranty and, where purchased, the Cordwell ShieldCare protection plan.

Gas-powered outdoor equipment, including mowers, snow blowers, chainsaws, and pressure washers, may be returned within 30 days only if unused and containing no fuel or oil. Once fuel or oil has been added, the item may not be returned to a store shelf and is instead serviced under the manufacturer warranty through an authorized service center.

Custom and special-order products, including cut-to-length blinds, mixed paint, custom doors, and special-order cabinetry, are not returnable except where defective.

Holiday and seasonal merchandise may be returned through the applicable holiday date, after which all sales of that seasonal category are final.

## Live goods guarantee

Perennials, trees, and shrubs are covered by the Cordwell one year live goods guarantee. Bring the plant, or the plant tag, together with the receipt within 365 days of purchase for a one-time replacement or refund. Annuals and holiday plants are excluded and follow the standard 30 day window.

## Returns without a receipt

Returns without proof of purchase require a valid government-issued photo ID and are refunded as store credit at the lowest advertised selling price of the item during the previous 90 days. Cordwell reserves the right to decline no-receipt returns flagged by the return verification system.

## Refund timing and methods

Refunds to the original payment card post within 3 to 5 business days of the return being accepted. Cash purchases over 500 dollars are refunded by corporate check mailed within 10 business days. Store credit is issued immediately and never expires.

## Serialized and restricted items

Generators, gas-powered equipment, and power tool combo kits with serial numbers must be returned with matching serial numbers on the product, packaging, and receipt. Gift cards, cut lumber, cut pipe, cut wire, and clearance items marked final sale are not returnable.
