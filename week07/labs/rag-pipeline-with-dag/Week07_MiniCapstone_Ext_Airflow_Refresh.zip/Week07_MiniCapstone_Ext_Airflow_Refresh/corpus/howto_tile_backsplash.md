---
doc_id: how-tile-backsplash
doc_family: howto-tile-backsplash
title: How to Tile a Kitchen Backsplash
category: howto
effective_date: 2025-05-25
version: "1.0"
owner: Project Content Team
---

## Planning and layout

Measure the square footage of the backsplash area and buy 10 percent extra tile for cuts and breakage. Find the most visible wall section and plan the layout from its center so cut tiles land in corners and under cabinets rather than at eye level. Mark a level line at the layout's base; countertops are rarely perfectly level, and following the counter instead of a level line telegraphs its error up the whole wall. Remove switch and outlet cover plates and shut off those circuits at the breaker before tiling around them.

## Setting materials for kitchens

Walls behind a range or sink see heat and moisture, so use a polymer-modified thin-set mortar or a premixed adhesive rated for the tile size and location. For standard 3 x 6 subway tile, spread mortar with a 3/16 inch V-notch trowel; larger format tile needs a 1/4 inch square notch and back-buttering. Mesh-mounted mosaic sheets use the same 3/16 V-notch but need a flat-side skim first so mortar does not squeeze through the joints.

## Setting tile

Spread only as much mortar as you can tile in about 15 minutes, combing all ridges in one direction. Press tiles with a slight slide perpendicular to the ridges to collapse them, using spacers sized to your grout joint; subway tile commonly uses 1/16 or 1/8 inch joints. Check the field with a straightedge every few rows. Cut tiles at outlets so the ears of the receptacle can seat on tile with box extenders installed as required by code for boxes now recessed more than 1/4 inch. Let the field cure 24 hours before grouting.

## Grouting

Joints 1/8 inch and narrower take unsanded grout; wider joints take sanded grout, and glass mosaics take unsanded regardless to avoid scratching. Work grout diagonally across joints with a rubber float, then clean with a barely damp sponge in light diagonal passes, rinsing constantly. The haze that forms as grout cures wipes off with a microfiber cloth once the surface dulls; stubborn haze the next day removes with a haze remover compatible with your grout. Caulk, rather than grout, every change of plane: the counter-to-tile joint and inside corners get color-matched siliconized caulk so seasonal movement does not crack the joint.

## Sealing and cleanup

Cementitious grout benefits from a penetrating sealer after curing 48 to 72 hours; premixed urethane and epoxy grouts need no sealer. Restore power, reinstall cover plates on extended boxes, and keep leftover tiles labeled in the garage for future repairs.
