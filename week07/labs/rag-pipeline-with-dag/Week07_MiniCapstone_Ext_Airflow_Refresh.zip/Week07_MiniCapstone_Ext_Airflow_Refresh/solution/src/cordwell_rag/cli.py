"""Command line entry points.

Usage (from starter/ or solution/ with src on PYTHONPATH, or via the
run.sh helper at the project root):

  python -m cordwell_rag.cli check-services
  python -m cordwell_rag.cli ingest
  python -m cordwell_rag.cli serve
  python -m cordwell_rag.cli experiment
  python -m cordwell_rag.cli select-champion
"""

from __future__ import annotations

import argparse
import sys

from . import config


def cmd_check_services(_args) -> int:
    """Ping every service the capstone can use and report plainly. This is
    the first thing to run on day one and the first thing to run when
    anything misbehaves."""
    import httpx

    checks = [
        ("Pinecone Local (control plane)", config.PINECONE_HOST, True),
        ("MLflow", config.MLFLOW_TRACKING_URI, True),
        ("LM Studio", config.LMSTUDIO_BASE_URL.rsplit("/v1", 1)[0] + "/v1/models", False),
        ("Ollama", config.OLLAMA_BASE_URL.rsplit("/v1", 1)[0] + "/v1/models", False),
    ]
    print(f"Backend mode : {config.BACKEND_MODE}")
    print(f"Model        : {config.LOCAL_MODEL}")
    print(f"Embeddings   : {config.EMBEDDING_BACKEND}")
    print()
    failures = 0
    for name, url, required in checks:
        try:
            response = httpx.get(url, timeout=3.0)
            status = f"UP ({response.status_code})"
        except Exception as exc:
            status = f"DOWN ({type(exc).__name__})"
            if required:
                failures += 1
        tag = "required" if required else "optional"
        print(f"  {name:35s} {url:45s} {status:12s} [{tag}]")
    if failures:
        print("\nRequired services are down. Run: docker compose up -d")
    else:
        print("\nAll required services are reachable.")
    return 1 if failures else 0


def cmd_ingest(_args) -> int:
    """Full population path: load, filter versions, chunk, dedupe, embed,
    create a fresh index, upsert. Prints the counts at every stage so the
    curveballs are visible when they bite."""
    from .chunking import chunk_corpus
    from .corpus_loader import load_corpus, select_active_documents
    from .embeddings import get_embedder
    from .vector_store import PineconeLocalStore

    docs = load_corpus()
    print(f"Loaded documents          : {len(docs)}")
    active = select_active_documents(docs)
    dropped_docs = len(docs) - len(active)
    print(f"Active after versioning   : {len(active)} ({dropped_docs} superseded dropped)")

    chunks, dup_dropped = chunk_corpus(active)
    print(f"Chunks after dedupe       : {len(chunks)} ({dup_dropped} duplicates dropped)")
    oversized = [c for c in chunks if len(c.text) > config.CHUNK_MAX_CHARS]
    if oversized:
        print(f"WARNING: {len(oversized)} chunks exceed CHUNK_MAX_CHARS; upsert will refuse them.")

    embedder = get_embedder()
    print(f"Embedding backend         : {embedder.name} (dim {embedder.dim})")
    vectors = embedder.embed([c.text for c in chunks])

    store = PineconeLocalStore()
    store.ensure_fresh_index()
    written = store.upsert_chunks(chunks, vectors)
    print(f"Vectors upserted          : {written} into index {config.INDEX_NAME!r}")
    print("Ingest complete.")
    return 0


def cmd_serve(args) -> int:
    import uvicorn

    uvicorn.run(
        "cordwell_rag.api:app",
        host=config.API_HOST,
        port=args.port or config.API_PORT,
        reload=False,
    )
    return 0


def cmd_experiment(_args) -> int:
    """Run the full sweep. Requires an already-populated index."""
    from trulens.core import TruSession

    from .embeddings import get_embedder
    from .evaluation import load_eval_set
    from .experiments import run_sweep
    from .vector_store import PineconeLocalStore

    config.ensure_dirs()
    embedder = get_embedder()
    store = PineconeLocalStore()
    store.connect_existing_index()
    eval_items = load_eval_set()
    session = TruSession(database_url=config.TRULENS_DB_URL)
    session.reset_database()  # one sweep, one clean TruLens ledger

    run_ids = run_sweep(embedder, store, eval_items, session)
    print(f"\nLogged {len(run_ids)} runs to MLflow experiment "
          f"{config.MLFLOW_EXPERIMENT_NAME!r} at {config.MLFLOW_TRACKING_URI}")
    print("Open the MLflow UI and compare, then run select-champion.")
    return 0


def cmd_select_champion(_args) -> int:
    from .experiments import select_champion

    verdict = select_champion()
    return 0 if verdict.get("status") == "champion_selected" else 1


def cmd_dashboard(_args) -> int:
    """Launch the TruLens dashboard on a fixed port. force=True makes
    re-runs safe when a previous dashboard process is still around."""
    from trulens.core import TruSession
    from trulens.dashboard import run_dashboard

    session = TruSession(database_url=config.TRULENS_DB_URL)
    run_dashboard(session, port=config.TRULENS_DASHBOARD_PORT, force=True)
    input("Dashboard running. Press Enter to stop.")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="cordwell_rag", description="Cordwell RAG mini-capstone")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("check-services", help="Ping Pinecone, MLflow, LM Studio, Ollama")
    sub.add_parser("ingest", help="Populate the Pinecone Local index from the corpus")
    serve = sub.add_parser("serve", help="Run the FastAPI service")
    serve.add_argument("--port", type=int, default=None)
    sub.add_parser("experiment", help="Run the MLflow evaluation sweep")
    sub.add_parser("select-champion", help="Pick and tag the champion run in MLflow")
    sub.add_parser("dashboard", help="Launch the TruLens dashboard")

    args = parser.parse_args(argv)
    handlers = {
        "check-services": cmd_check_services,
        "ingest": cmd_ingest,
        "serve": cmd_serve,
        "experiment": cmd_experiment,
        "select-champion": cmd_select_champion,
        "dashboard": cmd_dashboard,
    }
    return handlers[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
