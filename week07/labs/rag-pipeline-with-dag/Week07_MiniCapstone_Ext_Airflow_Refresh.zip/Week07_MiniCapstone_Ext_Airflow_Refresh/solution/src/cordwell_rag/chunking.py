"""Turn documents into index-ready chunks.

Design goals:
  * Respect document structure first: split on '## ' section headings so a
    chunk is usually one coherent topic.
  * Enforce a hard size ceiling second: any section longer than
    CHUNK_MAX_CHARS is packed by paragraphs, and any single paragraph
    longer than the ceiling is sliced by characters with overlap. Real
    corpora always contain at least one wall-of-text document with no
    structure at all, and Pinecone enforces a 40 KB metadata limit per
    vector, so "split on headings" alone is not a chunker.
  * Deduplicate by normalized content hash, because real corpora also
    always contain at least one copy-pasted duplicate.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import List, Tuple

from . import config
from .corpus_loader import Document


@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    doc_family: str
    title: str
    category: str
    effective_date: str
    seq: int
    text: str


def split_into_sections(body: str) -> List[str]:
    """Split a markdown body on level-2 headings, keeping each heading with
    its section text. A document with no '## ' headings comes back as a
    single section."""
    sections: List[str] = []
    current: List[str] = []
    for line in body.splitlines():
        if line.startswith("## ") and current:
            sections.append("\n".join(current).strip())
            current = [line]
        else:
            current.append(line)
    if current:
        sections.append("\n".join(current).strip())
    return [s for s in sections if s]


def _pack_paragraphs(section: str, max_chars: int) -> List[str]:
    """Greedily pack paragraphs into pieces no longer than max_chars.
    Single paragraphs longer than max_chars pass through intact; the
    caller slices them."""
    paragraphs = [p.strip() for p in section.split("\n\n") if p.strip()]
    pieces: List[str] = []
    buffer = ""
    for para in paragraphs:
        candidate = f"{buffer}\n\n{para}" if buffer else para
        if len(candidate) <= max_chars:
            buffer = candidate
        else:
            if buffer:
                pieces.append(buffer)
            buffer = para
    if buffer:
        pieces.append(buffer)
    return pieces


def _slice_with_overlap(text: str, max_chars: int, overlap: int) -> List[str]:
    """Character-slice a paragraph that is too long to keep whole. Each
    slice starts `overlap` characters before the previous slice ended, so
    a fact that straddles a cut point survives in at least one slice."""
    if len(text) <= max_chars:
        return [text]
    step = max_chars - overlap
    if step <= 0:
        raise ValueError("CHUNK_OVERLAP_CHARS must be smaller than CHUNK_MAX_CHARS")
    slices = []
    start = 0
    while start < len(text):
        slices.append(text[start : start + max_chars])
        if start + max_chars >= len(text):
            break
        start += step
    return slices


def chunk_document(
    doc: Document,
    max_chars: int = config.CHUNK_MAX_CHARS,
    overlap: int = config.CHUNK_OVERLAP_CHARS,
) -> List[Chunk]:
    """Chunk one document: heading-aware first, size-enforced always.

    Every returned chunk satisfies len(chunk.text) <= max_chars, no matter
    how unstructured the source document is.
    """
    pieces: List[str] = []
    for section in split_into_sections(doc.body):
        if len(section) <= max_chars:
            pieces.append(section)
            continue
        for packed in _pack_paragraphs(section, max_chars):
            if len(packed) <= max_chars:
                pieces.append(packed)
            else:
                pieces.extend(_slice_with_overlap(packed, max_chars, overlap))

    chunks: List[Chunk] = []
    for seq, text in enumerate(pieces):
        chunks.append(
            Chunk(
                chunk_id=f"{doc.doc_id}::c{seq:03d}",
                doc_id=doc.doc_id,
                doc_family=doc.doc_family,
                title=doc.title,
                category=doc.category,
                effective_date=doc.effective_date,
                seq=seq,
                text=text,
            )
        )
    return chunks


def normalize_for_hash(text: str) -> str:
    """Case-fold and collapse whitespace so cosmetic differences do not
    defeat duplicate detection."""
    return " ".join(text.lower().split())


def content_hash(text: str) -> str:
    return hashlib.blake2b(normalize_for_hash(text).encode("utf-8"), digest_size=16).hexdigest()


def dedupe_chunks(chunks: List[Chunk]) -> Tuple[List[Chunk], int]:
    """Drop chunks whose normalized text already appeared earlier.

    Returns (kept_chunks, dropped_count). First occurrence wins, and input
    order is preserved, so results are deterministic for a sorted corpus.
    """
    seen: set[str] = set()
    kept: List[Chunk] = []
    dropped = 0
    for chunk in chunks:
        digest = content_hash(chunk.text)
        if digest in seen:
            dropped += 1
            continue
        seen.add(digest)
        kept.append(chunk)
    return kept, dropped


def chunk_corpus(docs: List[Document]) -> Tuple[List[Chunk], int]:
    """Chunk every document, then dedupe across the whole corpus."""
    all_chunks: List[Chunk] = []
    for doc in docs:
        all_chunks.extend(chunk_document(doc))
    return dedupe_chunks(all_chunks)
