"""Evaluation: deterministic metrics plus the TruLens RAG triad.

Two complementary lenses on the same runs:

  * Deterministic reference-based metrics, computed inline per question:
    retrieval hit rate and MRR (did the right documents come back, and how
    high), ROUGE-L against the reference answer, and the abstention
    metrics (does the pipeline refuse when it should, and only then).
  * The TruLens triad, computed from recorded spans: context relevance
    (question vs retrieved chunks), groundedness (answer vs retrieved
    chunks), and answer relevance (question vs answer). These are
    reference-free: they judge the run without needing a gold answer,
    which is how you evaluate in production where no gold answers exist.

The triad implementations here are embedding-similarity based, so they are
fast, deterministic, and offline. A production system would typically use
an LLM judge for groundedness; the walkthrough discusses the trade."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

from rouge_score import rouge_scorer
from trulens.core import Metric, Selector, TruSession

from . import config
from .embeddings import Embedder
from .rag import RagPipeline

# ---------------------------------------------------------------------------
# Eval set
# ---------------------------------------------------------------------------


@dataclass
class EvalItem:
    qid: str
    question: str
    reference_answer: str
    expected_doc_ids: List[str]
    answerable: bool


def load_eval_set(path: Path | None = None) -> List[EvalItem]:
    path = path or config.EVAL_SET_PATH
    items: List[EvalItem] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            items.append(
                EvalItem(
                    qid=row["qid"],
                    question=row["question"],
                    reference_answer=row["reference_answer"],
                    expected_doc_ids=list(row["expected_doc_ids"]),
                    answerable=bool(row["answerable"]),
                )
            )
    return items


# ---------------------------------------------------------------------------
# Deterministic metrics
# ---------------------------------------------------------------------------

_ROUGE = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)


def rouge_l_f(reference: str, candidate: str) -> float:
    """ROUGE-L F1. Argument order matters and is the reverse of sacrebleu:
    rouge_scorer takes (reference, candidate)."""
    return float(_ROUGE.score(reference, candidate)["rougeL"].fmeasure)


def is_abstention(answer: str) -> bool:
    """The abstention contract is the exact ABSTAIN_MARKER string, which
    both the offline answerer and the live-backend prompts are required to
    emit verbatim when refusing."""
    return config.ABSTAIN_MARKER in answer.upper()


def retrieval_hit(expected_doc_ids: List[str], retrieved_doc_ids: List[str]) -> bool:
    """A hit means at least one expected source document appears anywhere
    in the retrieved list."""
    expected = set(expected_doc_ids)
    return any(d in expected for d in retrieved_doc_ids)


def reciprocal_rank(expected_doc_ids: List[str], retrieved_doc_ids: List[str]) -> float:
    """1/rank of the first retrieved chunk that comes from an expected
    document; 0.0 if none do. Rank is 1-based, so a perfect retrieval
    scores 1.0 and 'right doc but in third place' scores 0.333."""
    expected = set(expected_doc_ids)
    for rank, doc_id in enumerate(retrieved_doc_ids, start=1):
        if doc_id in expected:
            return 1.0 / rank
    return 0.0


# ---------------------------------------------------------------------------
# TruLens triad (embedding-similarity implementations)
# ---------------------------------------------------------------------------


def _cosine(a: List[float], b: List[float]) -> float:
    return sum(x * y for x, y in zip(a, b))  # unit-normalized inputs


def _clip01(x: float) -> float:
    return max(0.0, min(1.0, x))


def make_triad_metrics(embedder: Embedder) -> List[Metric]:
    """Build the three RAG-triad metrics wired to the recorded spans.

    Selector wiring (TruLens 2.x OTEL mode uses dict selectors):
      * record input  -> the question the caller passed to answer()
      * record output -> the final answer string
      * context       -> the list returned by the RETRIEVAL span, i.e.
                         exactly what retrieve() returned
    """

    def context_relevance(question: str, contexts: List[str]) -> float:
        """Was the retrieved material about the question at all? Mean
        cosine similarity between the question and each chunk."""
        if not contexts:
            return 0.0
        vecs = embedder.embed([question] + list(contexts))
        q, ctx_vecs = vecs[0], vecs[1:]
        return _clip01(sum(_cosine(q, c) for c in ctx_vecs) / len(ctx_vecs))

    def groundedness(contexts: List[str], response: str) -> float:
        """Is the answer supported by the retrieved material? Similarity
        between the answer and the single best-supporting chunk. An
        abstention is perfectly grounded by definition: refusing to answer
        cannot hallucinate."""
        if is_abstention(response):
            return 1.0
        if not contexts or not response:
            return 0.0
        vecs = embedder.embed([response] + list(contexts))
        r, ctx_vecs = vecs[0], vecs[1:]
        return _clip01(max(_cosine(r, c) for c in ctx_vecs))

    def answer_relevance(question: str, response: str) -> float:
        """Does the answer address the question that was asked? Cosine
        similarity between question and answer. Abstentions score 0 here:
        a refusal, however safe, does not answer the question. The tension
        between this metric and groundedness is the whole point of
        measuring both."""
        if not question or not response or is_abstention(response):
            return 0.0
        vecs = embedder.embed([question, response])
        return _clip01(_cosine(vecs[0], vecs[1]))

    return [
        Metric(
            implementation=context_relevance,
            name="context_relevance",
            selectors={
                "question": Selector.select_record_input(),
                "contexts": Selector.select_context(collect_list=True),
            },
        ),
        Metric(
            implementation=groundedness,
            name="groundedness",
            selectors={
                "contexts": Selector.select_context(collect_list=True),
                "response": Selector.select_record_output(),
            },
        ),
        Metric(
            implementation=answer_relevance,
            name="answer_relevance",
            selectors={
                "question": Selector.select_record_input(),
                "response": Selector.select_record_output(),
            },
        ),
    ]


# ---------------------------------------------------------------------------
# Harness
# ---------------------------------------------------------------------------


def run_evaluation(
    pipeline: RagPipeline,
    eval_items: List[EvalItem],
    session: TruSession,
    app_name: str = config.TRULENS_APP_NAME,
    app_version: str = "dev",
) -> Dict[str, Any]:
    """Run every eval question through the pipeline inside a TruLens
    recording context, then compute both metric families.

    Returns {"rows": per-question dicts, "aggregate": summary floats}.

    Sequencing note that matters: force_flush() and compute_feedbacks()
    run BEFORE this function returns, so all spans and metric values are
    safely in the TruLens database before any later TruApp is constructed.
    TruLens 2.x silently drops pending evaluations if a new app starts
    while they are queued.
    """
    from trulens.apps.app import TruApp

    triad = make_triad_metrics(pipeline.embedder)
    tru_app = TruApp(
        pipeline,
        app_name=app_name,
        app_version=app_version,
        main_method=pipeline.answer,
        feedbacks=triad,
    )

    rows: List[Dict[str, Any]] = []
    with tru_app:
        for item in eval_items:
            t0 = time.perf_counter()
            answer = pipeline.answer(item.question)
            latency_s = time.perf_counter() - t0
            retrieved_doc_ids = [m["doc_id"] for m in pipeline.last_matches]
            abstained = is_abstention(answer)
            row: Dict[str, Any] = {
                "qid": item.qid,
                "question": item.question,
                "answerable": item.answerable,
                "answer": answer,
                "abstained": abstained,
                "latency_s": round(latency_s, 4),
                "retrieved_doc_ids": ";".join(retrieved_doc_ids),
                "hit": retrieval_hit(item.expected_doc_ids, retrieved_doc_ids)
                if item.answerable
                else None,
                "mrr": reciprocal_rank(item.expected_doc_ids, retrieved_doc_ids)
                if item.answerable
                else None,
                "rougeL_f": rouge_l_f(item.reference_answer, answer)
                if item.answerable and not abstained
                else (0.0 if item.answerable else None),
            }
            rows.append(row)

    session.force_flush()
    tru_app.compute_feedbacks()
    session.force_flush()

    aggregate = aggregate_rows(rows)
    aggregate.update(read_triad_from_leaderboard(session, app_name, app_version))
    return {"rows": rows, "aggregate": aggregate}


def aggregate_rows(rows: List[Dict[str, Any]]) -> Dict[str, float]:
    """Fold per-question rows into run-level metrics.

    Definitions:
      * retrieval_hit_rate, retrieval_mrr: over answerable questions only.
      * rougeL_f: over answerable questions; a wrong abstention counts as
        0.0 rather than being excluded, so refusing everything cannot game
        the metric.
      * abstain_recall: over unanswerable questions, the fraction where
        the pipeline correctly refused. This is the safety number.
      * false_abstain_rate: over answerable questions, the fraction where
        the pipeline refused anyway. This is the cost-of-caution number.
    """
    answerable = [r for r in rows if r["answerable"]]
    unanswerable = [r for r in rows if not r["answerable"]]

    def mean(values: List[float]) -> float:
        return sum(values) / len(values) if values else 0.0

    return {
        "n_questions": float(len(rows)),
        "retrieval_hit_rate": mean([1.0 if r["hit"] else 0.0 for r in answerable]),
        "retrieval_mrr": mean([r["mrr"] for r in answerable]),
        "rougeL_f": mean([r["rougeL_f"] for r in answerable]),
        "abstain_recall": mean([1.0 if r["abstained"] else 0.0 for r in unanswerable]),
        "false_abstain_rate": mean([1.0 if r["abstained"] else 0.0 for r in answerable]),
        "latency_s_avg": mean([r["latency_s"] for r in rows]),
    }


def read_triad_from_leaderboard(
    session: TruSession, app_name: str, app_version: str
) -> Dict[str, float]:
    """Pull the triad aggregates for one app version from the TruLens
    leaderboard, so MLflow logs the same numbers the TruLens dashboard
    shows."""
    df = session.get_leaderboard()
    df = df.reset_index()
    mask = (df["app_name"] == app_name) & (df["app_version"] == app_version)
    subset = df[mask]
    out: Dict[str, float] = {}
    for metric in ("context_relevance", "groundedness", "answer_relevance"):
        if metric in subset.columns and len(subset) > 0:
            value = subset.iloc[0][metric]
            out[metric] = float(value) if value == value else 0.0  # NaN guard
    return out
