"""Load the Cordwell document corpus from disk.

Responsibilities:
  1. Read every markdown file in the corpus directory, surviving files that
     are not clean UTF-8 (real corpora always contain a few).
  2. Parse the YAML-ish front matter block into document metadata.
  3. Filter superseded document versions so only the latest document per
     doc_family reaches the index.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Tuple

from . import config


@dataclass
class Document:
    doc_id: str
    doc_family: str
    title: str
    category: str
    effective_date: str  # ISO yyyy-mm-dd; lexical sort equals date sort
    version: str
    path: str
    body: str
    meta: Dict[str, str] = field(default_factory=dict)


def read_text_tolerant(path: Path) -> str:
    """Read a text file that may not be valid UTF-8.

    Strategy: try UTF-8 first (with BOM tolerance via utf-8-sig), then fall
    back to Windows-1252, which maps every byte to some character and is the
    most common source of "mystery bytes" in North American business
    documents (smart quotes, accented letters pasted from Word or Outlook).

    Raises UnicodeDecodeError only if both decodings fail, which for
    cp1252 essentially never happens.
    """
    raw = path.read_bytes()
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    # Last resort: decode with replacement characters so ingestion never
    # dies on one bad file. We keep this explicit rather than silent.
    return raw.decode("utf-8", errors="replace")


def parse_front_matter(text: str) -> Tuple[Dict[str, str], str]:
    """Split a document into (metadata dict, body).

    Front matter is a leading block delimited by lines containing only
    '---', with simple 'key: value' pairs inside. This is a deliberately
    small hand parser: the corpus schema is flat, so pulling in a YAML
    library would be incidental complexity.
    """
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text

    meta: Dict[str, str] = {}
    body_start = len(lines)
    for i, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            body_start = i + 1
            break
        if ":" in line:
            key, _, value = line.partition(":")
            meta[key.strip()] = value.strip().strip('"')
    body = "\n".join(lines[body_start:]).strip()
    return meta, body


def load_corpus(corpus_dir: Path | None = None) -> List[Document]:
    """Load every .md document in the corpus directory (except MANIFEST.md)."""
    corpus_dir = corpus_dir or config.CORPUS_DIR
    docs: List[Document] = []
    for path in sorted(corpus_dir.glob("*.md")):
        if path.name.upper().startswith("MANIFEST"):
            continue
        text = read_text_tolerant(path)
        meta, body = parse_front_matter(text)
        docs.append(
            Document(
                doc_id=meta.get("doc_id", path.stem),
                doc_family=meta.get("doc_family", path.stem),
                title=meta.get("title", path.stem),
                category=meta.get("category", "uncategorized"),
                effective_date=meta.get("effective_date", "1970-01-01"),
                version=meta.get("version", "1.0"),
                path=str(path),
                body=body,
                meta=meta,
            )
        )
    return docs


def select_active_documents(docs: List[Document]) -> List[Document]:
    """Keep only the newest document in each doc_family.

    Corpora accumulate superseded versions of the same policy or manual.
    Indexing both versions is how a RAG assistant ends up confidently
    quoting a return window that stopped being true two years ago: both
    versions are topically relevant, so retrieval happily serves either.

    Rule: group by doc_family, keep the document with the greatest
    effective_date. Ties break on version string, then doc_id, so the
    result is deterministic.
    """
    by_family: Dict[str, Document] = {}
    for doc in docs:
        key = doc.doc_family
        incumbent = by_family.get(key)
        if incumbent is None:
            by_family[key] = doc
            continue
        candidate_rank = (doc.effective_date, doc.version, doc.doc_id)
        incumbent_rank = (incumbent.effective_date, incumbent.version, incumbent.doc_id)
        if candidate_rank > incumbent_rank:
            by_family[key] = doc
    # Preserve original ordering for determinism of downstream chunk ids.
    active_ids = {d.doc_id for d in by_family.values()}
    return [d for d in docs if d.doc_id in active_ids]
