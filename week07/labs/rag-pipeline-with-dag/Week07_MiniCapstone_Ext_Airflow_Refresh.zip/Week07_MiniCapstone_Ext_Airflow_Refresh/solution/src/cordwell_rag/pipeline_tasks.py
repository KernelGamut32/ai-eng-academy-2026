"""Orchestration task functions for the scheduled knowledge-base refresh.

This module is the seam between Airflow and the RAG system. Every function
here is a plain Python callable with JSON-serializable inputs and outputs,
which buys three things at once:

  * The Airflow DAG stays thin: each Airflow task wraps exactly one of
    these functions, so the DAG file is wiring, not logic.
  * Everything is unit-testable without Airflow installed: the functions
    know nothing about task instances, XCom, or context.
  * XCom compatibility is automatic: plain dicts of strings and numbers
    pass between tasks with no custom serialization.

The store factory (_build_store) exists as a named seam so tests can
substitute a fake index; production code never passes a store in.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List

from . import config

# ---------------------------------------------------------------------------
# Internal factories (seams for tests; production uses the defaults)
# ---------------------------------------------------------------------------


def _build_store():
    """Construct the vector store. Kept as a module-level factory so tests
    can monkeypatch one name instead of reaching into task internals."""
    from .vector_store import PineconeLocalStore

    return PineconeLocalStore()


def _build_embedder():
    from .embeddings import get_embedder

    return get_embedder()


# ---------------------------------------------------------------------------
# Task 1: preflight
# ---------------------------------------------------------------------------


def check_services_or_raise(timeout_s: float = 3.0) -> Dict[str, str]:
    """Ping the services the refresh needs and fail fast if any is down.

    Returns {service_name: 'up'} for the record when everything answers.
    Raises RuntimeError naming every unreachable service otherwise, so a
    scheduled run that cannot possibly succeed dies in its first task
    with a message that says exactly what to start, instead of failing
    halfway through ingest with a connection traceback.
    """
    import httpx

    required = {
        "pinecone": config.PINECONE_HOST,
        "mlflow": config.MLFLOW_TRACKING_URI,
    }
    down: List[str] = []
    status: Dict[str, str] = {}
    for name, url in required.items():
        try:
            httpx.get(url, timeout=timeout_s)
            status[name] = "up"
        except Exception as exc:
            down.append(f"{name} ({url}): {type(exc).__name__}")
    if down:
        raise RuntimeError(
            "refresh preflight failed, required services unreachable: "
            + "; ".join(down)
        )
    return status


# ---------------------------------------------------------------------------
# Task 2: ingest
# ---------------------------------------------------------------------------


def refresh_ingest() -> Dict[str, int]:
    """Run the full corpus refresh: load, version-select, chunk, dedupe,
    embed, rebuild the index, upsert.

    Returns the stage counts as a plain dict (XCom-friendly):
      documents_loaded, documents_active, chunks, duplicates_dropped,
      vectors_upserted.

    Raises RuntimeError if the refresh would leave the index empty or if
    upsert wrote fewer vectors than chunks: a scheduled refresh that
    silently publishes an empty or partial index is the worst outcome
    this pipeline can have, so both conditions are loud failures.
    """
    from .chunking import chunk_corpus
    from .corpus_loader import load_corpus, select_active_documents

    docs = load_corpus()
    active = select_active_documents(docs)
    chunks, dup_dropped = chunk_corpus(active)
    if not chunks:
        raise RuntimeError("refresh produced zero chunks; refusing to publish an empty index")

    embedder = _build_embedder()
    vectors = embedder.embed([c.text for c in chunks])

    store = _build_store()
    store.ensure_fresh_index()
    written = store.upsert_chunks(chunks, vectors)
    if written != len(chunks):
        raise RuntimeError(
            f"partial upsert: {written} of {len(chunks)} vectors written; "
            "index state is not trustworthy"
        )

    return {
        "documents_loaded": len(docs),
        "documents_active": len(active),
        "chunks": len(chunks),
        "duplicates_dropped": dup_dropped,
        "vectors_upserted": written,
    }


# ---------------------------------------------------------------------------
# Task 3: evaluation sweep
# ---------------------------------------------------------------------------


def run_refresh_sweep(refresh_tag: str) -> Dict[str, Any]:
    """Run the full 6-configuration evaluation sweep against the freshly
    ingested index, logging every run to MLflow.

    refresh_tag is a caller-supplied label (the DAG passes the logical
    date) logged as an extra MLflow param on every run, so the runs from
    one scheduled refresh are groupable in the UI.

    Returns {"run_ids": [...], "refresh_tag": tag}.
    """
    import mlflow

    from trulens.core import TruSession

    from .evaluation import load_eval_set
    from .experiments import run_sweep

    embedder = _build_embedder()
    store = _build_store()
    store.connect_existing_index()

    items = load_eval_set()
    config.ensure_dirs()
    session = TruSession(database_url=config.TRULENS_DB_URL)

    # tracking_uri is passed explicitly rather than relying on run_sweep's
    # default: that default binds config.MLFLOW_TRACKING_URI at IMPORT
    # time, so anything that changes config afterwards (tests, an env
    # override applied late) would be silently ignored. Reading config at
    # call time keeps the task honest.
    run_ids = run_sweep(
        embedder, store, items, session, tracking_uri=config.MLFLOW_TRACKING_URI
    )

    # Stamp every run from this refresh with the tag, after the fact, so
    # run_sweep itself stays refresh-agnostic.
    mlflow.set_tracking_uri(config.MLFLOW_TRACKING_URI)
    client = mlflow.tracking.MlflowClient()
    for run_id in run_ids:
        client.set_tag(run_id, "refresh_tag", refresh_tag)

    return {"run_ids": run_ids, "refresh_tag": refresh_tag}


# ---------------------------------------------------------------------------
# Task 4: champion selection
# ---------------------------------------------------------------------------


def select_refresh_champion() -> Dict[str, Any]:
    """Run gates-then-composite champion selection over the MLflow store
    and return the verdict dict unchanged.

    The verdict's status field ('champion_selected' or 'no_eligible_run')
    is what the DAG's branch task switches on. This wrapper exists so the
    DAG imports one orchestration module rather than reaching into
    experiments directly, and so the selection call site is patchable in
    tests.
    """
    from .experiments import select_champion

    return select_champion()


# ---------------------------------------------------------------------------
# Task 5a: publish report (champion path)
# ---------------------------------------------------------------------------


def write_refresh_report(
    verdict: Dict[str, Any],
    counts: Dict[str, int],
    run_date: str,
) -> str:
    """Write the dated refresh report and return its path as a string.

    The report is the human-readable artifact of one scheduled refresh:
    what was ingested, what won, and by which numbers. run_date comes
    from the DAG's data interval (never from wall-clock time inside the
    task, so re-running a past interval reproduces the same filename).
    """
    reports_dir = config.ARTIFACTS_DIR / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    path = reports_dir / f"refresh_{run_date}.md"

    metrics = verdict.get("metrics", {})
    params = verdict.get("params", {})
    lines = [
        f"# Cordwell KB Refresh Report: {run_date}",
        "",
        "## Ingest",
        "",
        f"- Documents loaded: {counts.get('documents_loaded', 'n/a')}",
        f"- Active after versioning: {counts.get('documents_active', 'n/a')}",
        f"- Chunks indexed: {counts.get('chunks', 'n/a')}"
        f" ({counts.get('duplicates_dropped', 'n/a')} duplicates dropped)",
        f"- Vectors upserted: {counts.get('vectors_upserted', 'n/a')}",
        "",
        "## Champion",
        "",
        f"- Run: {verdict.get('run_name', 'n/a')} ({verdict.get('run_id', 'n/a')})",
        f"- Composite: {verdict.get('composite', 0.0):.4f}",
        f"- Variant: {params.get('variant', 'n/a')}, top_k: {params.get('top_k', 'n/a')}",
        f"- Backend: {params.get('backend', 'n/a')},"
        f" embeddings: {params.get('embedding_backend', 'n/a')}",
        "",
        "## Champion metrics",
        "",
    ]
    for name in sorted(metrics):
        lines.append(f"- {name}: {metrics[name]:.4f}")
    lines += [
        "",
        f"Generated by the scheduled refresh DAG at {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())}.",
        "",
    ]
    path.write_text("\n".join(lines))
    return str(path)


# ---------------------------------------------------------------------------
# Task 5b: no-champion alert (failure path)
# ---------------------------------------------------------------------------


def raise_no_champion(verdict: Dict[str, Any]) -> None:
    """Terminal task for the no-eligible-run branch: record the gate
    failure counts where the operator will see them, then fail loudly.

    A scheduled refresh whose sweep produced no shippable configuration
    must surface as a FAILED run in the Airflow UI, not a green one with
    a sad log line; raising is therefore the entire job of this task.
    """
    failures = verdict.get("gate_failures", {})
    detail = ", ".join(f"{gate}: {count} runs failed" for gate, count in failures.items())
    raise RuntimeError(
        "refresh completed but no configuration passed the champion gates "
        f"({detail or 'no gate detail available'}); index was refreshed but "
        "champion.json was NOT updated"
    )
