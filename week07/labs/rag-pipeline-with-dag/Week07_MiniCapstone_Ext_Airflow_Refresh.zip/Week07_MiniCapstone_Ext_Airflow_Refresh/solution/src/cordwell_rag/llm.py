"""LLM backends: offline (deterministic), LM Studio, and Ollama.

Standing cohort pattern:
  * BACKEND_MODE comes from the LAB_BACKEND environment variable and is one
    of offline | lmstudio | ollama.
  * LM Studio and Ollama both expose OpenAI-compatible endpoints, so they
    share one client code path and differ only by base URL and model tag.
  * Selecting a live backend whose server is down raises
    openai.APIConnectionError. There is no silent fallback to offline mode:
    a demo that quietly switched backends would be lying about its results.

The offline backend is not a mock that returns canned strings. It is a
real, if simple, answerer: it scores every sentence in the retrieved
context against the question using the active embedder and returns the
best-matching sentences. That makes the whole pipeline runnable and
gradeable with zero servers, and it gives the evaluation harness honest
variation to measure.
"""

from __future__ import annotations

import re
from typing import Dict, List, Tuple

from . import config
from .embeddings import Embedder

_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")


def get_backend() -> str:
    return config.BACKEND_MODE


def _base_url_for(backend: str) -> str:
    if backend == "lmstudio":
        return config.LMSTUDIO_BASE_URL
    if backend == "ollama":
        return config.OLLAMA_BASE_URL
    raise ValueError(
        f"Unknown LLM backend {backend!r}. Expected 'offline', 'lmstudio', or 'ollama'."
    )


def chat_completion(
    messages: List[Dict[str, str]],
    temperature: float = 0.2,
    max_tokens: int = 400,
    backend: str | None = None,
    model: str | None = None,
    base_url_override: str | None = None,
    timeout: float | None = None,
    max_retries: int | None = None,
) -> str:
    """Call a live local model through the shared OpenAI-compatible path.

    Only valid for lmstudio and ollama. The offline backend never builds
    chat messages; it answers extractively (see offline_extractive_answer),
    so calling this with backend='offline' is a programming error and
    raises ValueError.

    The three override arguments exist for tests and connectivity
    debugging; normal calls leave them as None and take the config values.
    A dead server raises openai.APIConnectionError. There is deliberately
    no silent fallback to another backend: a pipeline that quietly swaps
    models mid-experiment produces results nobody can trust.
    """
    backend = backend or get_backend()
    if backend == "offline":
        raise ValueError(
            "chat_completion() is for live backends. The offline backend "
            "answers via offline_extractive_answer()."
        )
    base_url = base_url_override or _base_url_for(backend)
    model = model or config.LOCAL_MODEL

    from openai import OpenAI  # lazy: offline runs never import it

    client = OpenAI(
        base_url=base_url,
        api_key="not-needed-for-local",  # local servers ignore the key but require one
        timeout=config.LLM_TIMEOUT_S if timeout is None else timeout,
        max_retries=config.LLM_MAX_RETRIES if max_retries is None else max_retries,
    )
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    content = response.choices[0].message.content
    return (content or "").strip()


def split_sentences(text: str) -> List[str]:
    return [s.strip() for s in _SENTENCE_SPLIT_RE.split(text) if s.strip()]


def offline_extractive_answer(
    question: str,
    contexts: List[str],
    embedder: Embedder,
    max_sentences: int = 3,
    abstain_threshold: float | None = None,
) -> Tuple[str, float]:
    """Deterministic answerer used when BACKEND_MODE == 'offline'.

    Plain-terms description: chop the retrieved context into sentences,
    score each sentence against the question with the embedder, and stitch
    the best few sentences (in their original reading order) into the
    answer. If abstain_threshold is set and even the best sentence scores
    below it, refuse with the exact ABSTAIN_TEXT contract instead of
    guessing.

    Returns (answer_text, best_sentence_score).
    """
    sentences: List[str] = []
    for ctx in contexts:
        sentences.extend(split_sentences(ctx))
    if not sentences:
        return config.ABSTAIN_TEXT, 0.0

    vectors = embedder.embed([question] + sentences)
    q_vec, s_vecs = vectors[0], vectors[1:]

    def cosine(a: List[float], b: List[float]) -> float:
        return sum(x * y for x, y in zip(a, b))  # inputs are unit-normalized

    scored = [(cosine(q_vec, v), i) for i, v in enumerate(s_vecs)]
    scored.sort(reverse=True)
    best_score = scored[0][0] if scored else 0.0

    if abstain_threshold is not None and best_score < abstain_threshold:
        return config.ABSTAIN_TEXT, best_score

    top_indices = sorted(i for _, i in scored[:max_sentences])
    answer = " ".join(sentences[i] for i in top_indices)
    return answer, best_score
