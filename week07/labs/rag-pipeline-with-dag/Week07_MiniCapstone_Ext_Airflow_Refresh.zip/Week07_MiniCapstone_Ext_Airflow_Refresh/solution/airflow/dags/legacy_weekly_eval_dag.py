"""Weekly evaluation-only DAG, migrated to Airflow 3 (ticket CORD-2214).

Runs the evaluation sweep and champion selection WITHOUT re-ingesting,
as a drift check between nightly refreshes: if the champion changes when
the data did not, the eval set or the criteria moved.

Migration notes (Airflow 2.7 -> 3.3), deliberately minimal so the diff
against the legacy file reads as a migration, not a rewrite:

  * schedule_interval= -> schedule=. The old keyword was removed in 3.0
    and raises TypeError at DAG construction, which the UI surfaces as a
    DAG import error.
  * {{ execution_date }} -> {{ data_interval_end }}. The execution_date
    template variable was removed in 3.0; rendering it raises a jinja
    UndefinedError at RUN time, after the DAG parses cleanly, which is
    exactly why migrations that only fix the parse error get burned a
    second time.
"""

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator

_SRC_CANDIDATES = [
    Path("/opt/airflow/cordwell_src"),
    Path(__file__).resolve().parents[2] / "src",
]
for _src in _SRC_CANDIDATES:
    if _src.is_dir() and str(_src) not in sys.path:
        sys.path.insert(0, str(_src))


def _run_weekly_eval(eval_date: str) -> None:
    from cordwell_rag.pipeline_tasks import run_refresh_sweep, select_refresh_champion

    result = run_refresh_sweep(refresh_tag=f"weekly-eval-{eval_date}")
    verdict = select_refresh_champion()
    print(f"weekly eval {eval_date}: {len(result['run_ids'])} runs, verdict {verdict['status']}")


with DAG(
    dag_id="cordwell_weekly_eval",
    description="Weekly drift check: evaluation sweep + champion selection, no ingest",
    schedule="0 6 * * 1",
    start_date=datetime(2026, 8, 1),
    catchup=False,
    tags=["cordwell", "rag", "legacy-migrated"],
) as dag:
    run_eval = PythonOperator(
        task_id="run_weekly_eval",
        python_callable=_run_weekly_eval,
        op_kwargs={"eval_date": "{{ data_interval_end.strftime('%Y-%m-%d') }}"},
    )
