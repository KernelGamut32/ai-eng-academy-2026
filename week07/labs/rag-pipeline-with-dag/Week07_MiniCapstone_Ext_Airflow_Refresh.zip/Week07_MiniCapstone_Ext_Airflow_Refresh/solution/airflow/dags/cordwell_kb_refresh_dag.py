"""Scheduled knowledge-base refresh for the Cordwell RAG system.

The nightly pipeline: verify services, rebuild the index from the corpus,
run the full evaluation sweep, select a champion against the gates, and
either publish the dated refresh report or fail the run loudly when no
configuration is eligible.

Airflow 3 notes baked into this file (each was a live migration issue):

  * schedule= takes the cron string directly. The Airflow 2 keyword
    schedule_interval= does not exist in 3.x and raises TypeError at DAG
    construction, which surfaces as an import error in the UI.
  * A bare cron string on Airflow 3.3 builds a CronTriggerTimetable:
    the DAG fires AT the cron moment with a zero-width data interval,
    rather than after a full interval elapses as Airflow 2 did.
  * {{ execution_date }} and the execution_date context key were removed
    in 3.0. The refresh date below comes from data_interval_end.
  * Heavy imports (the RAG package, mlflow, trulens) happen INSIDE task
    functions, never at module top level: the scheduler re-parses every
    DAG file continuously, and a DAG that imports torch at parse time
    makes every scheduler loop pay for it.
"""

from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path

from airflow.sdk import dag, task

# Make the cordwell_rag package importable inside the Airflow container.
# docker-compose mounts the package source at /opt/airflow/cordwell_src;
# when the DAG runs outside the container (airflow dags test on a laptop),
# the fallback walks up from this file to the src directory.
_SRC_CANDIDATES = [
    Path("/opt/airflow/cordwell_src"),
    Path(__file__).resolve().parents[2] / "src",
]
for _src in _SRC_CANDIDATES:
    if _src.is_dir() and str(_src) not in sys.path:
        sys.path.insert(0, str(_src))

DAG_ID = "cordwell_kb_refresh"

DEFAULT_ARGS = {
    "owner": "ml-platform",
    # Ingest and the sweep touch network services; one transient hiccup
    # should not kill a nightly run. Two retries with a short pause is
    # the polite amount of stubbornness.
    "retries": 2,
    "retry_delay": timedelta(minutes=2),
}


@dag(
    dag_id=DAG_ID,
    description="Nightly Cordwell knowledge-base refresh: ingest, evaluate, select champion, report",
    # Cron string -> CronTriggerTimetable on Airflow 3.3: fires at 02:30
    # with a zero-width data interval. NOT schedule_interval= (removed).
    schedule="30 2 * * *",
    start_date=datetime(2026, 8, 1),
    # catchup=False: if the stack was down for a week, we want ONE fresh
    # refresh on restart, not seven stale backfills racing each other to
    # rebuild the same index.
    catchup=False,
    default_args=DEFAULT_ARGS,
    # The sweep tags MLflow runs with the refresh date; two refreshes
    # interleaving would corrupt both sets of numbers.
    max_active_runs=1,
    tags=["cordwell", "rag", "refresh"],
)
def cordwell_kb_refresh():
    @task
    def preflight() -> dict:
        """Fail fast if Pinecone or MLflow is unreachable."""
        from cordwell_rag.pipeline_tasks import check_services_or_raise

        return check_services_or_raise()

    @task
    def ingest() -> dict:
        """Rebuild the index from the corpus; returns stage counts."""
        from cordwell_rag.pipeline_tasks import refresh_ingest

        return refresh_ingest()

    @task
    def evaluate(counts: dict, data_interval_end=None) -> dict:
        """Run the evaluation sweep, tagging every MLflow run with the
        refresh date. Declaring data_interval_end as a parameter makes
        Airflow inject it from the run context; execution_date no longer
        exists in Airflow 3."""
        from cordwell_rag.pipeline_tasks import run_refresh_sweep

        refresh_tag = data_interval_end.strftime("%Y-%m-%d")
        return run_refresh_sweep(refresh_tag)

    @task
    def select(sweep_result: dict) -> dict:
        """Gates-then-composite champion selection; returns the verdict."""
        from cordwell_rag.pipeline_tasks import select_refresh_champion

        return select_refresh_champion()

    @task.branch
    def route_on_verdict(verdict: dict) -> str:
        """Send the run down the publish path when a champion was
        selected, or the alert path when nothing passed the gates. A
        branch task returns the task_id to follow; every other downstream
        task is skipped."""
        if verdict.get("status") == "champion_selected":
            return "publish_report"
        return "no_champion_alert"

    @task
    def publish_report(verdict: dict, counts: dict, data_interval_end=None) -> str:
        """Write the dated refresh report. The date comes from the data
        interval, not the wall clock, so re-running a past interval
        reproduces the same report file."""
        from cordwell_rag.pipeline_tasks import write_refresh_report

        run_date = data_interval_end.strftime("%Y-%m-%d")
        return write_refresh_report(verdict, counts, run_date)

    @task
    def no_champion_alert(verdict: dict) -> None:
        """Terminal failure task: surface the gate failures and fail the
        run so the schedule shows red."""
        from cordwell_rag.pipeline_tasks import raise_no_champion

        raise_no_champion(verdict)

    # ------------------------------------------------------------------
    # Wiring. TaskFlow builds data dependencies from the call graph, so
    # passing one task's return into another IS the dependency edge.
    # ------------------------------------------------------------------
    services = preflight()
    counts = ingest()
    services >> counts

    sweep_result = evaluate(counts)
    verdict = select(sweep_result)
    choice = route_on_verdict(verdict)

    report = publish_report(verdict, counts)
    alert = no_champion_alert(verdict)
    choice >> [report, alert]


cordwell_kb_refresh()
