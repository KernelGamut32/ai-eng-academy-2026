"""Provided tests. You do NOT write tests in this lab.

Run them to check your work as you build cordwell_triage/agent.py:

    pytest -q                     # run everything
    pytest -q -k classify         # run one topic
    pytest -q tests/test_agent.py::test_branch_refund_goes_to_human

Tests are grouped Part A through Part E to match the lab handout. Early parts
pass first; the whole file goes green when the agent is complete.
"""
from __future__ import annotations

import pytest
from langgraph.checkpoint.memory import InMemorySaver

from cordwell_triage.agent import (
    TriageState,
    classify,
    draft_reply,
    revise,
    escalate,
    finalize,
    route_by_category,
    review_gate,
    build_graph,
)
from cordwell_triage.helpers import MAX_WORDS, count_words


def user(text: str) -> dict:
    return {"messages": [{"role": "user", "content": text}]}


# --- Part A: state and the classify node ---------------------------------
def test_state_has_required_keys():
    assert set(TriageState.__annotations__) == {
        "messages", "category", "draft", "attempts", "outcome"
    }

def test_classify_reads_last_message_and_returns_category():
    out = classify(user("How do I reset a tripped breaker?"))
    assert out == {"category": "how_to"}

def test_classify_refund():
    assert classify(user("I need a refund"))["category"] == "refund"


# --- Part B: nodes and routing ------------------------------------------
def test_draft_reply_sets_draft_and_resets_attempts():
    out = draft_reply({"category": "how_to"})
    assert out["attempts"] == 0
    assert "Cordwell" in out["draft"]

def test_route_auto_category_goes_to_draft():
    assert route_by_category({"category": "how_to"}) == "draft_reply"

def test_route_refund_goes_to_escalate():
    assert route_by_category({"category": "refund"}) == "escalate"

def test_route_unknown_goes_to_escalate():
    assert route_by_category({"category": "unknown"}) == "escalate"

def test_escalate_sets_outcome():
    assert escalate({})["outcome"] == "routed to a human agent"

def test_finalize_sets_outcome_and_appends_message():
    out = finalize({"draft": "hello"})
    assert out["outcome"] == "handled automatically"
    assert out["messages"][0]["content"] == "hello"


# --- Part C: the revise cycle -------------------------------------------
def test_revise_increments_attempts_and_shortens():
    out = revise({"draft": "One sentence. Two sentence. Three sentence.", "attempts": 0})
    assert out["attempts"] == 1
    assert count_words(out["draft"]) < 6

def test_review_gate_loops_when_over_limit_with_attempts_left():
    long_draft = " ".join(["word"] * (MAX_WORDS + 5))
    assert review_gate({"draft": long_draft, "attempts": 0}) == "revise"

def test_review_gate_finalizes_when_within_limit():
    short_draft = "short reply"
    assert review_gate({"draft": short_draft, "attempts": 0}) == "finalize"

def test_review_gate_gives_up_at_max_attempts():
    long_draft = " ".join(["word"] * (MAX_WORDS + 5))
    assert review_gate({"draft": long_draft, "attempts": 3}) == "finalize"


# --- Part B/C end to end: the compiled graph -----------------------------
def test_branch_auto_ticket_is_handled_automatically():
    graph = build_graph()
    result = graph.invoke(user("How do I reset a tripped breaker?"))
    assert result["outcome"] == "handled automatically"
    assert count_words(result["draft"]) <= MAX_WORDS

def test_branch_refund_goes_to_human():
    graph = build_graph()
    result = graph.invoke(user("I want a refund for a broken drill."))
    assert result["outcome"] == "routed to a human agent"

def test_loop_actually_iterates():
    graph = build_graph()
    result = graph.invoke(user("How do I reset a tripped breaker?"))
    assert result["attempts"] >= 1  # at least one revision happened


# --- Part D: persistence -------------------------------------------------
def test_memory_accumulates_across_turns():
    graph = build_graph(checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": "t1"}}
    graph.invoke(user("How do I reset a tripped breaker?"), config)
    final = graph.invoke(user("Where is my order?"), config)
    assert len(final["messages"]) == 4  # two user turns, two assistant turns


# --- Part E: interrupt ---------------------------------------------------
def test_interrupt_pauses_before_escalate():
    graph = build_graph(checkpointer=InMemorySaver(), interrupt_before=["escalate"])
    config = {"configurable": {"thread_id": "t2"}}
    graph.invoke(user("I want a refund"), config)
    assert graph.get_state(config).next == ("escalate",)

def test_interrupt_resumes_to_completion():
    graph = build_graph(checkpointer=InMemorySaver(), interrupt_before=["escalate"])
    config = {"configurable": {"thread_id": "t3"}}
    graph.invoke(user("I want a refund"), config)
    final = graph.invoke(None, config)
    assert final["outcome"] == "routed to a human agent"
