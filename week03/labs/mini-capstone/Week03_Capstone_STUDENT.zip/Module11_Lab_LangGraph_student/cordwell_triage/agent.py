"""STUDENT STARTER: Cordwell Home and Hardware support triage agent (LangGraph).

You build the LangGraph state machine in THIS FILE ONLY. Everything else in the
packet is provided and should not be changed: helpers.py, app.py, and the tests.

Work top to bottom. Each TODO maps to a Part in LAB.md, where you will also find
the exact expected output for every task. Run `pytest -q` any time to check
progress. Hints live in HINTS_DETAILED.md and HINTS_PROGRESSIVE.md.

The imports you need are already written for you below. You do not have to hunt
for import paths. Focus on state, nodes, edges, and the graph.
"""
from __future__ import annotations

from typing import Annotated, Optional
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

from .helpers import (
    MAX_WORDS,
    MAX_ATTEMPTS,
    AUTO_CATEGORIES,
    classify_text,
    first_draft_for,
    count_words,
    drop_last_sentence,
    last_user_text,
)


# --- Part A: State -------------------------------------------------------
class TriageState(TypedDict):
    """TODO (Part A): declare the shared state with five fields.

      messages : the conversation. Use the add_messages reducer so turns
                 ACCUMULATE across calls instead of overwriting. The reducer
                 worked example is in README under "Reducers".
      category : str   - the classification result
      draft    : str   - the drafted reply text
      attempts : int   - how many times revise has run
      outcome  : str   - the final outcome text

    Replace the line below with the five typed fields.
    """
    pass


# --- Part A / B / C: Nodes ----------------------------------------------
def classify(state: TriageState) -> dict:
    """TODO (Part A): classify the latest user message.

    Read the newest message text with last_user_text(state["messages"]),
    pass it to classify_text(...), and return {"category": <result>}.
    Return ONLY the key you set.
    """
    raise NotImplementedError


def draft_reply(state: TriageState) -> dict:
    """TODO (Part B): produce the first draft.

    Return the canned draft for state["category"] using first_draft_for(...),
    and reset "attempts" to 0. Return both keys.
    """
    raise NotImplementedError


def revise(state: TriageState) -> dict:
    """TODO (Part C): shorten the draft by one sentence and count the attempt.

    Return a shorter "draft" using drop_last_sentence(state["draft"]) and
    "attempts" incremented by one.
    """
    raise NotImplementedError


def escalate(state: TriageState) -> dict:
    """TODO (Part B): hand off to a human.

    Return "outcome" set to "routed to a human agent", and append one assistant
    message to "messages" telling the customer it was routed to a human.
    (Appending, not overwriting, is what the reducer on messages gives you.)
    """
    raise NotImplementedError


def finalize(state: TriageState) -> dict:
    """TODO (Part B): finish an auto-handled ticket.

    Return "outcome" set to "handled automatically", and append one assistant
    message whose content is the final state["draft"].
    """
    raise NotImplementedError


# --- Part B / C: Routers -------------------------------------------------
def route_by_category(state: TriageState) -> str:
    """TODO (Part B): return the name of the next node as a string.

    If state["category"] is one of AUTO_CATEGORIES, return "draft_reply".
    Otherwise return "escalate".
    """
    raise NotImplementedError


def review_gate(state: TriageState) -> str:
    """TODO (Part C): decide whether to loop or finish.

    Return "revise" when the draft is over MAX_WORDS words AND attempts are
    still below MAX_ATTEMPTS. Otherwise return "finalize". Use count_words(...).
    """
    raise NotImplementedError


# --- Part B / C / D / E: The graph factory -------------------------------
def build_graph(checkpointer=None, interrupt_before: Optional[list] = None):
    """TODO (Parts B-E): build, wire, and compile the graph.

    Required structure (a diagram of this is in README and LAB.md):
      nodes    : classify, draft_reply, revise, escalate, finalize
      entry    : START -> classify
      branch   : classify routes via route_by_category to "draft_reply" or "escalate"
      review   : draft_reply routes via review_gate to "revise" or "finalize"
      cycle    : revise ALSO routes via review_gate to "revise" or "finalize"
      exits    : escalate -> END ; finalize -> END

    Compile with builder.compile(...) and pass BOTH checkpointer and
    interrupt_before straight through (Parts D and E rely on that). Return the
    compiled graph.
    """
    raise NotImplementedError
