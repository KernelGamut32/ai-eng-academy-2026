"""Provided helpers for the Cordwell triage lab. Students do not modify this file.

These functions handle the plumbing that is NOT the point of the lab (keyword
classification, string trimming, reading message text). The lab is about the
LangGraph state machine, so this deterministic logic is given to you.
"""
from __future__ import annotations

# --- Configuration knobs -------------------------------------------------
MAX_WORDS = 20        # auto-replies must be at most this many words
MAX_ATTEMPTS = 3      # safety guard so the revise loop can never run forever

# Auto-handled categories go to the draft/revise path. Everything else
# (refunds, billing, or anything we cannot confidently classify) goes to a human.
AUTO_CATEGORIES = {"how_to", "order_status", "product_info"}

_CATEGORY_KEYWORDS = {
    "refund":       ["refund", "return", "money back", "chargeback"],
    "order_status": ["where is my order", "track", "shipping", "delivery", "arrive"],
    "how_to":       ["how do i", "how to", "install", "reset", "replace"],
    "product_info": ["in stock", "price", "dimensions", "warranty", "compatible"],
}

# Canned first-draft replies, deliberately verbose so the length policy bites.
_DRAFTS = {
    "how_to": (
        "Thanks for contacting Cordwell Home and Hardware. "
        "To reset a tripped breaker, switch it fully off and then back on. "
        "If it trips again, stop and contact a licensed electrician. "
        "Our stores also run a free in-aisle demo every weekend if you would like hands-on help."
    ),
    "order_status": (
        "Thanks for contacting Cordwell Home and Hardware. "
        "You can track any order from the Orders page using your order number. "
        "Most in-stock items ship within two business days. "
        "If your tracking has not updated in five days, reply here and we will investigate for you."
    ),
    "product_info": (
        "Thanks for contacting Cordwell Home and Hardware. "
        "Live stock and pricing are shown on each product page for your selected store. "
        "Warranty length varies by brand and is listed under product details. "
        "Tell us the exact model and we will confirm compatibility for your project."
    ),
}


def classify_text(text: str) -> str:
    """Return a category string for a ticket using simple keyword matching.

    Deterministic and offline. Returns 'unknown' if nothing matches.
    """
    lowered = text.lower()
    for category, keywords in _CATEGORY_KEYWORDS.items():
        if any(kw in lowered for kw in keywords):
            return category
    return "unknown"


def first_draft_for(category: str) -> str:
    """Return the canned verbose draft reply for an auto-handled category."""
    return _DRAFTS[category]


def count_words(text: str) -> int:
    """Count whitespace-separated words in text."""
    return len(text.split())


def drop_last_sentence(text: str) -> str:
    """Remove the final sentence from text. Sentences end with '. ' or '.'.

    Used by the revise step to shorten an over-long draft one sentence at a time.
    """
    parts = [p for p in text.split(". ") if p]
    if len(parts) <= 1:
        return text
    shortened = ". ".join(parts[:-1])
    if not shortened.endswith("."):
        shortened += "."
    return shortened


def last_user_text(messages: list) -> str:
    """Return the text of the most recent message.

    add_messages stores messages as objects with a .content attribute, but a
    plain dict with a 'content' key also works. This helper reads either form
    so you never have to worry about it inside a node.
    """
    msg = messages[-1]
    if hasattr(msg, "content"):
        return msg.content
    return msg["content"]
