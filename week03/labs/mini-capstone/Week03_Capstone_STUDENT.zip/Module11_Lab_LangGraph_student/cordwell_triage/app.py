"""Provided runner. Exercises every part of the lab. Students do not edit this.

Run from the lab root:  python -m cordwell_triage.app
"""
from __future__ import annotations

from langgraph.checkpoint.memory import InMemorySaver

from .agent import build_graph
from .helpers import count_words


def banner(title: str) -> None:
    print("\n" + "=" * 68)
    print(title)
    print("=" * 68)


def show_state(state: dict) -> None:
    print("category:", state.get("category"))
    print("attempts:", state.get("attempts"))
    print("outcome :", state.get("outcome"))
    draft = state.get("draft", "")
    if draft:
        print(f"draft   : ({count_words(draft)} words) {draft}")
    print("messages:")
    for m in state.get("messages", []):
        role = getattr(m, "type", None) or m.get("role")
        content = getattr(m, "content", None) or m.get("content")
        print(f"   [{role}] {content}")


def part_b_branch():
    banner("PART B - conditional branch")
    graph = build_graph()
    for ticket in ["How do I reset a tripped breaker?",
                   "I want a refund for a broken drill."]:
        print(f"\n--- ticket: {ticket!r} ---")
        result = graph.invoke({"messages": [{"role": "user", "content": ticket}]})
        show_state(result)


def part_c_loop():
    banner("PART C - the revise cycle (watch attempts climb)")
    graph = build_graph()
    ticket = "How do I reset a tripped breaker?"
    print(f"ticket: {ticket!r}\n")
    for step in graph.stream(
        {"messages": [{"role": "user", "content": ticket}]},
        stream_mode="updates",
    ):
        for node, update in step.items():
            note = ""
            if "draft" in update:
                note = f"draft now {count_words(update['draft'])} words"
            print(f"   ran {node:<12} {note}")


def part_d_memory():
    banner("PART D - persistence across turns (checkpointer + thread_id)")
    graph = build_graph(checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": "cust-42"}}

    graph.invoke({"messages": [{"role": "user", "content": "How do I reset a tripped breaker?"}]}, config)
    final = graph.invoke({"messages": [{"role": "user", "content": "Where is my order?"}]}, config)

    print("After two turns on the same thread, messages holds BOTH exchanges:")
    show_state(final)


def part_e_interrupt():
    banner("PART E - human-in-the-loop interrupt before escalate")
    graph = build_graph(checkpointer=InMemorySaver(), interrupt_before=["escalate"])
    config = {"configurable": {"thread_id": "cust-99"}}

    graph.invoke({"messages": [{"role": "user", "content": "I want a refund for a broken drill."}]}, config)
    snapshot = graph.get_state(config)
    print("paused before:", snapshot.next, "  (graph is waiting for a human)")

    print("\n... human approves, resuming ...\n")
    final = graph.invoke(None, config)
    print("resumed to completion:")
    show_state(final)


if __name__ == "__main__":
    part_b_branch()
    part_c_loop()
    part_d_memory()
    part_e_interrupt()
