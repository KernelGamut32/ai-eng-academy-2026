"""SOLUTION: Cordwell Home and Hardware support triage agent, built with LangGraph.

This is the file students build in the lab. Everything here is the LangGraph
state machine: state, nodes, routers, and the graph factory.
"""
from __future__ import annotations

from typing import Annotated, Optional
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

from .helpers import (
    MAX_WORDS,
    MAX_ATTEMPTS,
    AUTO_CATEGORIES,
    classify_text,
    first_draft_for,
    count_words,
    drop_last_sentence,
    last_user_text,
)


# --- Part A: State -------------------------------------------------------
class TriageState(TypedDict):
    # messages accumulates across turns because of the add_messages reducer.
    messages: Annotated[list, add_messages]
    category: str
    draft: str
    attempts: int
    outcome: str


# --- Part A / B / C: Nodes ----------------------------------------------
def classify(state: TriageState) -> dict:
    text = last_user_text(state["messages"])
    return {"category": classify_text(text)}


def draft_reply(state: TriageState) -> dict:
    return {"draft": first_draft_for(state["category"]), "attempts": 0}


def revise(state: TriageState) -> dict:
    return {
        "draft": drop_last_sentence(state["draft"]),
        "attempts": state["attempts"] + 1,
    }


def escalate(state: TriageState) -> dict:
    return {
        "outcome": "routed to a human agent",
        "messages": [
            {"role": "assistant",
             "content": "This ticket needs a specialist. I have routed it to a human agent."}
        ],
    }


def finalize(state: TriageState) -> dict:
    return {
        "outcome": "handled automatically",
        "messages": [{"role": "assistant", "content": state["draft"]}],
    }


# --- Part B / C: Routers -------------------------------------------------
def route_by_category(state: TriageState) -> str:
    if state["category"] in AUTO_CATEGORIES:
        return "draft_reply"
    return "escalate"


def review_gate(state: TriageState) -> str:
    over_limit = count_words(state["draft"]) > MAX_WORDS
    can_retry = state["attempts"] < MAX_ATTEMPTS
    if over_limit and can_retry:
        return "revise"
    return "finalize"


# --- Part B / C / D / E: The graph factory -------------------------------
def build_graph(checkpointer=None, interrupt_before: Optional[list] = None):
    builder = StateGraph(TriageState)

    builder.add_node("classify", classify)
    builder.add_node("draft_reply", draft_reply)
    builder.add_node("revise", revise)
    builder.add_node("escalate", escalate)
    builder.add_node("finalize", finalize)

    builder.add_edge(START, "classify")

    # Branch: auto-handle, or send to a human.
    builder.add_conditional_edges(
        "classify", route_by_category, ["draft_reply", "escalate"]
    )

    # Review the draft. The same gate guards both the first draft and each revision.
    builder.add_conditional_edges(
        "draft_reply", review_gate, ["revise", "finalize"]
    )
    # Cycle: revise routes back through the same gate until it complies or gives up.
    builder.add_conditional_edges(
        "revise", review_gate, ["revise", "finalize"]
    )

    builder.add_edge("escalate", END)
    builder.add_edge("finalize", END)

    return builder.compile(
        checkpointer=checkpointer,
        interrupt_before=interrupt_before,
    )
