# Instructor Solution Packet

This packet is the completed reference. Do not distribute it to students.

- `cordwell_triage/agent.py` is the full solution. `pytest -q` reports 19 passed.
- `Instructor_Demo_Script.md` is your facilitation script for running the lab.
- `Instructor_Walkthrough.md` is the line-by-line explanation of the solution.
- `README.md`, `LAB.md`, and the two `HINTS_*.md` files are copies of what the
  students receive, included here for reference.

Hand students the separate student packet, which contains the stubbed
`agent.py` and no solution or instructor files.
