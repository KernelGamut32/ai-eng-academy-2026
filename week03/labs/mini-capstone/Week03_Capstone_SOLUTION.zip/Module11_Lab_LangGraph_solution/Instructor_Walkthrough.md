# Instructor Walkthrough: Line by Line

**Module 11 · Cordwell Triage Lab · solution explained**
**Verified on Python 3.12.3 against langgraph 1.2.9, langgraph-checkpoint 4.1.1, langchain-core 1.4.9. The code uses only standard typing features and runs unchanged on the cohort's Python 3.13.**

This is your deep reference for the solution in `cordwell_triage/agent.py`. Use it
to field questions, to lead the closing walk-through, and to diagnose stuck
students fast. Every output quoted here was captured from an actual run.

---

## The graph at a glance

```
START -> classify
classify --route_by_category--> draft_reply | escalate
draft_reply --review_gate--> revise | finalize
revise --review_gate--> revise | finalize      (this back-edge is the cycle)
escalate -> END
finalize -> END
```

Rendered by `graph.get_graph().draw_mermaid()`, conditional edges appear dotted and
plain edges solid. The `revise -.-> revise` self-edge is the loop, visible in the
diagram. There are two decision points: `route_by_category` after classification,
and `review_gate` guarding the draft loop.

Five primitives from the lecture are all present:
- **State**: `TriageState`, a `TypedDict`.
- **Reducer**: `add_messages` on the `messages` field.
- **Conditional edges**: `route_by_category` and `review_gate`.
- **Cycle**: `revise` routing back through `review_gate`.
- **Checkpointer and interrupt**: passed into `compile()` for Parts D and E.

---

## The provided helpers (context only, students do not edit)

`helpers.py` holds the deterministic logic that is not the point of the lab, so it
is given. Worth knowing so you can answer "where does that come from":

- `MAX_WORDS = 20`, `MAX_ATTEMPTS = 3`: the policy knobs.
- `AUTO_CATEGORIES = {"how_to", "order_status", "product_info"}`: which categories
  the agent may answer without a human.
- `classify_text(text)`: keyword match, returns a category or `"unknown"`.
- `first_draft_for(category)`: returns the canned verbose draft (deliberately over
  the word limit so the loop has work to do).
- `count_words(text)`, `drop_last_sentence(text)`: the string tools the loop uses.
- `last_user_text(messages)`: returns the newest message's text, reading either a
  message object with `.content` or a plain dict. This exists so students never
  wrestle with message object shapes inside a node.

---

## agent.py, line by line

### Imports
```python
from typing import Annotated, Optional
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
```
- `Annotated` is how a reducer is attached to a state field.
- `TypedDict` from `typing_extensions` is the LangGraph-recommended import for state
  schemas.
- `StateGraph` is the builder; `START` and `END` are the entry and exit sentinels.
- `add_messages` is the built-in reducer that appends messages instead of
  overwriting.

These are pre-written in the starter. The unfamiliar import paths are exactly the
kind of thing that should not eat student time, so they are given.

### State
```python
class TriageState(TypedDict):
    messages: Annotated[list, add_messages]
    category: str
    draft: str
    attempts: int
    outcome: str
```
- `messages: Annotated[list, add_messages]`: the one field with append semantics.
  When any node returns a `messages` list, the reducer appends it to what is already
  there. This is what makes memory accumulate in Part D.
- The other four fields use the default overwrite behavior, which is what you want
  for a single current value each.

If a student writes `messages: list` with no `Annotated`, Part A and B still pass,
but Part D fails with two messages instead of four. That is the most common
delayed-failure in the lab.

### classify
```python
def classify(state: TriageState) -> dict:
    text = last_user_text(state["messages"])
    return {"category": classify_text(text)}
```
- Reads the newest message text through the provided helper.
- Returns a partial update with only `category`. This is the node contract in one
  line: state in, an update dict out.

### draft_reply
```python
def draft_reply(state: TriageState) -> dict:
    return {"draft": first_draft_for(state["category"]), "attempts": 0}
```
- Looks the draft up by category.
- Sets `attempts` to 0 so the loop counter starts clean. If this reset is missing,
  `review_gate` later reads a key nobody set and raises `KeyError: 'attempts'`.

### revise
```python
def revise(state: TriageState) -> dict:
    return {
        "draft": drop_last_sentence(state["draft"]),
        "attempts": state["attempts"] + 1,
    }
```
- Removes one sentence from the draft.
- Increments `attempts`. Each pass therefore makes measurable progress on both
  fronts: the draft gets shorter, and the attempt count climbs toward the guard.

### escalate
```python
def escalate(state: TriageState) -> dict:
    return {
        "outcome": "routed to a human agent",
        "messages": [{"role": "assistant",
                      "content": "This ticket needs a specialist. I have routed it to a human agent."}],
    }
```
- Sets the outcome.
- Returns a one-item `messages` list. Because of the reducer, this appends the note
  after the user's message rather than replacing history.

### finalize
```python
def finalize(state: TriageState) -> dict:
    return {
        "outcome": "handled automatically",
        "messages": [{"role": "assistant", "content": state["draft"]}],
    }
```
- The compliant final draft becomes the assistant's reply, appended the same way.

### route_by_category
```python
def route_by_category(state: TriageState) -> str:
    if state["category"] in AUTO_CATEGORIES:
        return "draft_reply"
    return "escalate"
```
- A router returns the name of the next node as a string.
- Anything outside `AUTO_CATEGORIES`, including `refund` and `unknown`, goes to a
  human. Defaulting uncertainty to a person is a deliberate safety choice worth
  calling out.

### review_gate
```python
def review_gate(state: TriageState) -> str:
    over_limit = count_words(state["draft"]) > MAX_WORDS
    can_retry = state["attempts"] < MAX_ATTEMPTS
    if over_limit and can_retry:
        return "revise"
    return "finalize"
```
- Two booleans. Loop only while the draft is too long AND attempts remain.
- `can_retry` is the infinite-loop guard. Without it, a draft that can never comply
  (for example a single sentence over the limit, which `drop_last_sentence` leaves
  unchanged) would loop until LangGraph raises `GraphRecursionError` at its default
  recursion limit. This is the production lesson of the whole Part C.

### build_graph
```python
def build_graph(checkpointer=None, interrupt_before=None):
    builder = StateGraph(TriageState)

    builder.add_node("classify", classify)
    builder.add_node("draft_reply", draft_reply)
    builder.add_node("revise", revise)
    builder.add_node("escalate", escalate)
    builder.add_node("finalize", finalize)

    builder.add_edge(START, "classify")
    builder.add_conditional_edges("classify", route_by_category, ["draft_reply", "escalate"])

    builder.add_conditional_edges("draft_reply", review_gate, ["revise", "finalize"])
    builder.add_conditional_edges("revise", review_gate, ["revise", "finalize"])

    builder.add_edge("escalate", END)
    builder.add_edge("finalize", END)

    return builder.compile(checkpointer=checkpointer, interrupt_before=interrupt_before)
```
- `StateGraph(TriageState)` binds the graph to the state schema.
- Five `add_node` calls register the nodes by name. The names are what routers must
  return.
- `add_edge(START, "classify")` sets the entry point.
- The first `add_conditional_edges` is the branch. The destination list
  `["draft_reply", "escalate"]` declares the two names the router can return.
- The next two `add_conditional_edges` are the review gate on both the first draft
  and each revision. `revise` appearing in its own destination list is what makes
  the self-loop legal.
- `escalate` and `finalize` both flow to `END`.
- `compile(...)` threads `checkpointer` and `interrupt_before` straight through.
  Parts D and E rely entirely on this one line. Everything they add is here, not in
  a new node.

---

## Verification ledger

- **Environment**: verified on Python 3.12.3 (runs unchanged on the cohort's Python 3.13), langgraph 1.2.9, langgraph-checkpoint 4.1.1,
  langchain-core 1.4.9, pytest 9.1.0.
- **Tests**: 19 provided, all passing against the solution; all 19 failing on the
  cold starter (import succeeds, bodies raise `NotImplementedError`).
- **Loop trace (Part C, how-to ticket)**: draft 46 words, revise to 30, revise to
  20, finalize. `attempts` ends at 2.
- **Branch (Part B)**: how-to ticket outcome `handled automatically`; refund ticket
  outcome `routed to a human agent`.
- **Memory (Part D)**: two turns on one thread yield four messages.
- **Interrupt (Part E)**: `get_state(config).next` is `('escalate',)` at the pause;
  `invoke(None, config)` resumes to outcome `routed to a human agent`.

---

## Symptom to cause, quick reference

| Symptom | Likely cause |
|---|---|
| `KeyError: 'draft'` (or another node name) at run time | Router returned a name not in the graph, or not in the destination list |
| `KeyError: 'attempts'` inside `review_gate` | `draft_reply` did not set `attempts: 0` |
| Memory test sees 2 messages, not 4 | `messages` missing the `add_messages` reducer, or `compile` not passed the checkpointer |
| `GraphRecursionError` | `review_gate` missing the `attempts < MAX_ATTEMPTS` guard, hit with a draft that cannot comply |
| Interrupt never pauses; `next` is empty | `interrupt_before` not threaded into `compile` |
| Loop never runs (`attempts` stays 0) | `revise` not a destination of `review_gate`, or the gate always returns `finalize` |
