# Instructor Demo Script: Running the Cordwell Triage Lab

**Module 11 · LangGraph Fundamentals · lab block 120 to 150 minutes**
**Verified on Python 3.12.3 against langgraph 1.2.9, langgraph-checkpoint 4.1.1, langchain-core 1.4.9, pytest 9.1.0. Runs unchanged on the cohort's Python 3.13.**

This is your facilitation script for the lab that follows the Module 11 lecture and
the two live demos. Students build the state machine they just watched you build in
Demo 1 and Demo 2, but larger and end to end. Everything here is deterministic and
offline. No API keys, no network calls, nothing to fail live.

---

## Before the room arrives (pre-flight, 5 min)

1. Distribute the **student** packet (not the solution). Confirm each machine can:
   ```bash
   pip install -r requirements.txt
   python -c "import langgraph; from importlib.metadata import version; print(version('langgraph'))"
   ```
   Expect `1.2.9`. Any langgraph 1.x is fine; the API this lab uses is stable across
   the 1.x line.
2. From the student packet root, run `pytest -q`. You should see **19 failed**. That
   is the correct starting point. If tests error at collection instead of failing,
   a machine has a broken install; fix it before you begin.
3. Have the **solution** packet open on your own machine for the walk-through at the
   end, and keep `Instructor_Walkthrough.md` beside you for line-by-line answers.

> ⚠️ **CURRENCY FLAG.** Confirm class machines resolve `import langgraph` before the
> block starts. A fresh install mid-lab is the only thing that can eat time here.

---

## Framing (I-do, 5 min)

Say something close to this:

> "In the demos I built two things live: a hello graph, and the same graph with a
> branch. You watched. Now you build a real one. It is a support triage agent for
> Cordwell Home and Hardware. It classifies a ticket, either drafts a reply or
> sends it to a human, trims an over-long draft in a loop, remembers the
> conversation, and pauses for approval before it escalates. Every primitive from
> the lecture, in code you write, not code you read."

Then show the target once. Run the finished app on your machine so they see where
they are headed:

```bash
python -m cordwell_triage.app
```

Point at the four banners as they scroll. Do not explain the code yet. This is the
"here is the destination" moment. Then close it and let them build.

---

## The build (you-do, with checkpoints)

Students work from `LAB.md`, which carries the expected output for every task. Your
job is to keep the room moving and to catch the common stumbles below. Circulate;
do not lecture over them.

Run these checkpoints out loud as the room reaches them.

### Part A checkpoint (~20 to 25 min in)
Command: `pytest -q -k "state or classify"` should show 3 passing.

Common stumbles:
- **`messages` field without the reducer.** It imports and A tests still pass, but
  it will bite them in Part D. If you see `messages: list` with no `Annotated`,
  flag it now rather than letting Part D surprise them.
- **`classify` returns the whole state or the wrong key.** The contract is a
  partial update: return only `{"category": ...}`.

### Part B checkpoint (~55 min in)
Command: `pytest -q -k "draft or route or escalate or finalize or refund"`.

Common stumbles:
- **Router returns a name that is not a node**, for example `"draft"` instead of
  `"draft_reply"`. Symptom at run time is `KeyError: 'draft'`. The return value must
  match a registered node name exactly.
- **`draft_reply` forgets `attempts: 0`.** Symptom later is `KeyError: 'attempts'`
  inside `review_gate`, because the gate reads a key nobody set. Good teaching
  moment: nodes must set what downstream nodes read.

### Part C checkpoint (~90 min in)
Command: `pytest -q -k "revise or review or loop or auto_ticket"`.

Common stumbles:
- **The gate has no attempt guard.** For this lab's inputs the draft still complies
  in two passes, so it may look fine. Point out the risk anyway: a single-sentence
  draft over the limit can never shrink, and without the `attempts < MAX_ATTEMPTS`
  guard the graph loops until LangGraph raises `GraphRecursionError`. The guard is
  the production lesson, not an optional nicety.
- **`revise` not added to its own destination list.** If they wire
  `add_conditional_edges("revise", review_gate, ["finalize"])`, the loop cannot
  happen. `revise` must be a legal destination of its own gate.

### Part D checkpoint (~110 min in)
Command: `pytest -q -k memory`.

Common stumble:
- **`compile()` does not pass `checkpointer` through.** Symptom is the memory test
  seeing 2 messages, not 4, or an error about missing a checkpointer. This is where
  a missing reducer from Part A also surfaces. Two different bugs, same failing
  test, so check both.

### Part E checkpoint (~125 min in)
Command: `pytest -q -k interrupt`.

Common stumble:
- **`interrupt_before` not threaded into `compile()`.** The graph runs straight
  through without pausing, so `get_state(config).next` is empty. Same fix location
  as Part D: the single compile line.

---

## The payoff run (we-do, 10 min)

When most of the room is green, run the app together on the projector and narrate
the three things worth seeing:

1. **The branch.** A how-to ticket is handled automatically; a refund ticket goes to
   a human. Same graph, two paths.
2. **The loop.** In Part C the stream prints the draft shrinking 46, then 30, then
   20 words, and `attempts` climbing. The cycle is visible.
3. **Memory and the pause.** In Part D the same thread accumulates four messages. In
   Part E the graph stops before `escalate`, reports the pending node, and finishes
   only after a resume.

Predict-first hook for the room before you run Part D: "Two separate calls on one
thread. How many messages are in the final state, and why." Answer is four, because
the `add_messages` reducer appends both turns.

---

## Fallback

There is no live model or network in this lab, so nothing can fail on a flaky call.
The only failure modes are a broken install or a stubborn bug on one machine. If a
student is blocked on their environment, pair them with a neighbor and keep the room
moving; do not stop the block to debug one laptop. The full expected app output is
in `LAB.md` if you need to show a result without a working machine in front of you.

---

## Timing summary

| Segment | Minutes |
|---|---|
| Pre-flight (before class) | 5 |
| Framing and target run | 5 to 10 |
| Part A | 20 to 25 |
| Part B | 30 to 35 |
| Part C | 30 to 35 |
| Part D | 15 to 20 |
| Part E | 15 to 20 |
| Payoff run and wrap | 10 |
| **Total** | **120 to 150** |

---

## Wrap and bridge

Close on the reframe from the lecture: they just built a state machine with an LLM's
job done here by deterministic rules. Swapping the keyword classifier in `classify`
for a model call, or the canned drafts for generated ones, changes those node bodies
and nothing else about the graph. That is the seam the rest of the program builds
on. The escalate pause and the checkpoint audit trail are the same governance
features they will see again in the monitoring and compliance material.
