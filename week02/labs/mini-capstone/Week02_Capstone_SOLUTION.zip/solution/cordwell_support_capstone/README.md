# Cordwell Support Assistant, Week 2 Mini-Capstone (Reference Solution)

This is the complete, working reference implementation of the Week 2 mini-capstone.
It builds an LLM fine-tuning dataset for the fictional Cordwell Home and Hardware
support assistant from three synthetic sources (SQLite, two mock REST APIs, and two
legacy files), then validates, profiles, and writes it as messages-format JSONL.

Withhold this from students until the debrief.

## Run it

```
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-capstone.txt
pip install -e .
python scripts/generate_sources.py
python scripts/run_pipeline.py
python -m pytest -q
```

`run_pipeline.py` spins up the mock API in-process and runs Extract through Load,
printing a stage summary and writing `data/output/` (train and validation JSONL,
the trained tokenizer, and a profile report). The full pytest suite (34 tests)
covers every stage plus an end-to-end pipeline acceptance test.

## Locked reference numbers (seed 42)

With the shipped generator defaults (50k tickets, 400 products, 2400 reviews):

- Extract: ~35.7k usable tickets (validated against the extract-boundary schema),
  ~1.5k legacy chats, ~2365 valid reviews (~35 dropped by the ReviewRecord contract),
  ~337 valid specs (~63 rejected: malformed JSON plus SpecRecord failures).
- Transform: ~1.8k categories imputed, ~1.0k excluded as unresolvable, ~19.5k
  post-scrub duplicates removed, balanced to 7500 examples (1500 per category).
- Load: 6750 train and 750 validation, token p95 ~172 and max ~197, every quality
  gate green.

Small run-to-run drift in these counts is expected if generator parameters change;
the gates, not the exact counts, are the contract.
