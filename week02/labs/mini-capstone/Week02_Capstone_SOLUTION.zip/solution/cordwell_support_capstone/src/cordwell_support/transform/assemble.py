"""Build the product knowledge context and assemble messages-format examples.

Two jobs:

  build_product_context   Join three sources -- SQL products, API specs, and API
                          reviews -- into one lookup: product_id -> a short factual
                          context string. This is where the API extraction finally
                          pays off; without it the reviews and specs would have been
                          pulled for nothing.

  assemble_examples       Turn each cleaned, scrubbed row into a chat example:
                          a system message, the customer's user message, and the
                          agent's assistant message. For product questions that
                          have a known product, the relevant context is grounded
                          into the system message so the assistant can answer from
                          facts rather than guessing.

The output format is the modern role-based `messages` array -- the schema current
chat fine-tuning endpoints accept. The legacy {prompt, completion} format is not
used anywhere; it is rejected by current chat fine-tuning APIs.
"""

from __future__ import annotations

import pandas as pd

from ..config import SYSTEM_PROMPT, Config


def build_product_context(products: pd.DataFrame, specs_by_id: dict[int, dict],
                          reviews: list[dict]) -> dict[int, str]:
    """Join products + specs + reviews into a product_id -> context-string map.

    Only products that have a valid spec get an entry (a product with no usable
    spec has nothing reliable to ground on). Average rating and review count come
    from aggregating the reviews list.
    """
    # Aggregate review ratings per product.
    if reviews:
        rev_df = pd.DataFrame(reviews)
        agg = rev_df.groupby("product_id")["rating"].agg(["mean", "count"])
    else:
        agg = pd.DataFrame(columns=["mean", "count"])

    name_by_id = dict(zip(products["product_id"], products["name"]))

    context: dict[int, str] = {}
    for pid, spec in specs_by_id.items():
        name = name_by_id.get(pid, spec.get("name", "this product"))
        material = spec.get("material", "unspecified")
        warranty = spec.get("warranty_months")
        warranty_txt = (f"{warranty}-month warranty" if warranty is not None
                        else "warranty details on request")
        parts = [f"Product: {name}.",
                 f"Material: {material}.",
                 f"Coverage: {warranty_txt}."]
        if pid in agg.index:
            avg = round(float(agg.loc[pid, "mean"]), 1)
            cnt = int(agg.loc[pid, "count"])
            parts.append(f"Customer rating: {avg} out of 5 from {cnt} reviews.")
        context[int(pid)] = " ".join(parts)
    return context


def _system_message(row, product_context: dict[int, str]) -> str:
    """Base system prompt, with product context grounded in for product questions."""
    base = SYSTEM_PROMPT
    pid = row["product_id"]
    if row["category"] == "product_question" and pd.notna(pid):
        ctx = product_context.get(int(pid))
        if ctx:
            return base + "\n\nRelevant product information:\n" + ctx
    return base


def assemble_examples(df: pd.DataFrame, product_context: dict[int, str],
                      cfg: Config) -> pd.DataFrame:
    """Build one messages-format example per row.

    Returns a frame with columns:
        messages   list of {role, content} dicts (system, user, assistant)
        category   the example's category (kept for profiling and the split)
        source     provenance (support_ticket / legacy_csv / legacy_json)
    """
    records = []
    for row in df.itertuples(index=False):
        r = row._asdict()
        messages = [
            {"role": "system", "content": _system_message(r, product_context)},
            {"role": "user", "content": r["user_text"]},
            {"role": "assistant", "content": r["assistant_text"]},
        ]
        records.append({
            "messages": messages,
            "category": r["category"],
            "source": r["source"],
        })
    out = pd.DataFrame.from_records(records)
    return out
