"""Schemas that define what valid data is, at every boundary it crosses.

Validation is not a single step at the end. It is a contract enforced wherever data
enters or changes shape. This module holds all of those contracts, using pandera for
tabular frames and pydantic for individual records.

Given as worked references:
  EXAMPLE_TABLE_SCHEMA   A pandera DataFrameSchema over the final example projection
                         (category, char counts, token count).
  ChatMessage/ChatExample  Pydantic models for one assembled chat example: role is a
                         fixed set, content is non-blank, and the conversation has the
                         right shape (leading system, trailing assistant, a user turn).

Authored in this lab, one per boundary:
  tickets_schema()       A pandera DataFrameSchema for the raw tickets frame straight
                         out of SQL. Asserts the extraction contract held before any
                         transform runs.
  SpecRecord             A pydantic model for one product spec from the API. A spec
                         that parses as JSON but violates this contract is not usable.
  ReviewRecord           A pydantic model for one product review from the API. Catches
                         out-of-range ratings and missing fields at ingestion.

Note the imports: `import pandera.pandas as pa`. The bare `import pandera as pa`
raises a FutureWarning on current pandera; the .pandas path is the supported one.
And pydantic v2 idioms throughout: @field_validator + @classmethod, model_dump().
"""

from __future__ import annotations

import pandera.pandas as pa
from pandera.pandas import Check, Column, DataFrameSchema
from pydantic import BaseModel, field_validator
from typing import Literal

from ..config import (CATEGORIES, MAX_EXAMPLE_TOKENS, MAX_REPLY_CHARS,
                      MIN_REPLY_CHARS, USABLE_RESOLUTIONS)

# ---- Tabular contract (pandera) ------------------------------------------
EXAMPLE_TABLE_SCHEMA = DataFrameSchema(
    {
        "category": Column(str, Check.isin(list(CATEGORIES))),
        "source": Column(str),
        "user_chars": Column(int, Check.ge(1)),
        "assistant_chars": Column(int, Check.in_range(MIN_REPLY_CHARS, MAX_REPLY_CHARS)),
        "n_tokens": Column(int, Check.in_range(1, MAX_EXAMPLE_TOKENS)),
    },
    strict=True,
    coerce=True,
)


# ---- Row contract (pydantic v2) ------------------------------------------
class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str

    @field_validator("content")
    @classmethod
    def content_not_blank(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("message content must not be blank")
        return v


class ChatExample(BaseModel):
    messages: list[ChatMessage]

    @field_validator("messages")
    @classmethod
    def valid_conversation_shape(cls, msgs: list[ChatMessage]) -> list[ChatMessage]:
        if len(msgs) < 3:
            raise ValueError("expected at least system, user, assistant")
        roles = [m.role for m in msgs]
        if roles[0] != "system":
            raise ValueError("first message must be the system message")
        if roles[-1] != "assistant":
            raise ValueError("conversation must end with an assistant message")
        if "user" not in roles:
            raise ValueError("conversation must contain a user message")
        return msgs


# ---- Extract-boundary contract (pandera), authored in this lab -------------
def tickets_schema() -> DataFrameSchema:
    """A pandera schema for the raw tickets frame straight out of SQL.

    This is a boundary check: it asserts that the SQL extraction contract held
    before any transform runs. It is built as a function (not a module constant)
    so the schema is constructed on demand.

    The contract:
      - ticket_id is an integer.
      - customer_message and agent_reply are non-null strings (the SQL pre-filter
        guarantees a non-empty reply, so this is a real invariant, not a hope).
      - resolution is one of USABLE_RESOLUTIONS (again, the SQL WHERE guarantees it;
        the schema proves the guarantee held).
      - category is a nullable string. It may be missing here; imputation deals with
        that later. We deliberately do NOT constrain its values at this boundary,
        because junk and missing categories are expected in raw data.
    """
    return DataFrameSchema(
        {
            "ticket_id": Column(int),
            "customer_message": Column(str, nullable=False),
            "agent_reply": Column(str, nullable=False,
                                  checks=Check.str_length(min_value=1)),
            "resolution": Column(str, Check.isin(list(USABLE_RESOLUTIONS))),
            "category": Column(str, nullable=True, required=True),
        },
        strict=False,   # extra columns (product_id, channel, ...) are allowed here
        coerce=True,
    )


# ---- Source-record contracts (pydantic v2), authored in this lab -----------
class SpecRecord(BaseModel):
    """One product spec from the API. Validated in fetch_spec at ingestion.

    A spec that parses as JSON but fails this contract (for example a blank or
    missing material) is not usable and is treated as a failed fetch.
    """
    product_id: int
    name: str
    material: str
    warranty_months: int | None = None
    weight_lbs: float | None = None

    @field_validator("material")
    @classmethod
    def material_not_blank(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("material must not be blank")
        return v


class ReviewRecord(BaseModel):
    """One product review from the API. Validated at ingestion.

    Catches ratings outside the 1 to 5 range and missing fields. Valid JSON is not
    the same as valid data, and this is where that gap is closed for reviews.
    """
    review_id: int
    product_id: int
    rating: int
    title: str
    body: str
    created_at: str

    @field_validator("rating")
    @classmethod
    def rating_in_range(cls, v: int) -> int:
        if not 1 <= v <= 5:
            raise ValueError("rating must be between 1 and 5 inclusive")
        return v
