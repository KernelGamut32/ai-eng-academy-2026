"""Extract support tickets and product rows from the SQL source (Module 04).

Two ideas from Week 2 live here:

  1. Chunked reads. The tickets table is far larger than we want in memory at
     once. `pd.read_sql_query(..., chunksize=N)` streams it in blocks so the
     machine never holds all of it. In production against 6M rows this is the
     difference between a run and an out-of-memory crash.

  2. Parameterized queries. The set of "usable" resolutions comes from config,
     not from the code. We bind it as a parameter. Never build SQL by pasting
     values into an f-string: that is how you get SQL injection and quoting bugs.
"""

from __future__ import annotations

import pandas as pd
from sqlalchemy import Engine, bindparam, create_engine, text

from ..config import Config, USABLE_RESOLUTIONS


def make_engine(cfg: Config) -> Engine:
    """Create a SQLAlchemy engine for the local SQLite source.

    SQLite here stands in for the production PostgreSQL. The pandas + SQLAlchemy
    code below is identical against either; only the connection URL changes.
    """
    return create_engine(f"sqlite:///{cfg.db_path}")


# The pre-filter runs in the database, before rows ever reach pandas. It cuts the
# table down to tickets that are even candidates for training: a real resolution
# and a non-empty reply. The :res parameter expands to the usable-resolution list.
_TICKETS_SQL = text(
    """
    SELECT ticket_id, customer_message, agent_reply, category, resolution,
           product_id, order_id, channel, created_at
    FROM support_tickets
    WHERE resolution IN :res
      AND agent_reply IS NOT NULL
      AND TRIM(agent_reply) <> ''
    """
).bindparams(bindparam("res", expanding=True))


def read_tickets_chunked(cfg: Config, engine: Engine | None = None) -> pd.DataFrame:
    """Stream candidate support tickets from SQL in chunks and return one frame.

    The WHERE clause is a coarse, safe pre-filter (usable resolution, non-empty
    reply) so we never pull the whole table into memory. Finer selection (length,
    category, dedup, balance) happens later in the transform stage on the far
    smaller candidate set.

    Returns a single DataFrame assembled from the streamed chunks.
    """
    engine = engine or make_engine(cfg)
    params = {"res": list(USABLE_RESOLUTIONS)}
    frames: list[pd.DataFrame] = []
    for chunk in pd.read_sql_query(_TICKETS_SQL, engine, params=params,
                                   chunksize=cfg.sql_chunksize):
        frames.append(chunk)
    if not frames:
        # Preserve the column contract even on an empty result.
        return pd.read_sql_query(_TICKETS_SQL, engine, params=params).iloc[0:0]
    return pd.concat(frames, ignore_index=True)


def read_products(cfg: Config, engine: Engine | None = None) -> pd.DataFrame:
    """Read the (small) products table in full. Used to join API context later."""
    engine = engine or make_engine(cfg)
    return pd.read_sql_query(text("SELECT product_id, name, category FROM products"),
                             engine)
