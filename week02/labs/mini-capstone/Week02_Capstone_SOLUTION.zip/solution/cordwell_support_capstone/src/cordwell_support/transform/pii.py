"""Redact synthetic PII from free text before it can enter the training file.

Support free text routinely contains names, addresses, order numbers, emails, and
phone numbers. If that rides along into a fine-tuning file, the model can memorize
and later regurgitate it. Scrubbing here, in the transform stage, is the
responsible-AI control for this pipeline.

Every pattern is a RAW string. In Python 3.12+ an unescaped backslash sequence
such as \\d inside a normal string raises a SyntaxWarning; raw strings are the
correct, warning-free way to write regexes.

This is pattern-based redaction sufficient for structured PII and the explicit
"my name is X Y" construction. Production would add a trained NER model for
free-form names; that is called out as a limitation, not hidden.
"""

from __future__ import annotations

import re

import pandas as pd

# Order matters: email is matched before phone so an address or phone fragment
# inside an email never gets partially rewritten first.
_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"), "[EMAIL]"),
    (re.compile(r"\bCW-\d{8}\b"), "[ORDER_ID]"),
    (re.compile(r"\(\d{3}\)\s*\d{3}-\d{4}"), "[PHONE]"),
    (re.compile(r"\d+\s+\w+\s+St,\s+\w+,\s+NC\s+\d{5}"), "[ADDRESS]"),
    (re.compile(r"\bMy name is\s+[A-Z][a-z]+\s+[A-Z][a-z]+"), "My name is [NAME]"),
]


def scrub_pii(text: str) -> str:
    """Redact known PII patterns from a single string.

    Returns the text with emails, order numbers, phones, addresses, and explicit
    self-identified names replaced by typed placeholders.
    """
    if text is None:
        return text
    for pattern, replacement in _PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def scrub_series(series: pd.Series) -> pd.Series:
    """Apply scrub_pii across a pandas Series of strings, preserving the index."""
    return series.map(lambda v: scrub_pii(v) if isinstance(v, str) else v)


def contains_pii(text: str) -> bool:
    """True if any PII pattern still matches. Used by tests and profiling."""
    if not isinstance(text, str):
        return False
    # The name pattern rewrites to a literal that no longer matches, so only the
    # structured patterns are meaningful as a residual-PII check.
    for pattern, _ in _PATTERNS[:4]:
        if pattern.search(text):
            return True
    return False
