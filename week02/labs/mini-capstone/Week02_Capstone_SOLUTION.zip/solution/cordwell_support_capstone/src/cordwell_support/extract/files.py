"""Extract legacy chat transcripts from messy CSV and JSON exports.

The retired live-chat system left two exports behind, and they are exactly as
inconsistent as real dumps: the CSV is latin-1 encoded (a naive utf-8 read
raises), has mixed-case headers, whitespace-only rows, and about 8% duplicated
rows; the JSON export uses entirely different key names for the same fields.

This module normalizes both into one tidy frame with a stable column contract:
    source, session_id, user_text, agent_text, topic
so the rest of the pipeline never has to care where a row came from.
"""

from __future__ import annotations

import json
from io import StringIO

import pandas as pd

from ..config import Config

# Canonical column names every downstream stage can rely on.
CANONICAL_COLUMNS = ["source", "session_id", "user_text", "agent_text", "topic"]

# Map the CSV's mixed-case headers to canonical names.
_CSV_RENAME = {
    "Session_ID": "session_id",
    "User_Text": "user_text",
    "Agent_Text": "agent_text",
    "Topic": "topic",
    "Ended_At": "ended_at",
}

# Map the JSON export's alien keys to canonical names.
_JSON_RENAME = {
    "sessionId": "session_id",
    "customer": "user_text",
    "rep": "agent_text",
    "label": "topic",
}


def _read_text_resilient(path) -> str:
    """Read a text file, falling back from utf-8 to latin-1 on decode failure.

    latin-1 maps every byte to a code point, so it never raises. It is the
    pragmatic last resort for an export of unknown provenance.
    """
    raw = path.read_bytes()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1")


def _load_csv(cfg: Config) -> pd.DataFrame:
    text = _read_text_resilient(cfg.legacy_csv_path)
    df = pd.read_csv(StringIO(text), dtype="str")
    df = df.rename(columns=_CSV_RENAME)
    df["source"] = "legacy_csv"
    for col in ("user_text", "agent_text", "topic"):
        if col not in df.columns:
            df[col] = pd.NA
    return df[CANONICAL_COLUMNS]


def _load_json(cfg: Config) -> pd.DataFrame:
    records = json.loads(cfg.legacy_json_path.read_text())
    df = pd.DataFrame.from_records(records).rename(columns=_JSON_RENAME)
    df["source"] = "legacy_json"
    # A missing "rep" key means the column is absent for some rows; ensure it exists.
    for col in ("user_text", "agent_text", "topic"):
        if col not in df.columns:
            df[col] = pd.NA
    return df[CANONICAL_COLUMNS]


def load_legacy_chats(cfg: Config) -> pd.DataFrame:
    """Load, unify, and lightly clean both legacy exports.

    Cleaning here is only what is needed to make the two sources one honest frame:
    resolve encoding, unify columns, drop exact-duplicate rows, and drop rows whose
    user or agent text is blank or whitespace-only (they carry no training signal).
    Heavier selection is the transform stage's job.

    Returns a frame with columns: source, session_id, user_text, agent_text, topic.
    """
    csv_df = _load_csv(cfg)
    json_df = _load_json(cfg)
    combined = pd.concat([csv_df, json_df], ignore_index=True)

    # Treat whitespace-only text as missing before we filter on it.
    for col in ("user_text", "agent_text"):
        combined[col] = combined[col].str.strip()
        blank = combined[col].isna() | (combined[col] == "")
        combined.loc[blank, col] = pd.NA

    before = len(combined)
    combined = combined.drop_duplicates(
        subset=["user_text", "agent_text"], keep="first")
    combined = combined.loc[combined["user_text"].notna()
                            & combined["agent_text"].notna()].copy()
    combined = combined.reset_index(drop=True)
    combined.attrs["rows_dropped"] = before - len(combined)
    return combined
