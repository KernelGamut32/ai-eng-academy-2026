"""Compose the whole pipeline: Extract, Transform, Validate, Profile, Load.

This is the single function that runs identically in tests, in the CLI, and in
production. No stage logic lives in scripts or notebooks -- they only call in here.
Reading top to bottom is the pipeline: each block is one stage from Module 01.
"""

from __future__ import annotations

import json

import requests

from .config import Config
from .extract import api, files, sql
from .transform import assemble, pii, select
from .quality import profile as profile_mod
from .quality import tokens as tok
from .quality import validate as validate_mod
from .load import writer


def run_pipeline(cfg: Config, session: requests.Session | None = None) -> dict:
    """Run the end-to-end pipeline and return a summary dict.

    Requires the mock API to be reachable at cfg.api_base_url. Writes the train and
    validation JSONL shards, the trained tokenizer, and the profile report into
    cfg.output_dir. Raises if the quality gate fails.
    """
    summary: dict = {"stages": {}}

    # ---- EXTRACT ---------------------------------------------------------
    engine = sql.make_engine(cfg)
    tickets = sql.read_tickets_chunked(cfg, engine)
    products = sql.read_products(cfg, engine)
    legacy = files.load_legacy_chats(cfg)

    # Boundary check: prove the SQL extraction contract held before transforming.
    tickets_check = validate_mod.validate_tickets(tickets)

    session = session or api.build_session(cfg)
    reviews = api.fetch_reviews(cfg, session)
    # Boundary check: drop review records that parse as JSON but are not valid data
    # (out-of-range rating, missing field) before they reach the context join.
    reviews, reviews_dropped = validate_mod.validate_reviews(reviews)
    specs, spec_failures = api.fetch_specs(cfg, products["product_id"].tolist(),
                                           session)
    summary["stages"]["extract"] = {
        "tickets": len(tickets), "products": len(products),
        "legacy_chats": len(legacy),
        "reviews_ok": len(reviews), "reviews_dropped": reviews_dropped,
        "specs_ok": len(specs), "specs_failed": len(spec_failures),
        "tickets_boundary_ok": tickets_check["table_ok"],
    }

    # ---- TRANSFORM -------------------------------------------------------
    candidates = select.normalize_sources(tickets, legacy)

    # Scrub PII first, so downstream dedup operates on the final redacted text.
    # Two rows that differ only in a customer's order number are the same training
    # example once redacted, and must be caught as duplicates.
    candidates = candidates.copy()
    candidates["user_text"] = pii.scrub_series(candidates["user_text"])
    candidates["assistant_text"] = pii.scrub_series(candidates["assistant_text"])

    candidates, impute_stats = select.impute_category(candidates)
    kept, select_log = select.select_candidates(candidates, cfg)
    balanced = select.balance_categories(kept, cfg)

    product_context = assemble.build_product_context(products, specs, reviews)
    examples = assemble.assemble_examples(balanced, product_context, cfg)
    summary["stages"]["transform"] = {
        "impute": impute_stats,
        "select_log": select_log,
        "after_balance": len(balanced),
        "assembled": len(examples),
        "grounded_products": len(product_context),
    }

    # ---- TOKENIZE + token gate ------------------------------------------
    texts = examples["messages"].map(tok.example_text).tolist()
    tokenizer = tok.train_tokenizer(texts, cfg)
    examples = tok.add_token_lengths(examples, tokenizer)
    examples, dropped_tokens = tok.gate_by_tokens(examples, cfg)
    cfg.output_dir.mkdir(parents=True, exist_ok=True)
    tokenizer.save(str(cfg.tokenizer_path))
    summary["stages"]["tokenize"] = {
        "vocab_size": tokenizer.get_vocab_size(),
        "dropped_over_budget": dropped_tokens,
        "examples_remaining": len(examples),
    }

    # ---- VALIDATE --------------------------------------------------------
    summary["stages"]["validate"] = validate_mod.validate_examples(examples)

    # ---- PROFILE (hard gate) --------------------------------------------
    report = profile_mod.profile_dataset(examples, cfg)
    cfg.profile_path.write_text(json.dumps(report, indent=2))
    summary["stages"]["profile"] = report
    if not report["passed"]:
        failed = [k for k, v in report["checks"].items() if not v["ok"]]
        raise RuntimeError(f"quality gate failed on: {', '.join(failed)}")

    # ---- LOAD ------------------------------------------------------------
    summary["stages"]["load"] = writer.split_and_write(examples, cfg)

    engine.dispose()
    summary["ok"] = True
    return summary
