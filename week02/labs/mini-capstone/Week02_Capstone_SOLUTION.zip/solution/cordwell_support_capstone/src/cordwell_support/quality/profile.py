"""Profile the finished dataset and check it against the Module 01 quality gates.

Profiling is the last thing that stands between a plausible-looking dataset and a
trusted one. It computes the numbers that actually matter for a support assistant
-- how many examples, how balanced, how deduplicated, how long -- and compares each
to a threshold. The gate is hard: if any threshold fails, `passed` is False and the
pipeline refuses to load.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..config import (Config, MAX_CATEGORY_SHARE, MAX_DUPLICATE_RATE,
                      MAX_EXAMPLE_TOKENS, MIN_COMPLETENESS, MIN_EXAMPLES)
from .tokens import example_text
from ..transform.pii import contains_pii


def profile_dataset(examples: pd.DataFrame, cfg: Config) -> dict:
    """Compute quality metrics and evaluate them against the gates.

    Returns a JSON-serializable report dict with per-metric values, the thresholds,
    a per-check pass/fail, and an overall `passed` boolean.
    """
    n = len(examples)

    # Category balance
    cat_counts = examples["category"].value_counts()
    cat_shares = (cat_counts / n).round(4).to_dict() if n else {}
    max_share = float(cat_counts.max() / n) if n else 0.0

    # Duplicate rate on the (user, assistant) content pair
    pairs = examples["messages"].map(lambda m: (m[1]["content"], m[-1]["content"]))
    dup_rate = float(pairs.duplicated().mean()) if n else 0.0

    # Completeness: fraction of examples whose user and assistant content are
    # non-empty and whose category is a real value. After cleaning this should be
    # 1.0; a dip means something upstream let a blank through.
    def complete(m):
        return bool(m[1]["content"].strip()) and bool(m[-1]["content"].strip())
    completeness = float(examples["messages"].map(complete).mean()) if n else 0.0

    # Token-length distribution
    token_lengths = examples["n_tokens"].to_numpy() if n else np.array([0])
    tok = {
        "min": int(token_lengths.min()),
        "median": int(np.median(token_lengths)),
        "p95": int(np.percentile(token_lengths, 95)),
        "max": int(token_lengths.max()),
    }

    # Residual PII: should be zero after scrubbing.
    residual_pii = int(examples["messages"].map(
        lambda m: any(contains_pii(x["content"]) for x in m)).sum())

    checks = {
        "min_examples": {"value": n, "threshold": MIN_EXAMPLES,
                         "ok": n >= MIN_EXAMPLES},
        "max_category_share": {"value": round(max_share, 4),
                               "threshold": MAX_CATEGORY_SHARE,
                               "ok": max_share <= MAX_CATEGORY_SHARE},
        "max_duplicate_rate": {"value": round(dup_rate, 4),
                               "threshold": MAX_DUPLICATE_RATE,
                               "ok": dup_rate <= MAX_DUPLICATE_RATE},
        "min_completeness": {"value": round(completeness, 4),
                             "threshold": MIN_COMPLETENESS,
                             "ok": completeness >= MIN_COMPLETENESS},
        "max_tokens": {"value": tok["max"], "threshold": MAX_EXAMPLE_TOKENS,
                       "ok": tok["max"] <= MAX_EXAMPLE_TOKENS},
        "no_residual_pii": {"value": residual_pii, "threshold": 0,
                            "ok": residual_pii == 0},
    }
    passed = all(c["ok"] for c in checks.values())

    return {
        "n_examples": n,
        "category_shares": cat_shares,
        "source_mix": examples["source"].value_counts().to_dict(),
        "duplicate_rate": round(dup_rate, 4),
        "completeness": round(completeness, 4),
        "token_lengths": tok,
        "residual_pii_examples": residual_pii,
        "checks": checks,
        "passed": passed,
    }
