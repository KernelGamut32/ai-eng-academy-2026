"""Turn millions of messy rows into a smaller, well-chosen training set (Module 05).

This is the pandas heart of the pipeline. Three moves:

  normalize_sources   Fold SQL tickets and legacy chats into one candidate frame
                      with a single column contract.
  impute_category     A deliberate policy for missing categories: impute from
                      keywords when confident, otherwise exclude. Never let a
                      missing value silently vanish from the counts.
  select_candidates   Chained boolean masks, each logged with how many rows it
                      removes, so the drop is auditable rather than mysterious.
  balance_categories  Cap the dominant category so the assistant is not trained
                      almost entirely on order-status replies.

Everything uses .loc for combined row+column selection and pd.Series(True,
index=...) for masks, so nothing trips the pandas 3.0 index-alignment or
chained-assignment traps.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..config import CATEGORIES, Config, MAX_REPLY_CHARS, MIN_REPLY_CHARS

CANDIDATE_COLUMNS = ["source", "user_text", "assistant_text", "category", "product_id"]

# Ordered keyword rules for imputing a missing category. First match wins, so the
# order encodes precedence (an "order status" phrase beats a stray "ship").
_IMPUTE_RULES: list[tuple[str, tuple[str, ...]]] = [
    ("order_status", ("where is my order", "order status", "tracking", "track my",
                      "status update", "still have not seen it ship")),
    ("returns", ("return", "send it back", "exchange", "arrived damaged")),
    ("shipping", ("shipping", "deliver", "delivery", "how long does it take",
                  "ship it")),
    ("billing", ("charged", "charge", "refund", "invoice", "billed", "my card")),
    ("product_question", ("warranty", "compatible", "difference between",
                          "come with", "assembly", "in stock", "colors")),
]


def normalize_sources(tickets: pd.DataFrame, legacy: pd.DataFrame) -> pd.DataFrame:
    """Fold the two upstream sources into one candidate frame.

    SQL tickets map customer_message/agent_reply to user/assistant text and keep
    their category and product_id. Legacy chats map user_text/agent_text and use
    their topic as the (often missing) category; they carry no product_id.
    """
    t = pd.DataFrame({
        "source": "support_ticket",
        "user_text": tickets["customer_message"],
        "assistant_text": tickets["agent_reply"],
        "category": tickets["category"],
        "product_id": tickets["product_id"],
    })
    lg = pd.DataFrame({
        "source": legacy["source"],
        "user_text": legacy["user_text"],
        "assistant_text": legacy["agent_text"],
        "category": legacy["topic"],
        "product_id": pd.NA,
    })
    combined = pd.concat([t, lg], ignore_index=True)
    # Treat empty strings and known junk topics as missing categories.
    cat = combined["category"].astype("string")
    junk = cat.isna() | (cat.str.strip() == "") | (cat.str.strip() == "misc")
    combined.loc[junk, "category"] = pd.NA
    return combined[CANDIDATE_COLUMNS]


def _impute_one(text: str) -> str | None:
    low = text.lower()
    for category, keywords in _IMPUTE_RULES:
        if any(k in low for k in keywords):
            return category
    return None


def impute_category(candidates: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Fill missing categories from keyword rules; drop the truly ambiguous ones.

    Policy: where a confident keyword rule fires, impute the category. Where no
    rule fires and the category is missing, exclude the row (we will not guess a
    training label). Rows that already have a valid category are untouched.

    Returns (frame, stats) where stats records imputed and excluded counts so the
    loss is visible, not silent.
    """
    df = candidates.copy()
    missing = df["category"].isna()
    n_missing = int(missing.sum())

    # Impute only the missing rows, from their user_text.
    imputed_vals = df.loc[missing, "user_text"].map(_impute_one)
    df.loc[missing, "category"] = imputed_vals.to_numpy()

    # Any still-missing category could not be imputed -> exclude.
    still_missing = df["category"].isna()
    n_excluded = int(still_missing.sum())
    df = df.loc[~still_missing].copy().reset_index(drop=True)

    stats = {
        "missing_before": n_missing,
        "imputed": n_missing - n_excluded,
        "excluded_unresolvable": n_excluded,
    }
    return df, stats


def select_candidates(candidates: pd.DataFrame, cfg: Config
                      ) -> tuple[pd.DataFrame, list[dict]]:
    """Apply quality filters as chained masks, logging each filter's drop count.

    A "good" training example is: a real in-taxonomy category, a user message and
    an assistant reply that are both present and of sensible length, and not a
    duplicate of another example. Each condition is applied in turn and the number
    of rows it removes is recorded, so a surprising final count is traceable to the
    exact filter responsible.

    Returns (kept_frame, log) where log is a list of {filter, removed, remaining}.
    """
    df = candidates.copy()
    log: list[dict] = []

    def apply(mask: pd.Series, name: str):
        nonlocal df
        before = len(df)
        # Align the mask to df's index explicitly -- never assume positional match.
        df = df.loc[mask].copy()
        removed = before - len(df)
        log.append({"filter": name, "removed": removed, "remaining": len(df)})

    user = df["user_text"].astype("string").str.strip()
    asst = df["assistant_text"].astype("string").str.strip()
    reply_len = asst.str.len().fillna(0)

    apply(df["category"].isin(CATEGORIES), "category_in_taxonomy")
    apply(user.notna() & (user != ""), "user_text_present")
    apply(asst.notna() & (asst != ""), "assistant_text_present")

    # Recompute length on the surviving rows before the length filter.
    reply_len = df["assistant_text"].astype("string").str.strip().str.len().fillna(0)
    length_ok = (reply_len >= MIN_REPLY_CHARS) & (reply_len <= MAX_REPLY_CHARS)
    apply(length_ok, f"reply_len_{MIN_REPLY_CHARS}_to_{MAX_REPLY_CHARS}")

    before = len(df)
    df = df.drop_duplicates(subset=["user_text", "assistant_text"], keep="first")
    log.append({"filter": "dedup_user_assistant_pair",
                "removed": before - len(df), "remaining": len(df)})

    return df.reset_index(drop=True), log


def balance_categories(df: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    """Cap each category at cfg.target_per_category, sampling with the run seed.

    Categories above the cap are downsampled; categories below it keep every row.
    This deliberately discards clean, usable order-status examples to keep the
    assistant from over-learning that one category -- a real trade-off, made on
    purpose (see the stretch discussion on discarding good data).
    """
    rng = np.random.default_rng(cfg.seed)
    pieces = []
    for category, group in df.groupby("category", observed=True):
        if len(group) > cfg.target_per_category:
            take = rng.choice(group.index.to_numpy(),
                              size=cfg.target_per_category, replace=False)
            pieces.append(group.loc[take])
        else:
            pieces.append(group)
    balanced = pd.concat(pieces).sort_index().reset_index(drop=True)
    return balanced
