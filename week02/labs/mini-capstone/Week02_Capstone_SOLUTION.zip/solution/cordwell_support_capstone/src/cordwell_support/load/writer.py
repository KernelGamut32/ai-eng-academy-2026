"""Split, write, and verify the final LLM-ready JSONL shards (Module 01 Load).

The load stage produces the artifact next week's fine-tuning workflow consumes:
two JSONL files (train and validation), one example per line, in the messages
format. It then reloads them with Hugging Face `datasets` to prove the files are
actually consumable -- a write that no one reads back is a write you cannot trust.

Reproducibility details that matter:
  * The split is stratified by category and seeded, so train/val proportions are
    stable and both splits see every category.
  * JSONL is written with orjson for speed and correct handling of the nested
    structure. Each line is one compact JSON object followed by a newline.
  * datasets offline env vars are set BEFORE importing datasets, so verification
    never reaches for the network.
"""

from __future__ import annotations

import os

import numpy as np
import orjson
import pandas as pd

from ..config import Config


def stratified_split(examples: pd.DataFrame, cfg: Config
                     ) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Split into (train, val), stratified by category, using the split seed.

    Within each category a fixed fraction goes to validation, so both splits
    contain every category in the same proportion as the whole.
    """
    rng = np.random.default_rng(cfg.split_seed)
    val_idx: list = []
    for _, group in examples.groupby("category", observed=True):
        n_val = max(1, int(round(len(group) * cfg.val_fraction)))
        picked = rng.choice(group.index.to_numpy(), size=n_val, replace=False)
        val_idx.extend(picked.tolist())
    val_mask = examples.index.isin(val_idx)
    val = examples.loc[val_mask].reset_index(drop=True)
    train = examples.loc[~val_mask].reset_index(drop=True)
    return train, val


def write_jsonl(examples: pd.DataFrame, path) -> int:
    """Write examples to JSONL (one {"messages": [...]} object per line).

    Returns the number of lines written. Only the messages field is written; the
    profiling columns (category, source, n_tokens) stay out of the training file.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        for messages in examples["messages"]:
            f.write(orjson.dumps({"messages": messages}))
            f.write(b"\n")
    return len(examples)


def verify_roundtrip(train_path, val_path) -> dict:
    """Reload the written shards with Hugging Face datasets to confirm they parse.

    Offline env vars are set before the import so this never touches the network.
    Returns row counts and the detected column names.
    """
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
    from datasets import load_dataset  # imported here, after the env is set

    ds = load_dataset("json", data_files={
        "train": str(train_path), "validation": str(val_path)})
    return {
        "train_rows": ds["train"].num_rows,
        "val_rows": ds["validation"].num_rows,
        "columns": ds["train"].column_names,
    }


def split_and_write(examples: pd.DataFrame, cfg: Config) -> dict:
    """Split, write both shards, and verify the round-trip. Return a summary."""
    train, val = stratified_split(examples, cfg)
    n_train = write_jsonl(train, cfg.train_path)
    n_val = write_jsonl(val, cfg.val_path)
    verified = verify_roundtrip(cfg.train_path, cfg.val_path)
    return {
        "train_written": n_train,
        "val_written": n_val,
        "roundtrip": verified,
        "train_path": str(cfg.train_path),
        "val_path": str(cfg.val_path),
    }
