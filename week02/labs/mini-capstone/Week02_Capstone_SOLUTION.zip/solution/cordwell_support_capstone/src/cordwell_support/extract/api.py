"""Extract review and spec data from the (mock) REST APIs (Module 03).

The two APIs fail in different, realistic ways, and the client handles each:

  Reviews API  -- paginated and rate-limited. We mount a urllib3 Retry policy on
                  the session so transient 429 and 5xx responses are retried with
                  exponential backoff, and Retry-After is honored automatically.
                  The pagination loop itself just walks pages until has_more is
                  False.

  Spec API     -- occasionally returns malformed or partial JSON. A naive
                  response.json() would raise and kill the whole run, so we parse
                  defensively: one bad product is skipped and recorded, never
                  fatal.

Why Retry on the adapter instead of a hand-rolled sleep loop? Because it is the
convention real engineers ship. With backoff_factor=0.5 the wait schedule is
0, 1, 2, 4, 8 seconds (the first retry waits 0). respect_retry_after_header (on
by default) means a server that says "Retry-After: 1" is obeyed exactly.
"""

from __future__ import annotations

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from pydantic import ValidationError

from ..config import Config
from ..quality.schema import SpecRecord

# Status codes worth retrying: rate limiting and the transient 5xx family.
_RETRYABLE = (429, 500, 502, 503, 504)


def build_session(cfg: Config) -> requests.Session:
    """A requests Session whose adapter retries transient failures with backoff."""
    retry = Retry(
        total=cfg.api_max_retries,
        backoff_factor=cfg.api_backoff_factor,
        status_forcelist=_RETRYABLE,
        allowed_methods=frozenset(["GET"]),
        respect_retry_after_header=True,
        raise_on_status=False,
    )
    session = requests.Session()
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update({"Authorization": f"Bearer {cfg.api_token}"})
    return session


def fetch_reviews(cfg: Config, session: requests.Session | None = None) -> list[dict]:
    """Page through the reviews API and return every review as a flat list.

    Stop condition: the payload's has_more flag goes False. Transient 429/5xx
    responses on any page are absorbed by the session's Retry policy, so this
    loop only sees the eventual 200s.
    """
    session = session or build_session(cfg)
    url = f"{cfg.api_base_url}/reviews"
    reviews: list[dict] = []
    page = 1
    while True:
        resp = session.get(url, params={"page": page, "per_page": cfg.api_page_size},
                           timeout=cfg.api_timeout_seconds)
        resp.raise_for_status()
        payload = resp.json()
        # Defensive: the contract says "reviews" is a list. Trust but verify.
        batch = payload.get("reviews", [])
        if not isinstance(batch, list):
            raise ValueError(f"reviews page {page} returned a non-list payload")
        reviews.extend(batch)
        if not payload.get("has_more"):
            break
        page += 1
    return reviews


def fetch_spec(session: requests.Session, base_url: str, product_id: int,
               timeout: float) -> dict | None:
    """Fetch and defensively parse one product spec. Return None on any problem.

    "Any problem" covers: a non-200 status, a body that is not valid JSON, and a
    body that parses but violates the spec contract (validated with the Pydantic
    SpecRecord model). None of these should ever raise out of this function. One bad
    product must not sink the run.

    Note the two layers of defense: a try/except around json() catches malformed
    bytes, and SpecRecord.model_validate catches well-formed JSON that is not valid
    data (a blank or missing material). Valid JSON is not the same as valid data.
    """
    try:
        resp = session.get(f"{base_url}/specs/{product_id}", timeout=timeout)
    except requests.RequestException:
        return None
    if resp.status_code != 200:
        return None
    try:
        spec = resp.json()
    except (ValueError, requests.JSONDecodeError):
        return None
    if not isinstance(spec, dict):
        return None
    try:
        model = SpecRecord.model_validate(spec)
    except ValidationError:
        return None
    return model.model_dump()


def fetch_specs(cfg: Config, product_ids, session: requests.Session | None = None
                ) -> tuple[dict[int, dict], list[int]]:
    """Fetch specs for many products.

    Returns (specs_by_id, failed_ids). Failures are collected, not raised, so the
    caller can profile the loss rate and decide whether it is acceptable.
    """
    session = session or build_session(cfg)
    specs: dict[int, dict] = {}
    failed: list[int] = []
    for pid in product_ids:
        spec = fetch_spec(session, cfg.api_base_url, int(pid),
                          cfg.api_timeout_seconds)
        if spec is None:
            failed.append(int(pid))
        else:
            specs[int(pid)] = spec
    return specs, failed
