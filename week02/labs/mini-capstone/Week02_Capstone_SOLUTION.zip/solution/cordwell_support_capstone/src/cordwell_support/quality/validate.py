"""Validate data at each boundary it crosses, using pandera and pydantic.

Validation is not one gate at the end. It is a contract enforced wherever data
enters or changes shape:

  validate_tickets    pandera over the raw tickets frame from SQL. A structural
                      boundary check: it proves the extraction contract held.
  validate_reviews    pydantic over each review record at ingestion. Drops records
                      that parse as JSON but violate the review contract, and reports
                      how many were dropped.
  validate_examples   pandera over the final example projection plus pydantic over
                      every assembled conversation. The last gate before load, and
                      it raises rather than dropping, because a fine-tuning file is
                      the wrong place to let a quiet defect through.

The difference in posture is deliberate. At ingestion we drop bad source records and
count them (the world hands us junk; we filter it). At the final gate we raise (our
own pipeline should never produce a bad example; if it did, that is a bug to stop on).
"""

from __future__ import annotations

import pandas as pd
import pandera.pandas as pa
from pydantic import ValidationError

from .schema import (EXAMPLE_TABLE_SCHEMA, ChatExample, ReviewRecord, SpecRecord,
                     tickets_schema)
from .tokens import example_text


def validate_tickets(tickets: pd.DataFrame) -> dict:
    """Validate the raw tickets frame against the extract-boundary schema.

    Raises if the SQL extraction contract was violated (this should not happen; if
    it does, the extraction changed and the pipeline must stop). Returns a summary.
    """
    try:
        tickets_schema().validate(tickets, lazy=True)
    except pa.errors.SchemaErrors as exc:
        n = len(exc.failure_cases)
        raise ValueError(f"tickets failed extract-boundary schema: {n} cases") from exc
    return {"n_rows": len(tickets), "table_ok": True}


def validate_reviews(reviews: list[dict]) -> tuple[list[dict], int]:
    """Validate each review record; keep the valid ones, count the dropped.

    Reviews come from an external API and some are malformed at the data level (an
    out-of-range rating, a missing field) even when the JSON is well formed. We drop
    those at ingestion so they never reach the product-context aggregation, and we
    return the count so the loss is visible in the profile.
    """
    kept: list[dict] = []
    dropped = 0
    for record in reviews:
        try:
            model = ReviewRecord.model_validate(record)
        except ValidationError:
            dropped += 1
            continue
        kept.append(model.model_dump())
    return kept, dropped



def _table_projection(examples: pd.DataFrame) -> pd.DataFrame:
    """Project the examples frame to the columns the pandera schema validates."""
    return pd.DataFrame({
        "category": examples["category"].astype("str"),
        "source": examples["source"].astype("str"),
        "user_chars": examples["messages"].map(
            lambda m: len(m[1]["content"])).astype("int64"),
        "assistant_chars": examples["messages"].map(
            lambda m: len(m[-1]["content"])).astype("int64"),
        "n_tokens": examples["n_tokens"].astype("int64"),
    })


def validate_examples(examples: pd.DataFrame) -> dict:
    """Validate the full examples frame. Raise on any failure; return a summary.

    Returns {"n_validated": int, "table_ok": True, "rows_ok": int} on success.
    """
    # 1) Tabular validation (all column checks at once).
    projection = _table_projection(examples)
    try:
        EXAMPLE_TABLE_SCHEMA.validate(projection, lazy=True)
    except pa.errors.SchemaErrors as exc:
        n = len(exc.failure_cases)
        raise ValueError(f"pandera validation failed with {n} failing cases") from exc

    # 2) Row-level conversation-shape validation.
    row_errors: list[str] = []
    for i, messages in enumerate(examples["messages"]):
        try:
            ChatExample(messages=messages)
        except ValidationError as exc:
            row_errors.append(f"row {i}: {exc.errors()[0]['msg']}")
            if len(row_errors) >= 5:
                break
    if row_errors:
        raise ValueError("pydantic validation failed:\n  " + "\n  ".join(row_errors))

    return {
        "n_validated": len(examples),
        "table_ok": True,
        "rows_ok": len(examples),
    }
