# Cordwell Support Assistant, Week 2 Mini-Capstone (Student Starter)

You are building the data pipeline that produces a fine-tuning dataset for the
Cordwell Home and Hardware support assistant. The assistant drafts first-pass
replies for human support agents to review. Your job is not to train or call a
model. It is to do the part that determines whether such a model could ever be any
good: extract the raw support data from three messy sources, transform and clean
it, validate and profile it, and load it into the LLM-ready format the fine-tuning
step will consume.

All data is synthetic and generated locally. Nothing here leaves your machine, and
there are no API keys to manage.

## The shape of the work

Three sources, one target.

Sources:
1. A SQLite database (`cordwell.db`) standing in for the production support
   database: tickets, orders, and products.
2. Two local REST APIs (a mock server you run) for product reviews (paginated and
   rate limited) and product specs (occasionally malformed).
3. Two legacy files from a retired chat system: a latin-1 CSV and a JSON export
   with different key names.

Target: two JSONL files (`train` and `validation`), one training example per line,
in the role-based `messages` format that current chat fine-tuning endpoints accept.

## Setup

```
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements-capstone.txt
pip install -e .
python scripts/generate_sources.py   # writes the synthetic sources under data/
```

## The loop you will live in

```
python -m pytest -q                  # see what is red; the tests are your spec
# ... implement the next function ...
python -m pytest -q tests/test_extract_sql.py   # narrow to what you are working on
```

When you have implemented enough, run the whole thing end to end:

```
python scripts/run_pipeline.py       # spins up the mock API and runs Extract..Load
```

A finished run prints a stage-by-stage summary and writes the dataset, the trained
tokenizer, and a profile report under `data/output/`.

## What is given, what is yours

Given (do not need to touch): the config, the synthetic data generator, the mock
API server, the final-gate schema references, and all scaffolding. Yours to
implement: the functions that raise `NotImplementedError`, the schema and validator
contracts you author at each boundary (a Pandera schema for the raw tickets, Pydantic
models for the API specs and reviews), and three tests in `tests/test_todo.py`.
Follow `CAPSTONE_LAB_GUIDE.md` in order. The tests are the specification: when they
are green, you are done.

Stuck? Read the failing test first, then `HINTS.md`, which gives three escalating levels
of help per task. Use them freely. The docstrings get terser as the lab goes on by
design, and the hints are there so that terseness never turns into a dead end.
