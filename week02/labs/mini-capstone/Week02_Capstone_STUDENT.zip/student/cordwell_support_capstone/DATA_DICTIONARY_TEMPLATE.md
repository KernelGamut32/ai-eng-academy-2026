# Data Dictionary, Cordwell Week 2 Mini-Capstone (Task 0, complete this)

Before writing any code, explore the generated sources and fill in this template.
You cannot clean data you do not understand. Run `python scripts/generate_sources.py`
first, then inspect the files (sqlite3, a JSON viewer, pandas in a REPL).

All data is synthetic and refers to no real company, product, or person.

## Source 1: SQLite database, `data/cordwell.db`

List the tables. For each, record the columns, types, row count, and anything
notable (nulls, dominant values, encodings, distractors).

### Table `support_tickets` (____ rows)

| Column | Type | Notes (nulls? dominant values? PII?) |
|---|---|---|
| | | |

Which resolutions count as "usable" for training, and why? ____

Roughly what fraction of `category` is missing? ____
Which category dominates, and roughly what share? ____

### Other tables

Is any table present that the pipeline does not need? Which, and how did you decide?
____

## Source 2: Mock REST APIs

Start the server (`python scripts/serve_mock_api.py`) and hit each endpoint.

`GET /reviews`: How is it paginated? What is the stop condition? Which failure
statuses did you observe, and how should the client handle them? ____

`GET /specs/{id}`: Roughly what fraction are malformed? What makes a spec usable?
____

## Source 3: Legacy files

`legacy_chats.csv`: What encoding is it? What happens on a naive utf-8 read? What are
the column names? ____

`legacy_chats_extra.json`: What are the key names, and how do they map to the CSV's?
____

## Output

What is the exact shape of one output line? Which three messages does it contain, in
what order? ____

List the quality gates and their thresholds (from `config.py`): ____
