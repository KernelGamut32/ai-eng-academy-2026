"""Redact synthetic PII from free text before it can enter the training file.

Support free text routinely contains names, addresses, order numbers, emails, and
phone numbers. If that rides along into a fine-tuning file, the model can memorize
and later regurgitate it. Scrubbing here, in the transform stage, is the
responsible-AI control for this pipeline.

Every pattern is a RAW string. In Python 3.12+ an unescaped backslash sequence
such as \\d inside a normal string raises a SyntaxWarning; raw strings are the
correct, warning-free way to write regexes.

This is pattern-based redaction sufficient for structured PII and the explicit
"my name is X Y" construction. Production would add a trained NER model for
free-form names; that is called out as a limitation, not hidden.
"""

from __future__ import annotations

import re

import pandas as pd

# Order matters: email is matched before phone so an address or phone fragment
# inside an email never gets partially rewritten first.
_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"), "[EMAIL]"),
    (re.compile(r"\bCW-\d{8}\b"), "[ORDER_ID]"),
    (re.compile(r"\(\d{3}\)\s*\d{3}-\d{4}"), "[PHONE]"),
    (re.compile(r"\d+\s+\w+\s+St,\s+\w+,\s+NC\s+\d{5}"), "[ADDRESS]"),
    (re.compile(r"\bMy name is\s+[A-Z][a-z]+\s+[A-Z][a-z]+"), "My name is [NAME]"),
]


def scrub_pii(text: str) -> str:
    """Redact known PII patterns from a single string.

    _PATTERNS is given: a list of (compiled_regex, replacement) pairs in the right
    order. Apply each in turn and return the result. Pass None through unchanged.
    """
    raise NotImplementedError("Implement scrub_pii (apply every pattern in _PATTERNS).")


def scrub_series(series: pd.Series) -> pd.Series:
    """Apply scrub_pii across a Series of strings, preserving the index."""
    raise NotImplementedError("Implement scrub_series.")


def contains_pii(text: str) -> bool:
    """True if any structured PII pattern still matches (used by tests/profiling).

    Check only the first four _PATTERNS (email, order id, phone, address); the name
    pattern rewrites to a literal that no longer matches.
    """
    raise NotImplementedError("Implement contains_pii.")
