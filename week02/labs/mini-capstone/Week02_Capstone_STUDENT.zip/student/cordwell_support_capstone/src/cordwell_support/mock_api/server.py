"""A local stand-in for Cordwell's two third-party REST APIs.

This is GIVEN infrastructure, not something students implement. It exists so the
client code in `extract/api.py` has something realistic to talk to without any
external network. It deliberately behaves like a real, imperfect API:

  GET /reviews?page=N&per_page=K   Paginated. Requires a Bearer token. On the
                                   first attempt of a couple of pages it returns
                                   429 (with Retry-After) or 500, then succeeds on
                                   retry. This is what makes the backoff loop earn
                                   its keep.

  GET /specs/{product_id}          Returns the manufacturer spec bytes verbatim.
                                   About 10% of products return malformed JSON,
                                   exactly as the real spec service does.

Both endpoints return 401 without a valid token.

Run standalone:  python scripts/serve_mock_api.py
In tests:        use `run_mock_api(...)` as a context manager (ephemeral port).
"""

from __future__ import annotations

import json
import threading
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

# Pages that misbehave on their FIRST request, then recover. Deterministic so the
# client's retry path is exercised the same way on every machine.
_RATE_LIMIT_PAGES = {4, 11}   # -> 429 with Retry-After on first hit
_SERVER_ERROR_PAGES = {7}     # -> 500 on first hit


def _make_handler(reviews: list[dict], specs_dir: Path, token: str, per_page: int):
    seen_429: set[int] = set()
    seen_500: set[int] = set()

    class Handler(BaseHTTPRequestHandler):
        # Silence the default per-request stderr logging.
        def log_message(self, *args):
            return

        def _authorized(self) -> bool:
            return self.headers.get("Authorization") == f"Bearer {token}"

        def _send_json(self, status: int, payload: dict, extra_headers=None):
            body = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            for k, v in (extra_headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _send_raw(self, status: int, body: bytes):
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            parsed = urlparse(self.path)
            if not self._authorized():
                self._send_json(401, {"error": "missing or invalid token"})
                return

            if parsed.path == "/reviews":
                self._handle_reviews(parse_qs(parsed.query))
            elif parsed.path.startswith("/specs/"):
                self._handle_spec(parsed.path.rsplit("/", 1)[-1])
            else:
                self._send_json(404, {"error": "not found"})

        def _handle_reviews(self, qs):
            page = int(qs.get("page", ["1"])[0])
            size = int(qs.get("per_page", [str(per_page)])[0])

            # Inject transient failures on first contact with certain pages.
            if page in _RATE_LIMIT_PAGES and page not in seen_429:
                seen_429.add(page)
                self._send_json(429, {"error": "rate limited"},
                                {"Retry-After": "1"})
                return
            if page in _SERVER_ERROR_PAGES and page not in seen_500:
                seen_500.add(page)
                self._send_json(500, {"error": "internal server error"})
                return

            total = len(reviews)
            total_pages = (total + size - 1) // size
            start = (page - 1) * size
            chunk = reviews[start:start + size]
            self._send_json(200, {
                "page": page,
                "per_page": size,
                "total_pages": total_pages,
                "total": total,
                "has_more": page < total_pages,
                "reviews": chunk,
            })

        def _handle_spec(self, pid_str: str):
            path = specs_dir / f"{pid_str}.json"
            if not path.exists():
                self._send_json(404, {"error": "unknown product"})
                return
            # Return the bytes verbatim -- malformed specs stay malformed on the
            # wire, which is the whole point of the defensive-parsing exercise.
            self._send_raw(200, path.read_bytes())

    return Handler


def make_server(data_dir, token="cordwell-demo-token", host="127.0.0.1", port=8077,
                per_page=100) -> ThreadingHTTPServer:
    """Build (but do not start) a mock API server bound to host:port.

    Pass port=0 to grab an ephemeral free port (useful in tests).
    """
    data_dir = Path(data_dir)
    reviews = json.loads((data_dir / "reviews.json").read_text())
    specs_dir = data_dir / "specs"
    handler = _make_handler(reviews, specs_dir, token, per_page)
    return ThreadingHTTPServer((host, port), handler)


@contextmanager
def run_mock_api(data_dir, token="cordwell-demo-token", per_page=100):
    """Context manager that runs the mock API on an ephemeral port in a thread.

    Yields the base URL (e.g. "http://127.0.0.1:53124"). Shuts down on exit.
    """
    server = make_server(data_dir, token=token, host="127.0.0.1", port=0,
                         per_page=per_page)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    host, port = server.server_address
    try:
        yield f"http://{host}:{port}"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
