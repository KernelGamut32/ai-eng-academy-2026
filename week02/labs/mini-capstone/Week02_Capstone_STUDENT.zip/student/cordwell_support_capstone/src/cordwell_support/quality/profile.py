"""Profile the finished dataset and check it against the Module 01 quality gates.

Profiling is the last thing that stands between a plausible-looking dataset and a
trusted one. It computes the numbers that actually matter for a support assistant
-- how many examples, how balanced, how deduplicated, how long -- and compares each
to a threshold. The gate is hard: if any threshold fails, `passed` is False and the
pipeline refuses to load.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..config import (Config, MAX_CATEGORY_SHARE, MAX_DUPLICATE_RATE,
                      MAX_EXAMPLE_TOKENS, MIN_COMPLETENESS, MIN_EXAMPLES)
from .tokens import example_text
from ..transform.pii import contains_pii


def profile_dataset(examples: pd.DataFrame, cfg: Config) -> dict:
    """Compute quality metrics and evaluate them against the gates.

    Compute: n_examples; category_shares and the max share; duplicate_rate over the
    (user, assistant) content pair; completeness (fraction with non-blank user and
    assistant content); token-length min/median/p95/max from the n_tokens column;
    and residual_pii count (contains_pii over any message content).

    Build a "checks" dict mapping each gate to {"value", "threshold", "ok"} using
    MIN_EXAMPLES, MAX_CATEGORY_SHARE, MAX_DUPLICATE_RATE, MIN_COMPLETENESS,
    MAX_EXAMPLE_TOKENS, and residual PII == 0. "passed" is True only if every check
    is ok. Return a JSON-serializable report including the raw metrics and checks.
    """
    raise NotImplementedError("Implement profile_dataset (metrics + hard gate).")
