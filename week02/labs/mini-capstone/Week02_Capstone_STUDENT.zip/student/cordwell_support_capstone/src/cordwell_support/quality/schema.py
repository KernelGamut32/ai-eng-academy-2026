"""Schemas that define what valid data is, at every boundary it crosses.

Validation is not a single step at the end. It is a contract enforced wherever data
enters or changes shape. This module holds all of those contracts, using pandera for
tabular frames and pydantic for individual records.

Given as worked references:
  EXAMPLE_TABLE_SCHEMA   A pandera DataFrameSchema over the final example projection
                         (category, char counts, token count).
  ChatMessage/ChatExample  Pydantic models for one assembled chat example: role is a
                         fixed set, content is non-blank, and the conversation has the
                         right shape (leading system, trailing assistant, a user turn).

Authored in this lab, one per boundary:
  tickets_schema()       A pandera DataFrameSchema for the raw tickets frame straight
                         out of SQL. Asserts the extraction contract held before any
                         transform runs.
  SpecRecord             A pydantic model for one product spec from the API. A spec
                         that parses as JSON but violates this contract is not usable.
  ReviewRecord           A pydantic model for one product review from the API. Catches
                         out-of-range ratings and missing fields at ingestion.

Note the imports: `import pandera.pandas as pa`. The bare `import pandera as pa`
raises a FutureWarning on current pandera; the .pandas path is the supported one.
And pydantic v2 idioms throughout: @field_validator + @classmethod, model_dump().
"""

from __future__ import annotations

import pandera.pandas as pa
from pandera.pandas import Check, Column, DataFrameSchema
from pydantic import BaseModel, field_validator
from typing import Literal

from ..config import (CATEGORIES, MAX_EXAMPLE_TOKENS, MAX_REPLY_CHARS,
                      MIN_REPLY_CHARS, USABLE_RESOLUTIONS)

# ---- Tabular contract (pandera) ------------------------------------------
EXAMPLE_TABLE_SCHEMA = DataFrameSchema(
    {
        "category": Column(str, Check.isin(list(CATEGORIES))),
        "source": Column(str),
        "user_chars": Column(int, Check.ge(1)),
        "assistant_chars": Column(int, Check.in_range(MIN_REPLY_CHARS, MAX_REPLY_CHARS)),
        "n_tokens": Column(int, Check.in_range(1, MAX_EXAMPLE_TOKENS)),
    },
    strict=True,
    coerce=True,
)


# ---- Row contract (pydantic v2) ------------------------------------------
class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str

    @field_validator("content")
    @classmethod
    def content_not_blank(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("message content must not be blank")
        return v


class ChatExample(BaseModel):
    messages: list[ChatMessage]

    @field_validator("messages")
    @classmethod
    def valid_conversation_shape(cls, msgs: list[ChatMessage]) -> list[ChatMessage]:
        if len(msgs) < 3:
            raise ValueError("expected at least system, user, assistant")
        roles = [m.role for m in msgs]
        if roles[0] != "system":
            raise ValueError("first message must be the system message")
        if roles[-1] != "assistant":
            raise ValueError("conversation must end with an assistant message")
        if "user" not in roles:
            raise ValueError("conversation must contain a user message")
        return msgs


# ---- Extract-boundary contract (pandera), authored in this lab -------------
def tickets_schema() -> DataFrameSchema:
    """A pandera schema for the raw tickets frame straight out of SQL.

    This is a boundary check: it asserts that the SQL extraction contract held before
    any transform runs. It is built as a function, not a module constant, so it can be
    constructed on demand.

    Before you write it, answer the question this schema exists to answer: what does
    _TICKETS_SQL actually guarantee about the rows it returns? Whatever the query
    promises, the schema should prove. Assert those invariants.

    Then answer the harder question: what is NOT yet true of this frame? Raw data is
    raw. Some columns are still dirty at this boundary and only get cleaned three
    stages later. If you constrain one of those here, you will reject perfectly normal
    rows. A boundary contract encodes what must be true AT that boundary, and nothing
    more. The tests in tests/test_quality.py define the acceptance criteria, including
    one that will fail if you over-constrain.

    Remember that this frame carries columns the pipeline never uses. Decide whether
    an unexpected column should be an error here.
    """
    # EXAMPLE_TABLE_SCHEMA above is a worked example of the shape a DataFrameSchema
    # takes. Which columns to check, and with which Checks, is your call.
    raise NotImplementedError("Author tickets_schema.")


# ---- Source-record contracts (pydantic v2), authored in this lab -----------
class SpecRecord(BaseModel):
    """One product spec from the API. Validated in fetch_spec at ingestion.

    A spec that parses as JSON but fails this contract (for example a blank or
    missing material) is not usable and is treated as a failed fetch.
    """
    product_id: int
    name: str
    material: str
    warranty_months: int | None = None
    weight_lbs: float | None = None

    @field_validator("material")
    @classmethod
    def material_not_blank(cls, v: str) -> str:
        """Enforce the rule this model's docstring implies about material.

        ChatMessage.content_not_blank above is the pattern for a field validator: what
        it returns, what it raises, and why the @classmethod decorator is there.
        """
        raise NotImplementedError("Implement material_not_blank.")


class ReviewRecord(BaseModel):
    """One product review from the API. Validated at ingestion.

    A review is only usable if every field is present and the rating is a whole number
    from 1 to 5 inclusive. Valid JSON is not the same as valid data, and this is where
    that gap is closed for reviews. These records feed the average-rating aggregation
    that grounds product answers, so a bad rating here quietly corrupts training data.
    """
    review_id: int
    product_id: int
    rating: int
    title: str
    body: str
    created_at: str

    @field_validator("rating")
    @classmethod
    def rating_in_range(cls, v: int) -> int:
        """Reject ratings the review contract does not allow.

        The valid range is stated in the class docstring and in the data dictionary.
        Decide what this should do with a value outside it, and what pydantic expects
        a field validator to do in that case.
        """
        raise NotImplementedError("Implement rating_in_range.")
