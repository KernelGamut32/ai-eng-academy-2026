"""Train a small corpus tokenizer and measure per-example token length.

Fine-tuning examples are billed and bounded in tokens, not characters. A pipeline
that only checks character length can still ship examples that overflow a context
window. So we train a byte-level BPE tokenizer on this corpus (offline, no
downloads) and use it to (1) profile the token-length distribution and (2) drop
examples that exceed the token budget.

Byte-level BPE never emits an unknown token -- every byte is representable -- which
is why it is the workhorse for modern LLM tokenization.
"""

from __future__ import annotations

from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers

from ..config import Config


def example_text(messages: list[dict]) -> str:
    """Flatten a messages array into one string for length measurement."""
    return "\n".join(m["content"] for m in messages)


def train_tokenizer(texts, cfg: Config) -> Tokenizer:
    """Train a byte-level BPE tokenizer on the provided texts.

    Deterministic for a fixed corpus and vocab size. Returns a ready tokenizer.
    """
    tokenizer = Tokenizer(models.BPE(unk_token="[UNK]"))
    tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=True)
    tokenizer.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(
        vocab_size=cfg.tokenizer_vocab_size,
        min_frequency=2,
        special_tokens=["[PAD]", "[UNK]", "[BOS]", "[EOS]"],
    )
    tokenizer.train_from_iterator(list(texts), trainer=trainer)
    return tokenizer


def count_tokens(messages: list[dict], tokenizer: Tokenizer) -> int:
    """Token count for one assembled example (all message contents combined).

    Hint: example_text(messages) flattens the content; encode it and count the ids.
    """
    raise NotImplementedError("Implement count_tokens.")


def add_token_lengths(examples: "pd.DataFrame", tokenizer: Tokenizer):  # noqa: F821
    """Return the examples frame with an added n_tokens column."""
    lengths = examples["messages"].map(lambda m: count_tokens(m, tokenizer))
    return examples.assign(n_tokens=lengths)


def gate_by_tokens(examples: "pd.DataFrame", cfg: Config):  # noqa: F821
    """Drop examples whose token length exceeds MAX_EXAMPLE_TOKENS. Return (kept, dropped)."""
    raise NotImplementedError("Implement gate_by_tokens (filter on n_tokens).")
