"""Compose the whole pipeline: Extract, Transform, Validate, Profile, Load.

This is the single function that runs identically in tests, in the CLI, and in
production. No stage logic lives in scripts or notebooks -- they only call in here.
Reading top to bottom is the pipeline: each block is one stage from Module 01.
"""

from __future__ import annotations

import json

import requests

from .config import Config
from .extract import api, files, sql
from .transform import assemble, pii, select
from .quality import profile as profile_mod
from .quality import tokens as tok
from .quality import validate as validate_mod
from .load import writer


def run_pipeline(cfg: Config, session: requests.Session | None = None) -> dict:
    """Run the end-to-end pipeline and return a summary dict.

    The integration task. Every stage function you have written gets called, and the
    data is threaded from one to the next. Here they are, in alphabetical order, which
    is emphatically not the order you want:

        add_token_lengths      assemble_examples     balance_categories
        build_product_context  fetch_reviews         fetch_specs
        gate_by_tokens         impute_category       load_legacy_chats
        make_engine            normalize_sources     profile_dataset
        read_products          read_tickets_chunked  scrub_series
        select_candidates      split_and_write       train_tokenizer
        validate_examples      validate_reviews      validate_tickets

    Most of the sequence follows from the data: you cannot tokenize examples you have
    not assembled, and you cannot ground a product question before you have built the
    product context. Work those dependencies out and most of the pipeline orders itself.

    But at least one pair of steps is order sensitive in a way the dependencies do not
    reveal. Both orderings run without error. Both produce a dataset. Only one produces
    a correct one, and the difference is measured in thousands of examples. Before you
    commit to an order, read what each check in profile.py actually measures, and ask
    yourself which of your steps could change the text that a later step compares.

    If you choose wrong, a quality gate will fail and tell you so. That is the gate
    doing its job. Do not weaken the threshold to get past it: find out why it fired.

    Requires the mock API reachable at cfg.api_base_url. Write the profile report to
    cfg.profile_path and raise RuntimeError if the gate does not pass. Return a summary
    dict with an "ok" flag and a "stages" section; scripts/run_pipeline.py is given and
    prints that summary, so it shows you which keys it expects.
    """
    raise NotImplementedError("Implement run_pipeline.")
