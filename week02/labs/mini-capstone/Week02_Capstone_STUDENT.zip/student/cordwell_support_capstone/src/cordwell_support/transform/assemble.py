"""Build the product knowledge context and assemble messages-format examples.

Two jobs:

  build_product_context   Join three sources -- SQL products, API specs, and API
                          reviews -- into one lookup: product_id -> a short factual
                          context string. This is where the API extraction finally
                          pays off; without it the reviews and specs would have been
                          pulled for nothing.

  assemble_examples       Turn each cleaned, scrubbed row into a chat example:
                          a system message, the customer's user message, and the
                          agent's assistant message. For product questions that
                          have a known product, the relevant context is grounded
                          into the system message so the assistant can answer from
                          facts rather than guessing.

The output format is the modern role-based `messages` array -- the schema current
chat fine-tuning endpoints accept. The legacy {prompt, completion} format is not
used anywhere; it is rejected by current chat fine-tuning APIs.
"""

from __future__ import annotations

import pandas as pd

from ..config import SYSTEM_PROMPT, Config


def build_product_context(products: pd.DataFrame, specs_by_id: dict[int, dict],
                          reviews: list[dict]) -> dict[int, str]:
    """Join products + specs + reviews into a product_id -> context-string map.

    Only products with a valid spec get an entry. Aggregate the reviews list to a
    mean rating and count per product_id. For each spec, build a short factual
    string from the product name, material, warranty, and (if present) the rating.
    Return {product_id: context_string}.
    """
    raise NotImplementedError("Implement build_product_context (the three-source join).")


def _system_message(row, product_context: dict[int, str]) -> str:
    """Base system prompt, with product context grounded in for product questions."""
    base = SYSTEM_PROMPT
    pid = row["product_id"]
    if row["category"] == "product_question" and pd.notna(pid):
        ctx = product_context.get(int(pid))
        if ctx:
            return base + "\n\nRelevant product information:\n" + ctx
    return base


def assemble_examples(df: pd.DataFrame, product_context: dict[int, str],
                      cfg: Config) -> pd.DataFrame:
    """Build one messages-format example per row.

    For each row build messages = [system, user, assistant] where the system
    content comes from _system_message(row, product_context) (given), user is
    user_text, assistant is assistant_text. Return a frame with columns messages
    (list of dicts), category, and source.
    """
    raise NotImplementedError("Implement assemble_examples (messages array per row).")
