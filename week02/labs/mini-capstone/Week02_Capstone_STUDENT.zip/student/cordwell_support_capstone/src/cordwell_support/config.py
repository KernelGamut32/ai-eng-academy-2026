"""Central, reproducible configuration for the Cordwell support-assistant pipeline.

Everything version-sensitive or run-shaping lives here so a teammate can reproduce
an identical dataset on a fresh machine. Nothing in the pipeline should hard-code a
seed, a threshold, or a path. Read them from a Config instance instead.

Design note (Week 2, Module 02): reproducibility is a build-time obligation, not an
afterthought. Seeds, pinned thresholds, and an explicit output layout are what turn
"it worked on my laptop" into "it works on yours too".
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

# --------------------------------------------------------------------------
# Fixed domain constants (identical across every run, every machine)
# --------------------------------------------------------------------------

# The one system message every training example carries. Fine-tuning teaches the
# model to behave consistently under this instruction, so it must be stable.
SYSTEM_PROMPT = (
    "You are Cordwell Home and Hardware's internal support drafting assistant. "
    "You write a clear, friendly first-draft reply for a human support agent to "
    "review and edit before it is sent to a customer. Never invent order details, "
    "prices, or policies you were not given. If key information is missing, state "
    "what you would need in order to help."
)

# The category taxonomy the assistant is trained to cover. Anything outside this
# set is treated as out-of-scope and dropped during selection.
CATEGORIES: tuple[str, ...] = (
    "order_status",
    "returns",
    "product_question",
    "shipping",
    "billing",
)

# Resolution values that mark a ticket as a usable teaching example.
USABLE_RESOLUTIONS: tuple[str, ...] = ("resolved", "escalated_resolved")

# Quality gates the finished dataset must clear before it is allowed to load.
# These come straight from the Module 01 pipeline model.
MIN_COMPLETENESS = 0.95          # >= 95% of required fields present after cleaning
MAX_DUPLICATE_RATE = 0.02        # < 2% duplicate (user, assistant) pairs
MAX_CATEGORY_SHARE = 0.35        # no single category may exceed 35% of the set
MIN_EXAMPLES = 800               # a run producing fewer than this is suspect

# Reply-length sanity bounds, in characters, for a usable assistant message.
MIN_REPLY_CHARS = 40
MAX_REPLY_CHARS = 2000

# Token budget for one assembled example (system + user + assistant), measured
# with the corpus BPE tokenizer. Examples longer than this are dropped so nothing
# silently overflows a fine-tuning context window.
MAX_EXAMPLE_TOKENS = 512


@dataclass(frozen=True)
class Config:
    """Immutable run configuration. Construct once, thread it through the pipeline.

    Frozen on purpose: a config that can be mutated mid-run is a reproducibility
    bug waiting to happen.
    """

    # Reproducibility
    seed: int = 42
    split_seed: int = 13
    val_fraction: float = 0.1

    # Filesystem layout (all relative to a project-local data root by default)
    data_root: Path = field(default_factory=lambda: Path(os.environ.get(
        "CORDWELL_DATA_ROOT", "data")))

    # Source knobs
    db_filename: str = "cordwell.db"
    api_dir_name: str = "api"
    legacy_csv_name: str = "legacy_chats.csv"
    legacy_json_name: str = "legacy_chats_extra.json"

    # Mock API client settings (Module 03)
    api_base_url: str = field(default_factory=lambda: os.environ.get(
        "CORDWELL_API_BASE", "http://127.0.0.1:8077"))
    api_token: str = field(default_factory=lambda: os.environ.get(
        "CORDWELL_API_TOKEN", "cordwell-demo-token"))
    api_page_size: int = 100
    api_max_retries: int = 5
    api_backoff_factor: float = 0.5   # urllib3 schedule: 0, 1, 2, 4, 8 seconds
    api_timeout_seconds: float = 10.0

    # SQL extraction (Module 04)
    sql_chunksize: int = 10_000

    # Category balancing (Module 05): cap each category at this many examples.
    # Categories with fewer rows keep all of them.
    target_per_category: int = 1_500

    # Tokenizer (Week 2 LLM focus)
    tokenizer_vocab_size: int = 2_000

    # --- Derived paths -----------------------------------------------------
    @property
    def db_path(self) -> Path:
        return self.data_root / self.db_filename

    @property
    def api_dir(self) -> Path:
        return self.data_root / self.api_dir_name

    @property
    def legacy_csv_path(self) -> Path:
        return self.data_root / self.legacy_csv_name

    @property
    def legacy_json_path(self) -> Path:
        return self.data_root / self.legacy_json_name

    @property
    def output_dir(self) -> Path:
        return self.data_root / "output"

    @property
    def train_path(self) -> Path:
        return self.output_dir / "cordwell_sft_train.jsonl"

    @property
    def val_path(self) -> Path:
        return self.output_dir / "cordwell_sft_val.jsonl"

    @property
    def profile_path(self) -> Path:
        return self.output_dir / "profile_report.json"

    @property
    def tokenizer_path(self) -> Path:
        return self.output_dir / "corpus_bpe.json"
