"""Extract legacy chat transcripts from messy CSV and JSON exports.

The retired live-chat system left two exports behind, and they are exactly as
inconsistent as real dumps: the CSV is latin-1 encoded (a naive utf-8 read
raises), has mixed-case headers, whitespace-only rows, and about 8% duplicated
rows; the JSON export uses entirely different key names for the same fields.

This module normalizes both into one tidy frame with a stable column contract:
    source, session_id, user_text, agent_text, topic
so the rest of the pipeline never has to care where a row came from.
"""

from __future__ import annotations

import json
from io import StringIO

import pandas as pd

from ..config import Config

# Canonical column names every downstream stage can rely on.
CANONICAL_COLUMNS = ["source", "session_id", "user_text", "agent_text", "topic"]

# Map the CSV's mixed-case headers to canonical names.
_CSV_RENAME = {
    "Session_ID": "session_id",
    "User_Text": "user_text",
    "Agent_Text": "agent_text",
    "Topic": "topic",
    "Ended_At": "ended_at",
}

# Map the JSON export's alien keys to canonical names.
_JSON_RENAME = {
    "sessionId": "session_id",
    "customer": "user_text",
    "rep": "agent_text",
    "label": "topic",
}


def _read_text_resilient(path) -> str:
    """Read a text file, falling back from utf-8 to latin-1 on decode failure.

    latin-1 maps every byte to a code point, so it never raises. It is the
    pragmatic last resort for an export of unknown provenance.
    """
    raw = path.read_bytes()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1")


def _load_csv(cfg: Config) -> pd.DataFrame:
    text = _read_text_resilient(cfg.legacy_csv_path)
    df = pd.read_csv(StringIO(text), dtype="str")
    df = df.rename(columns=_CSV_RENAME)
    df["source"] = "legacy_csv"
    for col in ("user_text", "agent_text", "topic"):
        if col not in df.columns:
            df[col] = pd.NA
    return df[CANONICAL_COLUMNS]


def _load_json(cfg: Config) -> pd.DataFrame:
    records = json.loads(cfg.legacy_json_path.read_text())
    df = pd.DataFrame.from_records(records).rename(columns=_JSON_RENAME)
    df["source"] = "legacy_json"
    # A missing "rep" key means the column is absent for some rows; ensure it exists.
    for col in ("user_text", "agent_text", "topic"):
        if col not in df.columns:
            df[col] = pd.NA
    return df[CANONICAL_COLUMNS]


def load_legacy_chats(cfg: Config) -> pd.DataFrame:
    """Load, unify, and lightly clean both legacy exports.

    Cleaning here is only what is needed to make the two sources one honest frame:
    resolve encoding, unify columns, drop exact-duplicate rows, and drop rows whose
    user or agent text is blank or whitespace-only (they carry no training signal).
    Heavier selection is the transform stage's job.

    Returns a frame with columns: source, session_id, user_text, agent_text, topic.

    _load_csv and _load_json are given and already hand you the canonical columns, so
    your work is the unification and the cleaning: make the two frames one, decide what
    counts as "no usable text" (a field of three spaces is not text), and remove exact
    duplicate conversations. Heavier selection is the transform stage's job, not yours.

    One thing the profiler will want later: record how many rows you dropped, on
    combined.attrs["rows_dropped"]. A row that disappears without a count is a row you
    cannot explain.
    """
    raise NotImplementedError("Implement load_legacy_chats.")
