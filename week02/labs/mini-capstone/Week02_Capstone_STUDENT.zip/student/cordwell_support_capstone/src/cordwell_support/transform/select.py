"""Turn millions of messy rows into a smaller, well-chosen training set (Module 05).

This is the pandas heart of the pipeline. Four moves:

  normalize_sources   Fold SQL tickets and legacy chats into one candidate frame
                      with a single column contract (CANDIDATE_COLUMNS).
  impute_category     A deliberate policy for missing categories: impute from
                      keywords when confident, otherwise exclude. Never let a
                      missing value silently vanish from the counts.
  select_candidates   Chained boolean masks, each logged with how many rows it
                      removes, so the drop is auditable rather than mysterious.
  balance_categories  Cap the dominant category so the assistant is not trained
                      almost entirely on order-status replies.

Everything must use .loc for combined row+column selection and masks aligned to
the frame's index, so nothing trips the pandas 3.0 index-alignment or
chained-assignment traps.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..config import CATEGORIES, Config, MAX_REPLY_CHARS, MIN_REPLY_CHARS

CANDIDATE_COLUMNS = ["source", "user_text", "assistant_text", "category", "product_id"]

# Ordered keyword rules for imputing a missing category. First match wins, so the
# order encodes precedence (an "order status" phrase beats a stray "ship").
_IMPUTE_RULES: list[tuple[str, tuple[str, ...]]] = [
    ("order_status", ("where is my order", "order status", "tracking", "track my",
                      "status update", "still have not seen it ship")),
    ("returns", ("return", "send it back", "exchange", "arrived damaged")),
    ("shipping", ("shipping", "deliver", "delivery", "how long does it take",
                  "ship it")),
    ("billing", ("charged", "charge", "refund", "invoice", "billed", "my card")),
    ("product_question", ("warranty", "compatible", "difference between",
                          "come with", "assembly", "in stock", "colors")),
]


def normalize_sources(tickets: pd.DataFrame, legacy: pd.DataFrame) -> pd.DataFrame:
    """Fold the two upstream sources into one candidate frame (CANDIDATE_COLUMNS).

    SQL tickets: customer_message -> user_text, agent_reply -> assistant_text, keep
    category and product_id. Legacy chats: user_text/agent_text/topic map to
    user_text/assistant_text/category, with product_id set to NA. Concatenate them.
    Treat empty-string and obvious junk topics (for example "misc") as a missing
    category (pd.NA) so impute_category can deal with them.
    """
    raise NotImplementedError("Implement normalize_sources.")


def _impute_one(text: str) -> str | None:
    """Return the first category whose keywords appear in text, else None."""
    low = text.lower()
    for category, keywords in _IMPUTE_RULES:
        if any(k in low for k in keywords):
            return category
    return None


def impute_category(candidates: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Fill missing categories from keyword rules; drop the truly ambiguous ones.

    Policy: where _impute_one fires on the user_text, use that category. Where the
    category is still missing afterward, exclude the row (we will not guess a
    training label). Rows that already have a valid category are untouched.

    Return (frame, stats) where stats has keys missing_before, imputed, and
    excluded_unresolvable. The counts must add up, so the loss is visible.
    """
    raise NotImplementedError("Implement impute_category (impute then exclude, with stats).")


def select_candidates(candidates: pd.DataFrame, cfg: Config
                      ) -> tuple[pd.DataFrame, list[dict]]:
    """Apply quality filters as chained masks, logging each filter's drop count.

    A good example has: an in-taxonomy category (CATEGORIES), a present user
    message and assistant reply, a reply whose length is within [MIN_REPLY_CHARS,
    MAX_REPLY_CHARS], and is not a duplicate (user, assistant) pair. Apply each
    condition in turn and record {"filter", "removed", "remaining"} for each, so a
    surprising final count is traceable to the exact filter responsible. Use .loc
    and index-aligned masks.

    Return (kept_frame, log).
    """
    raise NotImplementedError("Implement select_candidates (chained masks + per-filter log).")


def balance_categories(df: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    """Cap each category at cfg.target_per_category, sampling with cfg.seed.

    Categories above the cap are downsampled to exactly the cap; smaller categories
    keep every row. Must be deterministic for a fixed seed.
    """
    raise NotImplementedError("Implement balance_categories (seeded downsample per category).")
