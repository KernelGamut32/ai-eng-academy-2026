"""Split, write, and verify the final LLM-ready JSONL shards (Module 01 Load).

The load stage produces the artifact next week's fine-tuning workflow consumes:
two JSONL files (train and validation), one example per line, in the messages
format. It then reloads them with Hugging Face `datasets` to prove the files are
actually consumable -- a write that no one reads back is a write you cannot trust.

Reproducibility details that matter:
  * The split is stratified by category and seeded, so train/val proportions are
    stable and both splits see every category.
  * JSONL is written with orjson for speed and correct handling of the nested
    structure. Each line is one compact JSON object followed by a newline.
  * datasets offline env vars are set BEFORE importing datasets, so verification
    never reaches for the network.
"""

from __future__ import annotations

import os

import numpy as np
import orjson
import pandas as pd

from ..config import Config


def stratified_split(examples: pd.DataFrame, cfg: Config
                     ) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Split into (train, val), stratified by category, using cfg.split_seed.

    Both splits must contain every category, in the same proportion as the whole, and
    two runs with the same config must produce the same split. Work out what that
    demands of your sampling, and which seed on cfg is the right one to use here.
    """
    raise NotImplementedError("Implement stratified_split.")


def write_jsonl(examples: pd.DataFrame, path) -> int:
    """Write examples to JSONL: one {"messages": [...]} object per line.

    Only the messages field belongs in the file. The profiling columns are our
    bookkeeping, and the fine-tuning endpoint has no use for them. Use orjson, and
    notice what type orjson.dumps returns before you open the file. Return the count.
    """
    raise NotImplementedError("Implement write_jsonl.")


def verify_roundtrip(train_path, val_path) -> dict:
    """Reload the written shards with Hugging Face datasets to confirm they parse.

    A write that nobody reads back is a write you cannot trust. Load both shards with
    Hugging Face datasets and return their row counts and column names.

    This lab runs with no network access, and datasets will try to reach the hub unless
    you stop it. Making that work is part of the task. If it hangs or errors on a
    network call, the fix is about the environment, and about when the environment is
    read.
    """
    raise NotImplementedError("Implement verify_roundtrip.")


def split_and_write(examples: pd.DataFrame, cfg: Config) -> dict:
    """Split, write both shards to the configured paths, verify, and return a summary."""
    raise NotImplementedError("Implement split_and_write.")
