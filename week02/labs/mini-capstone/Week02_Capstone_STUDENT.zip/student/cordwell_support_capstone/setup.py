"""Minimal packaging so `pip install -e .` makes `cordwell_support` importable.

Plain setuptools + requirements.txt on purpose. No pyproject.toml, no uv, no Ruff:
the cohort standard for this Academy is the smallest packaging that works.
"""

from setuptools import find_packages, setup

setup(
    name="cordwell_support_capstone",
    version="0.1.0",
    description="Week 2 mini-capstone: data pipeline for Cordwell's support assistant",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.13",
)
