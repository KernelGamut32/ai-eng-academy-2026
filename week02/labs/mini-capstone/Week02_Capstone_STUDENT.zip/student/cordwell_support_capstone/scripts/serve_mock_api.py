"""Launch the mock Cordwell APIs on a fixed local port for hands-on work.

    python scripts/serve_mock_api.py

Serves on http://127.0.0.1:8077 by default (override with CORDWELL_API_BASE host/
port via the args below). Leave this running in one terminal while you run the
pipeline in another. Ctrl-C to stop.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cordwell_support.config import Config  # noqa: E402
from cordwell_support.mock_api.server import make_server  # noqa: E402


def main():
    cfg = Config()
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8077)
    ap.add_argument("--per-page", type=int, default=cfg.api_page_size)
    args = ap.parse_args()

    server = make_server(cfg.api_dir, token=cfg.api_token, host=args.host,
                         port=args.port, per_page=args.per_page)
    print(f"Mock Cordwell API on http://{args.host}:{args.port}")
    print("  GET /reviews?page=1&per_page=100   (Bearer token required)")
    print("  GET /specs/<product_id>")
    print(f"  token: {cfg.api_token}")
    print("Ctrl-C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.shutdown()
        server.server_close()


if __name__ == "__main__":
    main()
