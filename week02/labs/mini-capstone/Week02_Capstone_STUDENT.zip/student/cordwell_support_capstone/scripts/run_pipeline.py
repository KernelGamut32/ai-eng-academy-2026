"""Run the full Cordwell pipeline end to end and print a summary.

By default this spins up the mock API in-process, so a single command runs the
whole thing:

    python scripts/run_pipeline.py

If you are already running the API in another terminal (scripts/serve_mock_api.py),
pass --no-serve and set CORDWELL_API_BASE to that server's URL.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cordwell_support.config import Config  # noqa: E402
from cordwell_support.pipeline import run_pipeline  # noqa: E402
from cordwell_support.mock_api.server import run_mock_api  # noqa: E402


def _print_summary(summary: dict):
    ex = summary["stages"]["extract"]
    print("\nEXTRACT :", f"{ex['tickets']} tickets, {ex['legacy_chats']} legacy, "
          f"{ex['reviews_ok']} reviews ({ex['reviews_dropped']} dropped), "
          f"{ex['specs_ok']} specs ({ex['specs_failed']} rejected)")
    tr = summary["stages"]["transform"]
    print("TRANSFORM:", f"imputed {tr['impute']['imputed']}, "
          f"excluded {tr['impute']['excluded_unresolvable']}, "
          f"balanced -> {tr['after_balance']}, assembled {tr['assembled']}")
    for step in tr["select_log"]:
        print(f"   filter {step['filter']:<34} removed {step['removed']:>7} "
              f"-> {step['remaining']}")
    tk = summary["stages"]["tokenize"]
    print("TOKENIZE:", f"vocab {tk['vocab_size']}, "
          f"dropped-over-budget {tk['dropped_over_budget']}, "
          f"remaining {tk['examples_remaining']}")
    pr = summary["stages"]["profile"]
    print("PROFILE :", f"{pr['n_examples']} examples, "
          f"max_share {pr['checks']['max_category_share']['value']}, "
          f"dup_rate {pr['duplicate_rate']}, "
          f"tokens p95 {pr['token_lengths']['p95']} / max {pr['token_lengths']['max']}")
    print("   checks:", {k: v["ok"] for k, v in pr["checks"].items()})
    ld = summary["stages"]["load"]
    print("LOAD    :", f"train {ld['train_written']}, val {ld['val_written']}, "
          f"roundtrip {ld['roundtrip']}")
    print("\nGATE PASSED. Artifacts in:", Config().output_dir.resolve())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--serve", dest="serve", action="store_true", default=True,
                    help="spin up the mock API in-process (default)")
    ap.add_argument("--no-serve", dest="serve", action="store_false",
                    help="use an already-running API at CORDWELL_API_BASE")
    args = ap.parse_args()

    cfg = Config()
    if not cfg.db_path.exists():
        print("No data found. Run: python scripts/generate_sources.py")
        sys.exit(1)

    if args.serve:
        with run_mock_api(cfg.api_dir, token=cfg.api_token,
                          per_page=cfg.api_page_size) as base:
            run_cfg = dataclasses.replace(cfg, api_base_url=base)
            summary = run_pipeline(run_cfg)
    else:
        summary = run_pipeline(cfg)

    _print_summary(summary)


if __name__ == "__main__":
    main()
