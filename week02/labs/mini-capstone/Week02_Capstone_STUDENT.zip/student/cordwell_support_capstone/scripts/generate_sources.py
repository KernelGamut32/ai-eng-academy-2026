"""Generate all synthetic source data for the Cordwell mini-capstone.

Produces, deterministically from fixed seeds:

  data/cordwell.db            SQLite standing in for the production PostgreSQL:
                              products, orders, support_tickets (~50k rows)
  data/legacy_chats.csv       Retired live-chat export (latin-1, dupes, gaps)
  data/legacy_chats_extra.json  A second messy export with different key names
  data/api/reviews.json       Product-review payloads (served, paginated, by mock API)
  data/api/specs/<pid>.json   Manufacturer spec payloads, ~10% deliberately malformed

Everything a customer or agent "wrote" is fabricated. PII in the free text
(names, addresses, order numbers, emails, phones) is synthetic and exists so the
lab has something real to scrub. Cordwell Home and Hardware is fictional.

Run:  python scripts/generate_sources.py            (uses default seed 42)
      python scripts/generate_sources.py --tickets 20000   (smaller, faster)
"""

from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

import numpy as np

# Reuse the project taxonomy so sources and pipeline agree on the categories.
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cordwell_support.config import Config, CATEGORIES  # noqa: E402

# --------------------------------------------------------------------------
# Fabricated name / place pools (for PII injection and review authors)
# --------------------------------------------------------------------------
FIRST_NAMES = [
    "James", "Maria", "Wei", "Aisha", "Diego", "Priya", "Liam", "Fatima",
    "Noah", "Yuki", "Omar", "Chloe", "Andre", "Sofia", "Ravi", "Zoe",
    "Bjorn", "Ines", "Kofi", "Renata",
]
LAST_NAMES = [
    "Nguyen", "Okafor", "Muller", "Silva", "Patel", "Kim", "Rossi", "Haddad",
    "Jansen", "Ferreira", "Osei", "Novak", "Ibrahim", "Costa", "Larsen",
]
STREETS = ["Maple", "Oak", "Birchwood", "Cedar", "Elm", "Sycamore", "Willow"]
CITIES = ["Charlotte", "Raleigh", "Durham", "Asheville", "Greensboro", "Cary"]

PRODUCT_CATEGORIES = ["paint", "tools", "lumber", "appliances", "garden"]
PRODUCT_NOUNS = {
    "paint": ["interior latex paint", "exterior primer", "paint sprayer", "roller kit"],
    "tools": ["cordless drill", "circular saw", "impact driver", "socket set"],
    "lumber": ["pressure-treated 2x4", "plywood sheet", "cedar plank", "MDF board"],
    "appliances": ["water heater", "ceiling fan", "range hood", "garbage disposal"],
    "garden": ["pressure washer", "leaf blower", "garden hose reel", "hedge trimmer"],
}

CHANNELS = ["email", "chat", "phone"]


def rng_choice(rng, seq):
    """Pick one element from a Python sequence using a numpy Generator."""
    return seq[int(rng.integers(0, len(seq)))]


def make_pii(rng):
    """Return a small bundle of synthetic PII to weave into free text."""
    first = rng_choice(rng, FIRST_NAMES)
    last = rng_choice(rng, LAST_NAMES)
    num = int(rng.integers(100, 9999))
    street = rng_choice(rng, STREETS)
    city = rng_choice(rng, CITIES)
    zipc = int(rng.integers(27000, 28999))
    order_no = f"CW-{int(rng.integers(10_000_000, 99_999_999))}"
    email = f"{first.lower()}.{last.lower()}@example.com"
    phone = f"(704) 555-{int(rng.integers(1000, 9999))}"
    return {
        "name": f"{first} {last}",
        "address": f"{num} {street} St, {city}, NC {zipc}",
        "order_no": order_no,
        "email": email,
        "phone": phone,
    }


# --------------------------------------------------------------------------
# Message template banks (customer_message, agent_reply) per category
# --------------------------------------------------------------------------
def build_message(rng, category, product_name, pii, inject_pii):
    """Return (customer_message, agent_reply) for a category, optionally with PII."""
    who = pii["name"]
    order_no = pii["order_no"]

    # A neutral, non-PII detail that varies per ticket to widen the distinct-text
    # space the way real tickets do (every customer describes their situation a
    # little differently). This is what keeps the corpus from collapsing to a
    # handful of unique examples after PII is redacted.
    window = rng_choice(rng, ["last Monday", "over the weekend", "on the 3rd",
                              "two weeks ago", "yesterday", "last Tuesday"])
    qty = int(rng.integers(1, 5))

    if category == "order_status":
        cust = rng_choice(rng, [
            f"I ordered a {product_name} {window} and the tracking has not updated. "
            f"Where is it?",
            f"My {product_name} was supposed to arrive by now. Can you check the status?",
            f"I placed an order for a {product_name} {window} and still have not seen "
            f"it ship. Any update?",
            f"Can you tell me where my {product_name} is? It has been {window} with no "
            f"movement.",
            f"Hi, the status on my {product_name} still says processing since {window}. "
            f"Is it stuck?",
        ])
        reply = rng_choice(rng, [
            f"Thanks for reaching out. Your {product_name} is in transit, with delivery "
            f"expected in two to three business days. You will get a tracking email as "
            f"soon as it is out for delivery.",
            f"I am sorry for the wait. Your {product_name} shipped from our warehouse "
            f"and is on its way. If it has not arrived within three business days, reply "
            f"here and we will open a trace with the carrier.",
            f"I checked on your {product_name} and it cleared our facility and is moving "
            f"through the carrier network now. Expected delivery is within three days.",
        ])
    elif category == "returns":
        cust = rng_choice(rng, [
            f"I want to return the {product_name} I bought {window}. It is the wrong size.",
            f"The {product_name} arrived damaged. How do I send it back for a refund?",
            f"Can I return the {product_name} I opened but did not use?",
            f"I ordered {qty} of the {product_name} and need to send some back. What is "
            f"the process?",
            f"The {product_name} does not fit my project. Is it still returnable?",
        ])
        reply = rng_choice(rng, [
            f"I am sorry the {product_name} did not work out. You can return it within 90 "
            f"days with the receipt. I can email you a prepaid label, and your refund "
            f"posts three to five business days after we receive it.",
            f"Sorry to hear the {product_name} arrived damaged. I have started a return. "
            f"Please keep the packaging, use the label I am sending, and we will refund "
            f"the full amount once the carrier scans it.",
            f"No problem. The {product_name} is within the return window. I have generated "
            f"a return authorization and emailed you the steps to send it back.",
        ])
    elif category == "product_question":
        cust = rng_choice(rng, [
            f"Does the {product_name} come with a warranty, and what does it cover?",
            f"Is the {product_name} compatible with standard fittings? I do not want to "
            f"buy the wrong thing.",
            f"What is the difference between the {product_name} and the pro model?",
            f"How heavy is the {product_name}, and does it need any assembly?",
            f"Will the {product_name} hold up for regular outdoor use?",
        ])
        reply = rng_choice(rng, [
            f"Good question. The {product_name} includes a limited warranty covering "
            f"manufacturing defects. Wear from normal use is not covered. Let me know if "
            f"you would like the full warranty document.",
            f"The {product_name} uses standard fittings, so it should match what you have. "
            f"If you tell me the model you are pairing it with, I will confirm before you "
            f"buy.",
            f"The {product_name} is built for regular use and comes largely preassembled. "
            f"I can send the spec sheet if you would like the exact dimensions and weight.",
        ])
    elif category == "shipping":
        cust = rng_choice(rng, [
            f"How much is shipping on a {product_name}, and how long does it take?",
            f"Do you deliver the {product_name} to areas outside the city?",
            f"Can I get the {product_name} shipped faster? I need it this week.",
            f"Is there a delivery fee for {qty} of the {product_name}?",
            f"What is the delivery window if I order the {product_name} today?",
        ])
        reply = rng_choice(rng, [
            f"Standard shipping on the {product_name} is a flat five dollars and arrives "
            f"in three to five business days. Expedited two-day shipping is available at "
            f"checkout for an added fee.",
            f"We deliver the {product_name} to most of the region. If you share your ZIP "
            f"code I can confirm the delivery window and any surcharge for outlying areas.",
            f"If you order the {product_name} today it typically ships same day and "
            f"arrives within three to five business days by standard delivery.",
        ])
    else:  # billing
        cust = rng_choice(rng, [
            f"I was charged twice for my {product_name}. Can you fix this?",
            f"My refund for the {product_name} has not shown up yet. When will I see it?",
            f"There is a charge on my card for the {product_name} I do not recognize.",
            f"I returned the {product_name} {window} but was not refunded. Can you check?",
            f"Why was I billed extra on my {product_name} order?",
        ])
        reply = rng_choice(rng, [
            f"I am sorry about that. I can see the duplicate authorization on your "
            f"{product_name} and I have released it. It should drop off your statement "
            f"within three to five business days.",
            f"Thanks for your patience. Refunds for the {product_name} typically post "
            f"three to five business days after they are issued. I confirmed yours was "
            f"issued, so it should appear shortly.",
            f"I looked into the charge for your {product_name}. The extra amount was a "
            f"pre-authorization that will drop off shortly. Let me know if it does not.",
        ])

    if inject_pii:
        # Weave synthetic PII into the customer message (and sometimes the reply)
        # exactly the way real free text does: names, order numbers, contact info.
        extras = [
            f" My name is {who} and my order number is {order_no}.",
            f" You can reach me at {pii['email']} or {pii['phone']}.",
            f" Ship it to {pii['address']}.",
        ]
        cust = cust + rng_choice(rng, extras)
        if rng.random() < 0.4:
            reply = reply + f" I have noted order {order_no} on your account."
    return cust, reply


# --------------------------------------------------------------------------
# SQL source: products, orders, support_tickets
# --------------------------------------------------------------------------
def generate_sql(cfg: Config, rng, n_tickets, n_orders, n_products):
    con = sqlite3.connect(cfg.db_path)
    cur = con.cursor()
    cur.executescript(
        """
        DROP TABLE IF EXISTS support_tickets;
        DROP TABLE IF EXISTS orders;
        DROP TABLE IF EXISTS products;
        CREATE TABLE products (
            product_id INTEGER PRIMARY KEY,
            sku TEXT, name TEXT, category TEXT, price REAL
        );
        CREATE TABLE orders (
            order_id INTEGER PRIMARY KEY,
            customer_id INTEGER, product_id INTEGER,
            order_status TEXT, order_total REAL, created_at TEXT
        );
        CREATE TABLE support_tickets (
            ticket_id INTEGER PRIMARY KEY,
            customer_message TEXT, agent_reply TEXT,
            category TEXT, resolution TEXT,
            product_id INTEGER, order_id INTEGER,
            channel TEXT, created_at TEXT, updated_at TEXT
        );
        """
    )

    # products
    products = []
    for pid in range(1, n_products + 1):
        pcat = rng_choice(rng, PRODUCT_CATEGORIES)
        name = rng_choice(rng, PRODUCT_NOUNS[pcat])
        price = round(float(rng.uniform(8, 480)), 2)
        products.append((pid, f"SKU-{pid:05d}", name, pcat, price))
    cur.executemany("INSERT INTO products VALUES (?,?,?,?,?)", products)
    product_names = {p[0]: p[2] for p in products}

    # orders
    orders = []
    base_days = rng.integers(1, 400, size=n_orders)
    for i in range(n_orders):
        oid = 100_000 + i
        pid = int(rng.integers(1, n_products + 1))
        status = rng_choice(rng, ["delivered", "shipped", "processing", "cancelled"])
        total = round(float(rng.uniform(10, 900)), 2)
        created = f"2025-{int(rng.integers(1,13)):02d}-{int(rng.integers(1,28)):02d}"
        orders.append((oid, int(rng.integers(1, 40000)), pid, status, total, created))
    cur.executemany("INSERT INTO orders VALUES (?,?,?,?,?,?)", orders)
    order_ids = [o[0] for o in orders]

    # support_tickets  --  skewed category distribution (order_status dominant)
    cat_p = np.array([0.55, 0.15, 0.14, 0.09, 0.07])  # aligns to CATEGORIES order
    cat_p = cat_p / cat_p.sum()
    tickets = []
    for i in range(n_tickets):
        tid = 500_000 + i
        category = str(rng.choice(CATEGORIES, p=cat_p))
        pid = int(rng.integers(1, n_products + 1))
        pname = product_names[pid]
        pii = make_pii(rng)
        inject = rng.random() < 0.6  # 60% of tickets carry some PII in free text
        cust, reply = build_message(rng, category, pname, pii, inject)

        # resolution: most resolved, some not; a slice missing entirely
        r = rng.random()
        if r < 0.62:
            resolution = "resolved"
        elif r < 0.72:
            resolution = "escalated_resolved"
        elif r < 0.86:
            resolution = "unresolved"
        elif r < 0.93:
            resolution = "escalated"
        else:
            resolution = None  # missing

        # ~7% of rows are missing category entirely
        stored_category = None if rng.random() < 0.07 else category

        # ~4% of replies are junk / too short (auto-acks) to exercise length filter
        if rng.random() < 0.04:
            reply = rng_choice(rng, ["Thanks!", "ok", "See attached.", ""])

        order_id = int(rng_choice(rng, order_ids)) if rng.random() < 0.7 else None
        product_id = pid if rng.random() < 0.8 else None
        channel = rng_choice(rng, CHANNELS)
        month = int(rng.integers(1, 13))
        day = int(rng.integers(1, 28))
        created = f"2025-{month:02d}-{day:02d}T{int(rng.integers(0,24)):02d}:00:00Z"
        updated = created
        tickets.append((tid, cust, reply, stored_category, resolution,
                        product_id, order_id, channel, created, updated))

    cur.executemany(
        "INSERT INTO support_tickets VALUES (?,?,?,?,?,?,?,?,?,?)", tickets)
    con.commit()
    con.close()
    return product_names


# --------------------------------------------------------------------------
# Legacy file source: messy CSV (latin-1) + JSON with different keys
# --------------------------------------------------------------------------
def generate_legacy(cfg: Config, rng, product_names, n_csv, n_json):
    pids = list(product_names.keys())

    # CSV rows -- deliberately messy: mixed casing headers, missing fields,
    # duplicate rows, whitespace-only text, and latin-1-only accented characters.
    header = "Session_ID,User_Text,Agent_Text,Topic,Ended_At"
    rows = []
    accents = ["caf\u00e9", "na\u00efve", "R\u00e9nata", "j\u00e4rn", "\u00fcber-sale"]
    user_templates = [
        "quick question about the {p}",
        "is the {p} still on sale this week",
        "can you tell me if the {p} is in stock",
        "how do I set up the {p} I just bought",
        "does the {p} work with my existing setup",
        "what colors does the {p} come in",
        "I need help choosing between two models of {p}",
    ]
    agent_templates = [
        "Happy to help with the {p}. Here is what you need to know.",
        "Sure, the {p} is in stock and ships in three to five days.",
        "Great choice. The {p} is one of our most popular items.",
        "Let me pull up the details on the {p} for you.",
        "The {p} is on sale through the end of the week.",
        "",  # missing agent text
    ]
    for i in range(n_csv):
        sid = f"CHAT-{i:06d}"
        pid = rng_choice(rng, pids)
        pname = product_names[pid]
        topic = rng_choice(rng, list(CATEGORIES) + ["", "misc"])
        user = rng_choice(rng, user_templates).format(p=pname)
        if rng.random() < 0.15:
            user = user + f" ({rng_choice(rng, accents)})"  # latin-1-only glyphs
        agent = rng_choice(rng, agent_templates).format(p=pname)
        # whitespace-only user text on a slice
        if rng.random() < 0.05:
            user = "   "
        ended = f"2024-{int(rng.integers(1,13)):02d}-{int(rng.integers(1,28)):02d}"
        # simple CSV escaping: wrap fields in quotes, double internal quotes
        def q(s):
            return '"' + str(s).replace('"', '""') + '"'
        rows.append(",".join(q(x) for x in [sid, user, agent, topic, ended]))

    # inject duplicates (~8%)
    n_dupes = int(n_csv * 0.08)
    dupe_idx = rng.integers(0, len(rows), size=n_dupes)
    rows = rows + [rows[int(j)] for j in dupe_idx]

    text = header + "\n" + "\n".join(rows) + "\n"
    # write as latin-1 so a naive utf-8 read trips on the accented rows
    cfg.legacy_csv_path.write_bytes(text.encode("latin-1"))

    # JSON extra -- same idea, different key names (sessionId/customer/rep/label)
    json_rows = []
    for i in range(n_json):
        pid = rng_choice(rng, pids)
        pname = product_names[pid]
        rec = {
            "sessionId": f"JS-{i:06d}",
            "customer": rng_choice(rng, [
                f"is the {pname} available in other colors",
                f"can I pick up the {pname} in store today",
                f"what is the return window on the {pname}",
                f"is there a bulk discount on the {pname}",
                f"does the {pname} need any assembly",
            ]),
            "rep": rng_choice(rng, [
                f"Yes, the {pname} comes in several finishes.",
                f"The {pname} is available while supplies last.",
                f"You can pick up the {pname} at your local store today.",
                f"The {pname} has a 90-day return window with a receipt.",
            ]),
            "label": rng_choice(rng, list(CATEGORIES) + [None]),
        }
        if rng.random() < 0.1:
            rec.pop("rep")  # missing reply field entirely
        json_rows.append(rec)
    cfg.legacy_json_path.write_text(json.dumps(json_rows, indent=2))


# --------------------------------------------------------------------------
# API source: reviews (paginated) + specs (some malformed)
# --------------------------------------------------------------------------
def generate_api(cfg: Config, rng, product_names, n_reviews):
    api_dir = cfg.api_dir
    (api_dir / "specs").mkdir(parents=True, exist_ok=True)
    pids = list(product_names.keys())

    reviews = []
    for rid in range(1, n_reviews + 1):
        pid = rng_choice(rng, pids)
        pname = product_names[pid]
        rating = int(rng.integers(1, 6))
        title = rng_choice(rng, [
            "Works great", "Not what I expected", "Solid value", "Would buy again",
            "Broke quickly", "Exactly as described",
        ])
        body = f"The {pname} {rng_choice(rng, ['held up well', 'stopped working after a month', 'was easy to use', 'felt cheap'])}."
        review = {
            "review_id": rid, "product_id": pid, "rating": rating,
            "title": title, "body": body,
            "created_at": f"2025-{int(rng.integers(1,13)):02d}-{int(rng.integers(1,28)):02d}",
        }
        # ~2% are valid JSON but violate the review contract: an out-of-range
        # rating or a missing body. These parse fine and must be caught by the
        # Pydantic ReviewRecord model at ingestion, not by JSON parsing.
        if rng.random() < 0.02:
            if rng.random() < 0.5:
                review["rating"] = int(rng_choice(rng, [0, 6, 7]))
            else:
                review.pop("body")
        reviews.append(review)
    (api_dir / "reviews.json").write_text(json.dumps(reviews))

    # specs -- one file per product; ~10% deliberately malformed on the wire
    for pid, pname in product_names.items():
        path = api_dir / "specs" / f"{pid}.json"
        roll = rng.random()
        if roll < 0.10:
            # malformed: truncated JSON or plain garbage
            broken = rng_choice(rng, [
                '{"product_id": %d, "material": "steel", "warranty_months":' % pid,  # truncated
                "<html>502 Bad Gateway</html>",                                       # not JSON
                '{"product_id": %d "warranty_months": 12}' % pid,                     # missing comma
            ])
            path.write_text(broken)
        else:
            spec = {
                "product_id": pid,
                "name": pname,
                "material": rng_choice(rng, ["steel", "aluminum", "composite", "wood"]),
                "warranty_months": int(rng_choice(rng, [12, 24, 36])),
                "weight_lbs": round(float(rng.uniform(0.5, 60)), 1),
            }
            # ~8% of the valid ones are partial (missing warranty) to test defaults
            if rng.random() < 0.08:
                spec.pop("warranty_months")
            # ~3% are valid JSON but violate the spec contract: a blank or missing
            # material. These parse fine and must be caught by the Pydantic
            # SpecRecord model in fetch_spec, not by JSON parsing.
            elif rng.random() < 0.03:
                if rng.random() < 0.5:
                    spec["material"] = "   "
                else:
                    spec.pop("material")
            path.write_text(json.dumps(spec))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tickets", type=int, default=50_000)
    ap.add_argument("--orders", type=int, default=15_000)
    ap.add_argument("--products", type=int, default=400)
    ap.add_argument("--reviews", type=int, default=2_400)
    ap.add_argument("--legacy-csv", type=int, default=4_000)
    ap.add_argument("--legacy-json", type=int, default=1_200)
    args = ap.parse_args()

    cfg = Config()
    cfg.data_root.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(cfg.seed)

    print(f"Generating sources into {cfg.data_root.resolve()} (seed={cfg.seed})")
    product_names = generate_sql(cfg, rng, args.tickets, args.orders, args.products)
    print(f"  SQLite: {args.products} products, {args.orders} orders, "
          f"{args.tickets} support_tickets -> {cfg.db_path}")
    generate_legacy(cfg, rng, product_names, args.legacy_csv, args.legacy_json)
    print(f"  Legacy: {args.legacy_csv} CSV rows (+8% dupes, latin-1), "
          f"{args.legacy_json} JSON rows -> {cfg.legacy_csv_path.name}, "
          f"{cfg.legacy_json_path.name}")
    generate_api(cfg, rng, product_names, args.reviews)
    print(f"  API: {args.reviews} reviews, {args.products} specs (~10% malformed) "
          f"-> {cfg.api_dir}")
    print("Done.")


if __name__ == "__main__":
    main()
