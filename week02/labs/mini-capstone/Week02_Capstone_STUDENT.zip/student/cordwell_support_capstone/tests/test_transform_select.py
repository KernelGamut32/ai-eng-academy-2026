"""Transform selection: impute policy, filter logging, balancing (Module 05)."""

from __future__ import annotations

import pandas as pd

from cordwell_support.config import CATEGORIES
from cordwell_support.transform import select


def _candidates(cfg):
    from cordwell_support.extract import sql, files
    tickets = sql.read_tickets_chunked(cfg)
    legacy = files.load_legacy_chats(cfg)
    return select.normalize_sources(tickets, legacy)


def test_normalize_produces_contract(cfg):
    cand = _candidates(cfg)
    assert list(cand.columns) == select.CANDIDATE_COLUMNS
    assert len(cand) > 0


def test_impute_fills_some_and_excludes_unresolvable(cfg):
    cand = _candidates(cfg)
    filled, stats = select.impute_category(cand)
    assert stats["missing_before"] > 0
    assert stats["imputed"] >= 0
    assert stats["excluded_unresolvable"] >= 0
    assert stats["imputed"] + stats["excluded_unresolvable"] == stats["missing_before"]
    # After impute+exclude, no missing categories remain.
    assert filled["category"].notna().all()


def test_select_log_is_monotonic_and_ordered(cfg):
    cand = _candidates(cfg)
    filled, _ = select.impute_category(cand)
    kept, log = select.select_candidates(filled, cfg)
    # Each filter's 'remaining' never increases.
    remaining = [step["remaining"] for step in log]
    assert remaining == sorted(remaining, reverse=True)
    # Final frame length matches the last log entry.
    assert len(kept) == remaining[-1]
    # Every surviving row is in-taxonomy and de-duplicated.
    assert kept["category"].isin(CATEGORIES).all()
    assert not kept.duplicated(subset=["user_text", "assistant_text"]).any()


def test_balance_caps_each_category(cfg):
    cand = _candidates(cfg)
    filled, _ = select.impute_category(cand)
    kept, _ = select.select_candidates(filled, cfg)
    balanced = select.balance_categories(kept, cfg)
    counts = balanced["category"].value_counts()
    assert (counts <= cfg.target_per_category).all()


def test_balance_is_deterministic(cfg):
    cand = _candidates(cfg)
    filled, _ = select.impute_category(cand)
    kept, _ = select.select_candidates(filled, cfg)
    a = select.balance_categories(kept, cfg)
    b = select.balance_categories(kept, cfg)
    pd.testing.assert_frame_equal(a, b)
