"""SQL extraction: chunked reads and parameterized filtering (Module 04)."""

from __future__ import annotations

import pandas as pd
from sqlalchemy import text

from cordwell_support.config import USABLE_RESOLUTIONS
from cordwell_support.extract import sql


def test_read_tickets_returns_only_usable_resolutions(cfg):
    df = sql.read_tickets_chunked(cfg)
    assert len(df) > 0
    assert set(df["resolution"].unique()) <= set(USABLE_RESOLUTIONS)


def test_read_tickets_drops_empty_replies(cfg):
    df = sql.read_tickets_chunked(cfg)
    replies = df["agent_reply"].astype("string").str.strip()
    assert (replies.str.len() > 0).all()


def test_chunked_read_matches_single_read(cfg):
    """Streaming in chunks must yield exactly the same rows as one read."""
    engine = sql.make_engine(cfg)
    chunked = sql.read_tickets_chunked(cfg, engine)
    single = pd.read_sql_query(sql._TICKETS_SQL, engine,
                               params={"res": list(USABLE_RESOLUTIONS)})
    assert len(chunked) == len(single)
    engine.dispose()


def test_parameterization_is_safe_against_injection(cfg):
    """A hostile 'resolution' value must be treated as data, not SQL."""
    engine = sql.make_engine(cfg)
    # If the value were string-concatenated, this would drop the table. As a bound
    # parameter it simply matches nothing.
    hostile = "resolved'); DROP TABLE support_tickets;--"
    q = text("SELECT COUNT(*) AS n FROM support_tickets WHERE resolution = :r")
    n = pd.read_sql_query(q, engine, params={"r": hostile})["n"].iloc[0]
    assert int(n) == 0
    # Table still exists and still has rows.
    total = pd.read_sql_query(text("SELECT COUNT(*) AS n FROM support_tickets"),
                              engine)["n"].iloc[0]
    assert int(total) > 0
    engine.dispose()
