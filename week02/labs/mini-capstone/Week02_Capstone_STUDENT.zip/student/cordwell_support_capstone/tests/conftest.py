"""Shared fixtures: a small seeded dataset and a running mock API.

The dataset fixture is session-scoped and small (a few thousand tickets) so the
whole suite runs in a few seconds while still exercising every stage. It reuses
the real generator functions, so tests validate the same code path students run.
"""

from __future__ import annotations

import dataclasses
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

import generate_sources as gen  # noqa: E402
from cordwell_support.config import Config  # noqa: E402
from cordwell_support.mock_api.server import run_mock_api  # noqa: E402


@pytest.fixture(scope="session")
def cfg(tmp_path_factory) -> Config:
    """A Config pointing at a freshly generated small dataset in a temp dir."""
    root = tmp_path_factory.mktemp("cordwell_data")
    c = dataclasses.replace(
        Config(),
        data_root=root,
        tokenizer_vocab_size=800,
        target_per_category=300,
        sql_chunksize=1_000,
    )
    c.data_root.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(c.seed)
    names = gen.generate_sql(c, rng, n_tickets=4_000, n_orders=1_500, n_products=120)
    gen.generate_legacy(c, rng, names, n_csv=800, n_json=300)
    gen.generate_api(c, rng, names, n_reviews=600)
    return c


@pytest.fixture()
def api_cfg(cfg) -> Config:
    """A Config whose api_base_url points at an ephemeral running mock API."""
    with run_mock_api(cfg.api_dir, token=cfg.api_token,
                      per_page=cfg.api_page_size) as base:
        yield dataclasses.replace(cfg, api_base_url=base)
