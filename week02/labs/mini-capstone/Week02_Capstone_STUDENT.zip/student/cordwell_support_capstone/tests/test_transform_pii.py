"""PII scrubbing: pattern coverage, idempotence, and a property test."""

from __future__ import annotations

import re

from hypothesis import given, strategies as st

from cordwell_support.transform import pii


def test_scrubs_each_pattern():
    text = ("My name is Maria Larsen and my order number is CW-34553836. "
            "You can reach me at maria.larsen@example.com or (704) 555-1234. "
            "Ship it to 482 Maple St, Charlotte, NC 28201.")
    out = pii.scrub_pii(text)
    assert "CW-34553836" not in out and "[ORDER_ID]" in out
    assert "example.com" not in out and "[EMAIL]" in out
    assert "(704) 555-1234" not in out and "[PHONE]" in out
    assert "Maple St" not in out and "[ADDRESS]" in out
    assert "Maria Larsen" not in out and "[NAME]" in out


def test_scrub_is_idempotent():
    text = "order CW-12345678 for maria.larsen@example.com"
    once = pii.scrub_pii(text)
    twice = pii.scrub_pii(once)
    assert once == twice


def test_contains_pii_flags_before_and_clears_after():
    dirty = "order CW-99887766"
    assert pii.contains_pii(dirty)
    assert not pii.contains_pii(pii.scrub_pii(dirty))


_ORDER_RE = re.compile(r"CW-\d{8}")


@given(digits=st.integers(min_value=10_000_000, max_value=99_999_999))
def test_no_order_id_survives_scrub(digits):
    text = f"the order is CW-{digits} thanks"
    assert not _ORDER_RE.search(pii.scrub_pii(text))


def test_scrub_series_preserves_index():
    import pandas as pd
    s = pd.Series(["order CW-12345678", "no pii here"], index=[5, 9])
    out = pii.scrub_series(s)
    assert list(out.index) == [5, 9]
    assert out.loc[5] == "order [ORDER_ID]"
