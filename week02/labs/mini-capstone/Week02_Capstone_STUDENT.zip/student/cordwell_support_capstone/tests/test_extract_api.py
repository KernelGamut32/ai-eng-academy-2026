"""API extraction: pagination, retry through injected failures, defensive parse."""

from __future__ import annotations

import json

from cordwell_support.extract import api


def test_fetch_reviews_paginates_through_all_pages(api_cfg):
    """The loop must walk every page and absorb the injected 429 and 500."""
    reviews = api.fetch_reviews(api_cfg)
    # The generator wrote 600 reviews for the test fixture.
    assert len(reviews) == 600
    ids = [r["review_id"] for r in reviews]
    assert len(set(ids)) == len(ids)  # no page double-counted or skipped


def test_fetch_reviews_survives_rate_limit_and_5xx(api_cfg):
    """A fresh session hits the same misbehaving pages and still succeeds."""
    session = api.build_session(api_cfg)
    reviews = api.fetch_reviews(api_cfg, session)
    assert len(reviews) == 600


def test_fetch_spec_returns_none_on_malformed(api_cfg):
    """Malformed JSON must yield None, never raise."""
    session = api.build_session(api_cfg)
    results = [api.fetch_spec(session, api_cfg.api_base_url, pid,
                              api_cfg.api_timeout_seconds)
               for pid in range(1, 121)]
    # Some specs are valid dicts, some are None (malformed) - and none raised.
    assert any(r is not None for r in results)
    assert any(r is None for r in results)
    for r in results:
        assert r is None or isinstance(r, dict)


def test_fetch_specs_collects_failures(api_cfg):
    specs, failed = api.fetch_specs(api_cfg, list(range(1, 121)))
    assert len(specs) + len(failed) == 120
    # Roughly a tenth of specs are malformed; assert the failure path is exercised.
    assert len(failed) >= 1
    for spec in specs.values():
        # SpecRecord validation ran: every returned spec has the required fields and
        # a non-blank material. A blank-material spec would have been rejected.
        assert "product_id" in spec and "material" in spec
        assert spec["material"].strip() != ""


def test_missing_token_is_unauthorized(api_cfg):
    """Sanity: the mock enforces auth, so the client must send a token."""
    import requests
    resp = requests.get(f"{api_cfg.api_base_url}/reviews?page=1", timeout=5)
    assert resp.status_code == 401
