"""Load stage and the full end-to-end pipeline (the capstone acceptance test)."""

from __future__ import annotations

import json

import pandas as pd

from cordwell_support.config import SYSTEM_PROMPT
from cordwell_support.load import writer
from cordwell_support.pipeline import run_pipeline


def _example_frame(n_per_cat=40):
    from cordwell_support.config import CATEGORIES
    rows = []
    for cat in CATEGORIES:
        for i in range(n_per_cat):
            rows.append({
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": f"{cat} question number {i}"},
                    {"role": "assistant", "content": f"Here is a helpful reply for {cat} {i}."},
                ],
                "category": cat,
                "source": "support_ticket",
                "n_tokens": 30,
            })
    return pd.DataFrame(rows)


def test_stratified_split_covers_every_category(cfg):
    ex = _example_frame()
    train, val = writer.stratified_split(ex, cfg)
    assert set(train["category"]) == set(val["category"])
    # Roughly the configured validation fraction.
    assert abs(len(val) / len(ex) - cfg.val_fraction) < 0.05


def test_write_jsonl_one_object_per_line(cfg, tmp_path):
    ex = _example_frame(5)
    path = tmp_path / "out.jsonl"
    n = writer.write_jsonl(ex, path)
    lines = path.read_text().strip().splitlines()
    assert n == len(lines)
    for line in lines:
        obj = json.loads(line)
        assert set(obj.keys()) == {"messages"}
        assert obj["messages"][0]["role"] == "system"


# ---- The acceptance test: the whole pipeline, gate and all ---------------
def test_pipeline_end_to_end_passes_gate(api_cfg):
    summary = run_pipeline(api_cfg)
    assert summary["ok"] is True
    profile = summary["stages"]["profile"]
    assert profile["passed"] is True
    assert profile["n_examples"] >= 800
    # No category dominates and no PII leaked.
    assert profile["checks"]["max_category_share"]["ok"]
    assert profile["checks"]["no_residual_pii"]["ok"]

    # The boundary validators ran: tickets passed the extract-boundary schema, and
    # some invalid review records were dropped at ingestion.
    extract = summary["stages"]["extract"]
    assert extract["tickets_boundary_ok"] is True
    assert extract["reviews_dropped"] >= 1

    # The written shards exist, parse, and only carry the messages field.
    train_lines = api_cfg.train_path.read_text().strip().splitlines()
    assert len(train_lines) == summary["stages"]["load"]["train_written"]
    first = json.loads(train_lines[0])
    assert list(first.keys()) == ["messages"]


def test_pipeline_roundtrip_counts_match(api_cfg):
    summary = run_pipeline(api_cfg)
    load = summary["stages"]["load"]
    assert load["roundtrip"]["train_rows"] == load["train_written"]
    assert load["roundtrip"]["val_rows"] == load["val_written"]
