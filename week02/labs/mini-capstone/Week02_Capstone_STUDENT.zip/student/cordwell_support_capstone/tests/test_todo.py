"""Tests for YOU to write (Task T). Delete the NotImplementedError and implement.

The rest of the suite is the acceptance spec: it is given, and it must go green
when your implementation is correct. These three are yours to author. They are
small and mirror patterns you have already seen in the given tests.
"""

from __future__ import annotations

import pandas as pd

from cordwell_support.config import CATEGORIES
from cordwell_support.transform import pii, select


def test_todo_scrub_removes_phone_number():
    """Assert scrub_pii turns a US phone number into the [PHONE] placeholder.

    Write a short input string containing a phone like (704) 555-0111, scrub it,
    and assert the digits are gone and [PHONE] is present.
    """
    raise NotImplementedError("Write this test.")


def test_todo_balance_never_exceeds_target():
    """Build a small DataFrame where one category has more than target_per_category
    rows, call select.balance_categories with a Config whose target is small, and
    assert no category exceeds the target.
    """
    raise NotImplementedError("Write this test.")


def test_todo_impute_counts_add_up():
    """Construct a candidates frame with a few missing categories (some imputable
    by keyword, some not), call select.impute_category, and assert
    imputed + excluded_unresolvable == missing_before.
    """
    raise NotImplementedError("Write this test.")
