"""Quality layer: schema validation and tokenization."""

from __future__ import annotations

import pandas as pd
import pytest
from pydantic import ValidationError

from cordwell_support.config import SYSTEM_PROMPT
from cordwell_support.quality import tokens as tok
from cordwell_support.quality.schema import (ChatExample, EXAMPLE_TABLE_SCHEMA,
                                             ReviewRecord, SpecRecord, tickets_schema)
from cordwell_support.quality.validate import (validate_examples, validate_reviews,
                                               validate_tickets)


def _good_messages():
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": "Where is my order?"},
        {"role": "assistant", "content": "Let me check that order for you right now."},
    ]


# ---- pydantic row contract -----------------------------------------------
def test_chat_example_accepts_valid_shape():
    ChatExample(messages=_good_messages())


def test_chat_example_rejects_missing_system():
    bad = [{"role": "user", "content": "hi"},
           {"role": "assistant", "content": "hello there friend"}]
    with pytest.raises(Exception):
        ChatExample(messages=bad)


def test_chat_example_rejects_blank_content():
    bad = _good_messages()
    bad[2] = {"role": "assistant", "content": "   "}
    with pytest.raises(Exception):
        ChatExample(messages=bad)


def test_chat_example_rejects_non_assistant_ending():
    bad = _good_messages()[:2]  # ends on user
    with pytest.raises(Exception):
        ChatExample(messages=bad)


# ---- pandera tabular contract --------------------------------------------
def test_table_schema_rejects_unknown_category():
    df = pd.DataFrame({
        "category": ["not_a_category"], "source": ["support_ticket"],
        "user_chars": [10], "assistant_chars": [60], "n_tokens": [40],
    })
    with pytest.raises(Exception):
        EXAMPLE_TABLE_SCHEMA.validate(df, lazy=True)


# ---- tokenizer ------------------------------------------------------------
def test_tokenizer_counts_and_gate(cfg):
    texts = [f"Cordwell support example number {i} about a product." for i in range(200)]
    tokenizer = tok.train_tokenizer(texts, cfg)
    assert tokenizer.get_vocab_size() > 0
    n = tok.count_tokens(_good_messages(), tokenizer)
    assert n > 0

    examples = pd.DataFrame({"messages": [_good_messages(), _good_messages()],
                             "category": ["returns", "billing"],
                             "source": ["support_ticket", "support_ticket"]})
    examples = tok.add_token_lengths(examples, tokenizer)
    assert "n_tokens" in examples.columns
    kept, dropped = tok.gate_by_tokens(examples, cfg)
    assert dropped == 0 and len(kept) == 2


def test_validate_examples_on_good_frame(cfg):
    tokenizer = tok.train_tokenizer(["hello world"] * 50, cfg)
    ex = pd.DataFrame({"messages": [_good_messages()] * 3,
                       "category": ["returns", "billing", "shipping"],
                       "source": ["support_ticket"] * 3})
    ex = tok.add_token_lengths(ex, tokenizer)
    result = validate_examples(ex)
    assert result["n_validated"] == 3


# ---- Extract-boundary contract: pandera tickets schema -------------------
def _good_tickets():
    return pd.DataFrame({
        "ticket_id": [1, 2],
        "customer_message": ["where is my order", "how do I return this"],
        "agent_reply": ["It is on the way.", "Here is your return label."],
        "resolution": ["resolved", "escalated_resolved"],
        "category": ["order_status", None],   # category may be missing at this boundary
        "product_id": [10, None],
    })


def test_tickets_schema_accepts_valid_frame():
    validate_tickets(_good_tickets())  # must not raise


def test_tickets_schema_allows_missing_category():
    df = _good_tickets()
    df["category"] = None
    validate_tickets(df)  # missing category is expected at extract; must not raise


def test_tickets_schema_rejects_bad_resolution():
    df = _good_tickets()
    df.loc[0, "resolution"] = "abandoned"   # not a usable resolution
    with pytest.raises(ValueError):
        validate_tickets(df)


def test_tickets_schema_rejects_empty_reply():
    df = _good_tickets()
    df.loc[0, "agent_reply"] = ""
    with pytest.raises(ValueError):
        validate_tickets(df)


# ---- Source-record contract: pydantic SpecRecord -------------------------
def test_spec_record_accepts_valid():
    SpecRecord.model_validate({"product_id": 1, "name": "Hammer", "material": "steel"})


def test_spec_record_rejects_blank_material():
    with pytest.raises(ValidationError):
        SpecRecord.model_validate({"product_id": 1, "name": "Hammer", "material": "   "})


def test_spec_record_rejects_missing_material():
    with pytest.raises(ValidationError):
        SpecRecord.model_validate({"product_id": 1, "name": "Hammer"})


# ---- Source-record contract: pydantic ReviewRecord -----------------------
def _good_review():
    return {"review_id": 1, "product_id": 2, "rating": 4, "title": "Good",
            "body": "worked well", "created_at": "2025-01-01"}


def test_review_record_accepts_valid():
    ReviewRecord.model_validate(_good_review())


@pytest.mark.parametrize("bad_rating", [0, 6, 7, -1])
def test_review_record_rejects_out_of_range_rating(bad_rating):
    rec = _good_review()
    rec["rating"] = bad_rating
    with pytest.raises(ValidationError):
        ReviewRecord.model_validate(rec)


def test_validate_reviews_drops_and_counts_bad():
    reviews = [_good_review(), {**_good_review(), "review_id": 2, "rating": 9},
               {"review_id": 3, "product_id": 2, "rating": 5, "title": "x",
                "created_at": "2025-01-01"}]  # missing body
    kept, dropped = validate_reviews(reviews)
    assert dropped == 2
    assert len(kept) == 1
    assert kept[0]["review_id"] == 1
