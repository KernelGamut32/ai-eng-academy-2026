"""Legacy file extraction: encoding fallback, dedup, key mapping (Module 04)."""

from __future__ import annotations

from cordwell_support.extract import files
from cordwell_support.extract.files import CANONICAL_COLUMNS


def test_csv_is_not_utf8_but_loads(cfg):
    """The raw CSV must fail a naive utf-8 decode, proving the fallback matters."""
    raw = cfg.legacy_csv_path.read_bytes()
    try:
        raw.decode("utf-8")
        assert False, "fixture CSV should not be valid utf-8"
    except UnicodeDecodeError:
        pass
    df = files.load_legacy_chats(cfg)
    assert len(df) > 0


def test_canonical_columns_and_both_sources(cfg):
    df = files.load_legacy_chats(cfg)
    assert list(df.columns) == CANONICAL_COLUMNS
    assert set(df["source"].unique()) == {"legacy_csv", "legacy_json"}


def test_no_blank_or_duplicate_rows_survive(cfg):
    df = files.load_legacy_chats(cfg)
    # No whitespace-only or missing text remains.
    assert df["user_text"].notna().all()
    assert df["agent_text"].notna().all()
    assert (df["user_text"].str.strip().str.len() > 0).all()
    # No exact duplicate (user, agent) pairs remain.
    assert not df.duplicated(subset=["user_text", "agent_text"]).any()


def test_dedup_actually_removed_rows(cfg):
    df = files.load_legacy_chats(cfg)
    assert df.attrs["rows_dropped"] > 0
